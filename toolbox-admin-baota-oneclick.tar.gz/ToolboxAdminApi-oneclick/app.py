#!/usr/bin/env python3
import hashlib
import json
import mimetypes
import os
import secrets
import shutil
import smtplib
import subprocess
import tempfile
import time
import urllib.request
from datetime import datetime, timezone
from email.message import EmailMessage
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlparse

ROOT = Path(__file__).resolve().parent
WWW = ROOT / "wwwroot"
DATA = ROOT / "data"
USERS_PATH = DATA / "users.json"
MAIL_PATH = DATA / "mail.json"
USER_DATA = DATA / "users"
CLIENT_TEMPLATE = ROOT / "client-template" / "ToolboxClient.cs"
CLIENT_ICON = ROOT / "assets" / "toolbox-default.ico"
DEFAULT_APP_ICON = "/assets/toolbox-default-icon.png"
DEFAULT_LOGIN_HINT = "总管理员默认账号：admin，默认密码：dev-token。"
ADMIN_TOKEN = os.environ.get("TOOLBOX_ADMIN_TOKEN", "dev-token")
SESSIONS = {}
RESET_CODES = {}


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def random_hex(n=24):
    return secrets.token_hex(n)


def new_id(prefix="id"):
    return f"{prefix}_{int(time.time() * 1000):x}_{random_hex(4)}"


def sha256_hex(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def stored_password(password):
    salt = random_hex(16)
    return f"sha256${salt}${sha256_hex(salt + password)}"


def check_password(password, stored):
    try:
        kind, salt, digest = stored.split("$", 2)
    except ValueError:
        return False
    return kind == "sha256" and sha256_hex(salt + password) == digest


def read_json(path, fallback):
    if not path.exists():
        return fallback
    with path.open("r", encoding="utf-8-sig") as f:
        return json.load(f)


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
    tmp.replace(path)


def default_config():
    return {
        "app": {
            "title": "Toolbox",
            "subtitle": "",
            "version": "V1.0",
            "logo_text": "Y",
            "icon": DEFAULT_APP_ICON,
            "login_hint": DEFAULT_LOGIN_HINT,
            "window_width": 1080,
            "window_height": 700,
            "password": "",
            "theme": "午夜靛蓝",
            "theme_count": 19,
            "allow_client_theme": True,
            "bg_path": "",
            "output_dir": "",
        },
        "license": {"enabled": False, "api_base": "", "product_code": ""},
        "sidebar": [],
        "toolbox_tabs": [],
        "pages": {},
    }


def safe_id(value):
    text = "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in str(value).lower()).strip("_")
    return text or "user"


def user_config_path(user_id):
    safe = safe_id(user_id)
    return USER_DATA / safe / "config.json"


def read_config(user_id=""):
    path = user_config_path(user_id) if user_id else DATA / "config.json"
    if not path.exists():
        if (DATA / "config.json").exists() and user_id:
            path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(DATA / "config.json", path)
        else:
            write_json(path, default_config())
    config = read_json(path, default_config())
    app = config.setdefault("app", {})
    changed = False
    if not app.get("icon") and not app.get("icon_url") and not app.get("icon_path"):
        app["icon"] = DEFAULT_APP_ICON
        changed = True
    if "login_hint" not in app:
        app["login_hint"] = DEFAULT_LOGIN_HINT
        changed = True
    if app.get("password_enabled") is False and app.get("password"):
        app["password"] = ""
        changed = True
    if changed:
        write_json(path, config)
    return config


def write_config(config, user_id=""):
    path = user_config_path(user_id) if user_id else DATA / "config.json"
    write_json(path, config)


def public_toolbox_config(user_id):
    cfg = read_config(user_id)
    app = cfg.setdefault("app", {})
    if app.get("password_enabled") is False:
        app["password"] = ""
    normalize_client_config(cfg)
    path = user_config_path(user_id)
    meta = dict(cfg.get("_sync") or {})
    meta["userId"] = user_id
    meta["updatedAt"] = int(path.stat().st_mtime) if path.exists() else int(time.time())
    cfg["_sync"] = meta
    return cfg


def normalize_client_config(cfg):
    inject_update_entry(cfg)

    def normalize_button(button):
        if not isinstance(button, dict):
            return
        action = button.get("action", "link")
        target = get_target(button)
        if action == "download":
            button["download_url"] = target
            button.setdefault("url", target)
            button.setdefault("target", target)
        elif action == "script":
            button["script_id"] = target
            button.setdefault("script", target)
            button.setdefault("target", target)
        elif action == "cmd":
            button["command"] = target
            button.setdefault("target", target)
        elif action == "winget":
            button["package_id"] = target
            button.setdefault("winget", target)
            button.setdefault("package", target)
            button.setdefault("target", target)
        else:
            button["url"] = target
            button.setdefault("target", target)

    def normalize_sections(sections):
        for section in sections or []:
            for button in (section or {}).get("buttons") or []:
                normalize_button(button)

    for page in (cfg.get("pages") or {}).values():
        normalize_sections((page or {}).get("sections") or [])
    for tab in cfg.get("toolbox_tabs") or []:
        normalize_sections((tab or {}).get("sections") or [])


def inject_update_entry(cfg):
    app = cfg.get("app") or {}
    update_url = (app.get("update_url") or app.get("client_update_url") or "").strip()
    if not update_url:
        return
    title = (app.get("update_title") or "工具箱更新").strip() or "工具箱更新"
    button_name = (app.get("update_button") or "下载最新版").strip() or "下载最新版"
    page_id = "__client_update"
    sidebar = cfg.setdefault("sidebar", [])
    sidebar[:] = [item for item in sidebar if item.get("id") != page_id]
    sidebar.insert(0, {"id": page_id, "name": title})
    pages = cfg.setdefault("pages", {})
    pages[page_id] = {
        "title": title,
        "sections": [{
            "title": "",
            "buttons": [{
                "id": "client_update_download",
                "name": button_name,
                "action": "download",
                "download_url": update_url,
                "url": update_url,
                "target": update_url,
                "description": "下载并安装最新版本工具箱"
            }]
        }]
    }


def public_brand_config():
    app = read_config("admin").get("app", {})
    return {
        "title": app.get("admin_title") or "工具箱后台登录",
        "hint": app.get("login_hint") or DEFAULT_LOGIN_HINT,
        "icon": app.get("icon") or DEFAULT_APP_ICON,
        "logoText": app.get("logo_text") or "Y",
    }


def read_users():
    DATA.mkdir(parents=True, exist_ok=True)
    USER_DATA.mkdir(parents=True, exist_ok=True)
    store = read_json(USERS_PATH, {"users": [], "inviteCodes": []})
    store.setdefault("users", [])
    store.setdefault("inviteCodes", [])
    store.setdefault("settings", {})
    cleanup_invites(store)
    if not store["users"]:
        admin = {
            "id": "admin",
            "username": "admin",
            "displayName": "Super Admin",
            "role": "super",
            "active": True,
            "canViewJson": True,
            "passwordHash": stored_password(ADMIN_TOKEN),
            "apiKey": random_hex(20),
            "createdAt": now_iso(),
        }
        store["users"] = [admin]
        write_json(USERS_PATH, store)
        write_config(read_config(""), "admin")
    return store


def write_users(store):
    store.setdefault("users", [])
    store.setdefault("inviteCodes", [])
    store.setdefault("settings", {})
    cleanup_invites(store)
    write_json(USERS_PATH, store)


def cleanup_invites(store):
    try:
        keep = []
        now_ts = time.time()
        default_days = int((store.get("settings") or {}).get("inviteRetentionDays") or 7)
        for invite in store.get("inviteCodes", []):
            used = int(invite.get("usedCount") or 0)
            max_uses = int(invite.get("maxUses") or 1)
            days = int(invite.get("retentionDays") or default_days)
            if used > 0 and max_uses > 0 and used >= max_uses and days >= 0:
                used_at = ""
                if invite.get("usedBy"):
                    used_at = invite.get("usedBy", [{}])[-1].get("usedAt", "")
                try:
                    used_ts = time.mktime(time.strptime(used_at[:19], "%Y-%m-%dT%H:%M:%S"))
                except Exception:
                    used_ts = now_ts
                if now_ts - used_ts >= days * 86400:
                    continue
            keep.append(invite)
        store["inviteCodes"] = keep
    except Exception:
        return


def default_mail_settings():
    return {"host": "", "port": 465, "user": "", "password": "", "from": "", "secure": True}


def read_mail_settings():
    settings = read_json(MAIL_PATH, default_mail_settings())
    defaults = default_mail_settings()
    defaults.update(settings or {})
    return defaults


def public_mail_settings():
    settings = read_mail_settings()
    return {
        "host": settings.get("host", ""),
        "port": settings.get("port", 465),
        "user": settings.get("user", ""),
        "from": settings.get("from", ""),
        "secure": bool(settings.get("secure", True)),
        "hasPassword": bool(settings.get("password"))
    }


def write_mail_settings(body):
    current = read_mail_settings()
    current["host"] = (body.get("host") or "").strip()
    current["port"] = int(body.get("port") or 465)
    current["user"] = (body.get("user") or "").strip()
    current["from"] = (body.get("from") or current["user"]).strip()
    current["secure"] = bool(body.get("secure", True))
    if body.get("password"):
        current["password"] = body.get("password")
    elif body.get("clearPassword"):
        current["password"] = ""
    write_json(MAIL_PATH, current)
    return current


def public_user(user):
    return {
        "id": user.get("id"),
        "username": user.get("username"),
        "email": user.get("email", ""),
        "displayName": user.get("displayName"),
        "role": user.get("role"),
        "active": user.get("active", True),
        "canViewJson": user.get("canViewJson", user.get("role") == "super"),
        "apiKey": user.get("apiKey"),
    }


def find_user_by_id(user_id):
    return next((u for u in read_users()["users"] if u.get("id") == user_id), None)


def find_user_by_username(username):
    return next((u for u in read_users()["users"] if u.get("username") == username), None)


def find_user_by_email(email):
    email = (email or "").strip().lower()
    if not email:
        return None
    return next((u for u in read_users()["users"] if (u.get("email") or "").strip().lower() == email), None)


def find_user_by_api_key(key):
    if not key:
        return None
    return next((u for u in read_users()["users"] if u.get("apiKey") == key and u.get("active", True) is not False), None)


def create_user(username, password, display_name="", role="user", template_user=None, email=""):
    username = (username or "").strip()
    email = (email or "").strip().lower()
    password = password or ""
    display_name = (display_name or username).strip() or username
    role = "super" if role == "super" else "user"
    if not username or not password:
        raise ValueError("Username and password are required.")
    if find_user_by_username(username):
        raise ValueError("Username already exists.")
    if email and find_user_by_email(email):
        raise ValueError("Email already exists.")
    base = safe_id(username)
    user_id = base
    while find_user_by_id(user_id):
        user_id = f"{base}-{int(time.time() * 1000)}"
    user = {
        "id": user_id,
        "username": username,
        "email": email,
        "displayName": display_name,
        "role": role,
        "active": True,
        "canViewJson": role == "super",
        "passwordHash": stored_password(password),
        "apiKey": random_hex(20),
        "createdAt": now_iso(),
    }
    store = read_users()
    store["users"].append(user)
    write_users(store)
    write_config(read_config(template_user["id"] if template_user else "admin"), user_id)
    return user


def smtp_ready():
    settings = read_mail_settings()
    return bool((settings.get("host") or os.environ.get("SMTP_HOST")) and
                (settings.get("user") or os.environ.get("SMTP_USER")) and
                (settings.get("password") or os.environ.get("SMTP_PASS")))


def send_reset_email(email, code):
    if not smtp_ready():
        return False
    msg = EmailMessage()
    settings = read_mail_settings()
    sender = settings.get("from") or settings.get("user") or os.environ.get("SMTP_FROM") or os.environ.get("SMTP_USER")
    msg["From"] = sender
    msg["To"] = email
    msg["Subject"] = "工具箱后台密码找回验证码"
    msg.set_content("你的密码找回验证码是：%s\n验证码 10 分钟内有效。" % code)
    host = settings.get("host") or os.environ.get("SMTP_HOST")
    port = int(settings.get("port") or os.environ.get("SMTP_PORT", "465"))
    user = settings.get("user") or os.environ.get("SMTP_USER")
    password = settings.get("password") or os.environ.get("SMTP_PASS")
    if settings.get("secure", True) or port == 465:
        with smtplib.SMTP_SSL(host, port, timeout=15) as smtp:
            smtp.login(user, password)
            smtp.send_message(msg)
    else:
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            smtp.starttls()
            smtp.login(user, password)
            smtp.send_message(msg)
    return True


def update_user_account(user_id, body, super_edit=False):
    store = read_users()
    user = next((u for u in store["users"] if u.get("id") == user_id), None)
    if not user:
        raise ValueError("User not found.")
    username = (body.get("username") or user.get("username") or "").strip()
    email = (body.get("email") or user.get("email") or "").strip().lower()
    if not username:
        raise ValueError("Username is required.")
    for other in store["users"]:
        if other.get("id") == user_id:
            continue
        if other.get("username") == username:
            raise ValueError("Username already exists.")
        if email and (other.get("email") or "").strip().lower() == email:
            raise ValueError("Email already exists.")
    user["username"] = username
    user["email"] = email
    if "displayName" in body:
        user["displayName"] = (body.get("displayName") or username).strip() or username
    if super_edit and "role" in body:
        user["role"] = "super" if body.get("role") == "super" else "user"
    if super_edit and "active" in body:
        user["active"] = bool(body.get("active"))
    if super_edit and "canViewJson" in body:
        user["canViewJson"] = bool(body.get("canViewJson")) or user.get("role") == "super"
    if body.get("password"):
        user["passwordHash"] = stored_password(body.get("password"))
    if super_edit and body.get("resetApiKey"):
        user["apiKey"] = random_hex(20)
    write_users(store)
    return user


def get_auth(handler):
    auth = handler.headers.get("Authorization", "")
    token = ""
    if auth.startswith("Bearer "):
        token = auth[7:]
    else:
        token = handler.query.get("token", [""])[0]
    session = SESSIONS.get(token)
    if session:
        user = find_user_by_id(session["userId"])
        if user and user.get("active", True) is not False:
            return {"token": token, "user": user}
    if token == ADMIN_TOKEN:
        user = find_user_by_id("admin")
        if user:
            return {"token": token, "user": user}
    return None


def target_user_id(auth, handler):
    target = handler.headers.get("X-Target-User") or handler.query.get("targetUserId", [""])[0]
    if auth["user"].get("role") == "super" and target:
        user = find_user_by_id(target)
        if not user:
            raise ValueError("Target user not found.")
        return user["id"]
    return auth["user"]["id"]


def get_target(button):
    action = button.get("action", "link")
    if action == "download":
        return button.get("download_url") or button.get("url") or button.get("target") or ""
    if action == "cmd":
        return button.get("command") or button.get("target") or ""
    if action == "script":
        return button.get("script_id") or button.get("target") or ""
    if action == "winget":
        return button.get("package_id") or button.get("target") or ""
    return button.get("url") or button.get("target") or ""


def new_button(body):
    action = body.get("action", "link")
    target = body.get("target") or body.get("url") or ""
    item = {"name": body.get("name", "未命名"), "icon": body.get("icon", ""), "action": action}
    item["id"] = body.get("id") or new_id("btn")
    try:
        item["sort"] = int(body.get("sort") if body.get("sort") not in (None, "") else 0)
    except Exception:
        item["sort"] = 0
    if body.get("description") or body.get("intro") or body.get("remark"):
        item["description"] = body.get("description") or body.get("intro") or body.get("remark")
    if action == "download":
        item["download_url"] = target
    elif action == "cmd":
        item["command"] = target
    elif action == "script":
        item["script_id"] = target
    elif action == "winget":
        item["package_id"] = target
    else:
        item["url"] = target
    return item


def button_sort_value(button):
    try:
        return int((button or {}).get("sort") or 0)
    except Exception:
        return 0


def button_rows(config):
    rows = []
    changed = False
    for page_id, page in (config.get("pages") or {}).items():
        for si, section in enumerate(page.get("sections") or []):
            buttons = section.get("buttons") or []
            kept = [button for button in buttons if not is_empty_button(button)]
            if len(kept) != len(buttons):
                section["buttons"] = kept
                changed = True
            for bi, button in enumerate(section.get("buttons") or []):
                if not button.get("id"):
                    button["id"] = new_id("btn")
                    changed = True
                rows.append({"scope": "page", "pageId": page_id, "tabIndex": None, "sectionIndex": si, "buttonIndex": bi,
                             "id": button.get("id"),
                             "area": page.get("title") or page.get("name") or page_id, "section": section.get("title", ""),
                             "name": button.get("name", ""), "icon": button.get("icon", ""), "action": button.get("action", "link"),
                             "sort": button_sort_value(button), "target": get_target(button), "raw": button})
    for ti, tab in enumerate(config.get("toolbox_tabs") or []):
        for si, section in enumerate(tab.get("sections") or []):
            buttons = section.get("buttons") or []
            kept = [button for button in buttons if not is_empty_button(button)]
            if len(kept) != len(buttons):
                section["buttons"] = kept
                changed = True
            for bi, button in enumerate(section.get("buttons") or []):
                if not button.get("id"):
                    button["id"] = new_id("btn")
                    changed = True
                rows.append({"scope": "toolbox", "pageId": None, "tabIndex": ti, "sectionIndex": si, "buttonIndex": bi,
                             "id": button.get("id"),
                             "area": tab.get("name", ""), "section": section.get("title", ""),
                             "name": button.get("name", ""), "icon": button.get("icon", ""), "action": button.get("action", "link"),
                             "sort": button_sort_value(button), "target": get_target(button), "raw": button})
    rows.sort(key=lambda row: (row.get("area") or "", row.get("section") or "", int(row.get("sort") or 0), int(row.get("buttonIndex") or 0)))
    return rows, changed


def is_empty_button(button):
    if not isinstance(button, dict):
        return True
    name = str(button.get("name") or "").strip()
    if name and name != "未命名":
        return False
    if str(button.get("icon") or "").strip():
        return False
    if str(button.get("description") or button.get("intro") or button.get("remark") or "").strip():
        return False
    return not get_target(button).strip()


def get_container(config, body):
    if body.get("scope") == "toolbox":
        return config["toolbox_tabs"][int(body.get("tabIndex", 0))]
    return config["pages"][body.get("pageId")]


def find_button_slot(config, body):
    button_id = body.get("id")
    if button_id:
        for page_id, page in (config.get("pages") or {}).items():
            for si, section in enumerate(page.get("sections") or []):
                for bi, button in enumerate(section.get("buttons") or []):
                    if button.get("id") == button_id:
                        return section, bi
        for ti, tab in enumerate(config.get("toolbox_tabs") or []):
            for si, section in enumerate(tab.get("sections") or []):
                for bi, button in enumerate(section.get("buttons") or []):
                    if button.get("id") == button_id:
                        return section, bi
    container = get_container(config, body)
    section = container["sections"][int(body["sectionIndex"])]
    return section, int(body["buttonIndex"])


def clean_invite_prefix(value):
    text = "".join(ch for ch in str(value or "YQ").upper() if ch.isalnum() or ch in "-_").strip("-_")
    return (text or "YQ")[:18]


def make_invite_code(prefix, existing):
    for _ in range(1000):
        code = f"{prefix}-{random_hex(4).upper()}"
        if code not in existing:
            return code
    raise ValueError("Invite code generation failed.")


def csharp_literal(value):
    return '"' + str(value).replace("\\", "\\\\").replace('"', '\\"').replace("\r", "\\r").replace("\n", "\\n").replace("\t", "\\t") + '"'


def assembly_version(value):
    text = str(value or "1.0.0.0").strip().lstrip("vV")
    parts = []
    for raw in text.replace("_", ".").replace("-", ".").split("."):
        if raw.isdigit():
            parts.append(str(max(0, min(65535, int(raw)))))
        if len(parts) == 4:
            break
    while len(parts) < 4:
        parts.append("0")
    return ".".join(parts)


def make_ico_from_png(png_bytes):
    size = len(png_bytes)
    header = b"\x00\x00\x01\x00\x01\x00"
    entry = bytes([0, 0, 0, 0]) + (1).to_bytes(2, "little") + (32).to_bytes(2, "little") + size.to_bytes(4, "little") + (22).to_bytes(4, "little")
    return header + entry + png_bytes


def custom_client_icon(app, target_dir):
    url = (app.get("exe_icon") or app.get("exe_icon_url") or "").strip()
    if not url:
        return CLIENT_ICON
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "ToolboxAdminApi"})
        with urllib.request.urlopen(request, timeout=15) as response:
            data = response.read(2 * 1024 * 1024)
            content_type = response.headers.get("Content-Type", "").lower()
        icon_path = Path(target_dir) / "client-icon.ico"
        lower = url.lower().split("?", 1)[0]
        if lower.endswith(".ico") or "image/x-icon" in content_type or "image/vnd.microsoft.icon" in content_type:
            icon_path.write_bytes(data)
            return icon_path
        if lower.endswith(".png") or "image/png" in content_type or data.startswith(b"\x89PNG\r\n\x1a\n"):
            icon_path.write_bytes(make_ico_from_png(data))
            return icon_path
    except Exception:
        return CLIENT_ICON
    return CLIENT_ICON


def make_client_exe(user, base_url):
    if not CLIENT_TEMPLATE.exists():
        raise RuntimeError("Client template missing.")
    compiler = shutil.which("mcs") or shutil.which("csc")
    if not compiler:
        raise RuntimeError("服务器未安装 Mono/C# 编译器，无法在线生成 EXE。请在宝塔终端安装 mono-devel。")
    if not CLIENT_ICON.exists():
        raise RuntimeError("工具箱默认图标缺失，请上传 assets/toolbox-default.ico 后再生成 EXE。")
    api_key = user.get("apiKey") or random_hex(20)
    user["apiKey"] = api_key
    config_url = f"{base_url.rstrip('/')}/api/toolbox/config?key={quote(api_key)}"
    source = CLIENT_TEMPLATE.read_text(encoding="utf-8")
    app_config = read_config(user.get("id")).get("app", {})
    exe_title = app_config.get("exe_title") or app_config.get("title") or "Toolbox"
    exe_description = app_config.get("exe_description") or app_config.get("subtitle") or exe_title
    exe_product = app_config.get("exe_product") or app_config.get("title") or exe_title
    exe_company = app_config.get("exe_company") or ""
    exe_copyright = app_config.get("exe_copyright") or ""
    exe_version = assembly_version(app_config.get("exe_version") or app_config.get("version") or "1.0.0.0")
    source = source.replace('"__CONFIG_URL__"', csharp_literal(config_url))
    source = source.replace('"__BUILD_STAMP__"', csharp_literal(str(int(time.time()))))
    source = source.replace('"__INTEGRITY_SEED__"', csharp_literal(random_hex(16)))
    source = source.replace('"__EXE_TITLE__"', csharp_literal(exe_title))
    source = source.replace('"__EXE_DESCRIPTION__"', csharp_literal(exe_description))
    source = source.replace('"__EXE_COMPANY__"', csharp_literal(exe_company))
    source = source.replace('"__EXE_PRODUCT__"', csharp_literal(exe_product))
    source = source.replace('"__EXE_COPYRIGHT__"', csharp_literal(exe_copyright))
    source = source.replace('"__EXE_VERSION__"', csharp_literal(exe_version))
    source = source.replace('"__EXE_FILE_VERSION__"', csharp_literal(exe_version))
    with tempfile.TemporaryDirectory() as td:
        icon_file = custom_client_icon(app_config, td)
        src = Path(td) / "ToolboxClient.cs"
        exe = Path(td) / f"toolbox-{safe_id(user.get('username','user'))}-{int(time.time())}.exe"
        src.write_text(source, encoding="utf-8")
        args = [compiler, "-target:winexe", "-optimize+", f"-out:{exe}", f"-win32icon:{icon_file}",
                "-r:System.dll", "-r:System.Core.dll", "-r:System.Windows.Forms.dll",
                "-r:System.Drawing.dll", "-r:System.Web.Extensions.dll", str(src)]
        result = subprocess.run(args, universal_newlines=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
        if result.returncode != 0 or not exe.exists():
            raise RuntimeError("EXE 编译失败：" + (result.stderr or result.stdout))
        return exe.name, exe.read_bytes()


class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True


class Handler(BaseHTTPRequestHandler):
    server_version = "ToolboxAdminApiPython/1.0"

    def read_body(self):
        length = int(self.headers.get("Content-Length", "0") or "0")
        if not length:
            return {}
        return json.loads(self.rfile.read(length).decode("utf-8") or "{}")

    def send_json(self, value, status=200):
        data = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_bytes(self, data, content_type, status=200, filename=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        if filename:
            self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def do_GET(self):
        self.dispatch()

    def do_POST(self):
        self.dispatch()

    def do_PUT(self):
        self.dispatch()

    def do_PATCH(self):
        self.dispatch()

    def do_DELETE(self):
        self.dispatch()

    def dispatch(self):
        try:
            parsed = urlparse(self.path)
            self.route = unquote(parsed.path)
            self.query = parse_qs(parsed.query)
            method = self.command.upper()
            path = self.route
            if path == "/api/health":
                return self.send_json({"ok": True, "app": "ToolboxAdminApi", "time": now_iso()})
            if path == "/api/public/brand" and method == "GET":
                return self.send_json(public_brand_config())
            if path == "/api/login" and method == "POST":
                body = self.read_body()
                user = find_user_by_username((body.get("username") or "").strip())
                if not user or user.get("active", True) is False or not check_password(str(body.get("password") or ""), user.get("passwordHash", "")):
                    return self.send_json({"error": "Invalid username or password."}, 401)
                token = random_hex(32)
                SESSIONS[token] = {"userId": user["id"], "createdAt": now_iso()}
                return self.send_json({"token": token, "user": public_user(user)})
            if path == "/api/register" and method == "POST":
                body = self.read_body()
                code = (body.get("inviteCode") or "").strip()
                store = read_users()
                invite = next((x for x in store["inviteCodes"] if x.get("code") == code), None)
                if not invite or invite.get("active") is False:
                    raise ValueError("Invite code is invalid.")
                used = int(invite.get("usedCount") or 0)
                max_uses = int(invite.get("maxUses") or 1)
                if max_uses > 0 and used >= max_uses:
                    raise ValueError("Invite code has been used.")
                user = create_user(body.get("username"), body.get("password"), body.get("displayName"), "user", find_user_by_id("admin"), body.get("email"))
                store = read_users()
                invite = next((x for x in store["inviteCodes"] if x.get("code") == code), None)
                invite.setdefault("usedBy", []).append({"userId": user["id"], "username": user["username"], "usedAt": now_iso()})
                invite["usedCount"] = used + 1
                if max_uses > 0 and invite["usedCount"] >= max_uses:
                    invite["active"] = False
                write_users(store)
                token = random_hex(32)
                SESSIONS[token] = {"userId": user["id"], "createdAt": now_iso()}
                return self.send_json({"token": token, "user": public_user(user)})
            if path == "/api/password/forgot" and method == "POST":
                body = self.read_body()
                email = (body.get("email") or "").strip().lower()
                user = find_user_by_email(email)
                if not user or user.get("active", True) is False:
                    return self.send_json({"ok": True, "message": "如果邮箱存在，验证码会发送到邮箱。"})
                code = str(secrets.randbelow(900000) + 100000)
                RESET_CODES[email] = {"code": code, "userId": user["id"], "expires": time.time() + 600}
                sent = send_reset_email(email, code)
                result = {"ok": True, "message": "验证码已发送，请查看邮箱。"}
                if not sent:
                    result["message"] = "服务器未配置 SMTP，临时验证码已显示。"
                    result["debugCode"] = code
                return self.send_json(result)
            if path == "/api/password/reset" and method == "POST":
                body = self.read_body()
                email = (body.get("email") or "").strip().lower()
                code = (body.get("code") or "").strip()
                password = body.get("password") or ""
                record = RESET_CODES.get(email)
                if not record or record.get("code") != code or record.get("expires", 0) < time.time():
                    return self.send_json({"error": "验证码无效或已过期。"}, 400)
                if len(password) < 6:
                    return self.send_json({"error": "密码至少 6 位。"}, 400)
                update_user_account(record["userId"], {"password": password})
                RESET_CODES.pop(email, None)
                return self.send_json({"ok": True})
            if path in ("/api/toolbox/config", "/api/config"):
                user = find_user_by_api_key(self.query.get("key", [""])[0])
                if not user:
                    return self.send_json({"error": "Invalid or disabled toolbox key."}, 403)
                return self.send_json(public_toolbox_config(user["id"]))

            if path.startswith("/api/"):
                auth = get_auth(self)
                if not auth:
                    return self.send_json({"error": "Please log in first."}, 401)
                if path.startswith("/api/super"):
                    return self.handle_super(path, method, auth)
                if path.startswith("/api/admin"):
                    return self.handle_admin(path, method, auth)
                return self.send_json({"error": "Not found"}, 404)
            return self.serve_static(path)
        except Exception as exc:
            return self.send_json({"error": str(exc)}, 500)

    def handle_super(self, path, method, auth):
        if auth["user"].get("role") != "super":
            return self.send_json({"error": "Super admin only."}, 403)
        store = read_users()
        if path == "/api/super/users/batch" and method == "POST":
            b = self.read_body()
            ids = set(b.get("ids") or [])
            action = b.get("action")
            if "admin" in ids and action in ("delete", "disable"):
                raise ValueError("默认总管理员不能删除或停用。")
            changed = 0
            if action == "delete":
                before = len(store["users"])
                store["users"] = [u for u in store["users"] if u.get("id") not in ids]
                changed = before - len(store["users"])
            elif action in ("enable", "disable"):
                for user in store["users"]:
                    if user.get("id") in ids:
                        user["active"] = action == "enable"
                        changed += 1
            elif action in ("allow_json", "deny_json"):
                for user in store["users"]:
                    if user.get("id") in ids:
                        user["canViewJson"] = action == "allow_json" or user.get("role") == "super"
                        changed += 1
            else:
                raise ValueError("Unsupported batch action.")
            write_users(store)
            return self.send_json({"ok": True, "changed": changed})
        if path == "/api/super/users":
            if method == "GET":
                return self.send_json({"users": [public_user(u) for u in store["users"]]})
            if method == "POST":
                b = self.read_body()
                return self.send_json(public_user(create_user(b.get("username"), b.get("password"), b.get("displayName"), b.get("role"), auth["user"], b.get("email"))))
            if method == "PATCH":
                b = self.read_body()
                user = update_user_account(b.get("id"), b, True)
                return self.send_json(public_user(user))
            if method == "DELETE":
                b = self.read_body()
                if b.get("id") == "admin":
                    raise ValueError("Cannot delete default super admin.")
                store["users"] = [u for u in store["users"] if u.get("id") != b.get("id")]
                write_users(store)
                return self.send_json({"ok": True})
        if path == "/api/super/invites":
            if method == "GET":
                return self.send_json({"invites": store["inviteCodes"]})
            if method == "POST":
                b = self.read_body()
                prefix = clean_invite_prefix(b.get("prefix") or b.get("code") or "YQ")
                count = max(1, min(200, int(b.get("count") or 1)))
                max_uses = max(1, int(b.get("maxUses") or 1))
                retention_days = max(0, int(b.get("retentionDays") or (store.get("settings") or {}).get("inviteRetentionDays") or 7))
                existing = {x.get("code") for x in store["inviteCodes"]}
                created = []
                for _ in range(count):
                    code = make_invite_code(prefix, existing)
                    existing.add(code)
                    invite = {"code": code, "active": True, "maxUses": max_uses,
                              "usedCount": 0, "usedBy": [], "retentionDays": retention_days,
                              "createdAt": now_iso(), "createdBy": auth["user"].get("username")}
                    created.append(invite)
                store["inviteCodes"][0:0] = created
                write_users(store)
                return self.send_json({"invites": created})
            if method == "PATCH":
                b = self.read_body()
                invite = next((x for x in store["inviteCodes"] if x.get("code") == b.get("code")), None)
                if not invite:
                    raise ValueError("Invite code not found.")
                if "active" in b:
                    invite["active"] = bool(b.get("active"))
                if "maxUses" in b:
                    invite["maxUses"] = max(1, int(b.get("maxUses") or 1))
                if "retentionDays" in b:
                    invite["retentionDays"] = max(0, int(b.get("retentionDays") or 0))
                write_users(store)
                return self.send_json(invite)
            if method == "DELETE":
                b = self.read_body()
                codes = set(b.get("codes") or [])
                if not codes and b.get("code"):
                    codes.add(b.get("code"))
                store["inviteCodes"] = [x for x in store["inviteCodes"] if x.get("code") not in codes]
                write_users(store)
                return self.send_json({"ok": True})
        if path == "/api/super/mail":
            if method == "GET":
                return self.send_json(public_mail_settings())
            if method == "PATCH":
                write_mail_settings(self.read_body())
                return self.send_json(public_mail_settings())
        if path == "/api/super/mail/test" and method == "POST":
            body = self.read_body()
            email = (body.get("email") or "").strip()
            if not email:
                raise ValueError("请输入测试收件邮箱。")
            code = str(secrets.randbelow(900000) + 100000)
            if not send_reset_email(email, code):
                raise ValueError("SMTP 未配置完整或发送失败。")
            return self.send_json({"ok": True})
        return self.send_json({"error": "Not found"}, 404)

    def handle_admin(self, path, method, auth):
        user_id = target_user_id(auth, self)
        if path == "/api/admin/me" and method == "GET":
            return self.send_json({"user": public_user(auth["user"]), "targetUser": public_user(find_user_by_id(user_id))})
        if path == "/api/admin/account" and method == "PATCH":
            b = self.read_body()
            if b.get("password") and not check_password(str(b.get("currentPassword") or ""), auth["user"].get("passwordHash", "")):
                return self.send_json({"error": "当前密码不正确。"}, 400)
            user = update_user_account(auth["user"]["id"], b, False)
            return self.send_json({"user": public_user(user)})
        if path == "/api/admin/client/download" and method == "GET":
            name, data = make_client_exe(find_user_by_id(user_id), self.base_url())
            return self.send_bytes(data, "application/vnd.microsoft.portable-executable", filename=name)
        if path == "/api/admin/config":
            if method == "GET":
                return self.send_json(read_config(user_id))
            if method == "PUT":
                if auth["user"].get("role") != "super" and auth["user"].get("canViewJson") is False:
                    return self.send_json({"error": "当前账号没有 JSON 管理权限。"}, 403)
                write_config(self.read_body(), user_id)
                return self.send_json(read_config(user_id))
        if path == "/api/admin/app" and method == "PATCH":
            patch = self.read_body()
            cfg = read_config(user_id)
            app = cfg.setdefault("app", {})
            for k, v in patch.items():
                if k == "password_enabled" and not v:
                    app["password_enabled"] = False
                    app["password"] = ""
                elif k == "password_enabled":
                    app["password_enabled"] = True
                elif k == "password" and v:
                    app["password"] = stored_password(str(v))
                else:
                    app[k] = v
            write_config(cfg, user_id)
            return self.send_json(cfg)
        if path == "/api/admin/buttons":
            cfg = read_config(user_id)
            if method == "GET":
                rows, changed = button_rows(cfg)
                if changed:
                    write_config(cfg, user_id)
                return self.send_json(rows)
            body = self.read_body()
            if method == "POST":
                container = get_container(cfg, body)
                sections = container.setdefault("sections", [])
                while len(sections) <= int(body.get("sectionIndex", 0)):
                    sections.append({"title": "默认分组", "buttons": []})
                payload = dict(body.get("button") or body)
                sections[int(body.get("sectionIndex", 0))].setdefault("buttons", []).append(new_button(payload))
            elif method == "PATCH":
                section, button_index = find_button_slot(cfg, body)
                button = section["buttons"][button_index]
                old_id = button.get("id") or body.get("id")
                payload = dict(body.get("button") or body)
                if old_id:
                    payload["id"] = old_id
                button.clear()
                button.update(new_button(payload))
            elif method == "DELETE":
                section, button_index = find_button_slot(cfg, body)
                del section["buttons"][button_index]
            write_config(cfg, user_id)
            rows, changed = button_rows(cfg)
            if changed:
                write_config(cfg, user_id)
            return self.send_json(rows)
        return self.send_json({"error": "Not found"}, 404)

    def base_url(self):
        proto = self.headers.get("X-Forwarded-Proto", "http")
        host = self.headers.get("Host") or "localhost:5088"
        return f"{proto}://{host}"

    def serve_static(self, path):
        rel = path.strip("/") or "index.html"
        file_path = (WWW / rel).resolve()
        if not str(file_path).startswith(str(WWW.resolve())) or not file_path.exists() or not file_path.is_file():
            return self.send_json({"error": "Not found"}, 404)
        ctype = mimetypes.guess_type(str(file_path))[0] or "application/octet-stream"
        if ctype.startswith("text/") or file_path.suffix in (".js", ".json"):
            ctype += "; charset=utf-8"
        return self.send_bytes(file_path.read_bytes(), ctype)


if __name__ == "__main__":
    read_users()
    host = os.environ.get("TOOLBOX_HOST", "127.0.0.1")
    port = int(os.environ.get("TOOLBOX_PORT", "5088"))
    print(f"Toolbox admin API started: http://{host}:{port}/", flush=True)
    ThreadingHTTPServer((host, port), Handler).serve_forever()
