﻿# 工具箱后台 API

这是一个用于管理工具箱配置的后台 API。它同时提供网页后台和给工具箱客户端拉取配置的公开接口。

当前版本使用无需编译的 PowerShell 服务端，适合这台机器直接运行。

## 启动

```powershell
cd ToolboxAdminApi
.\server.ps1 -Url http://localhost:5088/
```

打开：

```text
http://localhost:5088
```

默认总管理员账号：

```text
用户名：admin
密码：dev-token
```

生产环境建议改成环境变量：

```powershell
$env:TOOLBOX_ADMIN_TOKEN="your-strong-token"
.\server.ps1 -Url http://0.0.0.0:5088/
```

## 对接接口

公开配置接口：

```http
GET /api/toolbox/config
```

返回值就是工具箱可使用的完整 JSON 配置。

多人使用：

- 普通用户登录后只能看到和修改自己的工具箱配置。
- 总管理员登录后可以在“用户”页创建用户、重置密码、删除用户。
- 总管理员顶部可以切换“正在管理”的用户，查看或修改该用户的数据。
- 每个用户都有独立的工具箱对接地址，格式是 `/api/toolbox/config?key=...`。

工具箱启动密码：

- “应用信息”里的“工具箱启动密码”打开后，客户工具箱启动时需要输入密码。
- 关闭后会清空配置里的 `app.password`，客户工具箱不再要求密码。
- 开启但从未设置过密码时，需要填写“新密码”。

专属工具箱下载：

- “对接”页可以下载当前正在管理用户的工具箱 EXE。
- 总管理员也可以在“用户”页给每个用户单独下载工具箱 EXE。
- EXE 内已经写入该用户的 `/api/toolbox/config?key=...` 地址。
- 双击 EXE 即可启动，目标电脑需要可运行 .NET Framework 4 程序。

后台接口登录后使用 `Authorization: Bearer <session-token>`：

```http
POST   /api/login
GET    /api/admin/config
PUT    /api/admin/config
PATCH  /api/admin/app
GET    /api/admin/client/download
GET    /api/admin/buttons
POST   /api/admin/buttons
PATCH  /api/admin/buttons
DELETE /api/admin/buttons
GET    /api/super/users
POST   /api/super/users
PATCH  /api/super/users
DELETE /api/super/users
```

## 数据文件

数据保存在：

```text
data/users.json
data/users/<用户ID>/config.json
```

默认管理员的数据会从原 exe 中解析出来的配置初始化。

