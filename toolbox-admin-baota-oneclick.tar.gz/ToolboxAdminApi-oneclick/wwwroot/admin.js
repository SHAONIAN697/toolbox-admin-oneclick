﻿const state = {
  token: localStorage.getItem('toolbox_session_token') || '',
  currentUser: null,
  targetUser: null,
  targetUserId: localStorage.getItem('toolbox_target_user') || '',
  users: [],
  invites: [],
  mail: null,
  config: null,
  buttons: []
};

const $ = (id) => document.getElementById(id);

const ACTIONS = [
  ['link', '打开网页'],
  ['download', '下载文件'],
  ['cmd', '运行命令'],
  ['script', '内置功能'],
  ['winget', '安装软件']
];

const ACTION_LABELS = Object.fromEntries(ACTIONS);

const SCRIPT_LABELS = {
  preset_new_machine: '新机一键优化',
  preset_audio_workstation: '音频工站优化',
  preset_privacy_lockdown: '隐私加固',
  preset_pure_activate: '纯净激活套装',
  sys_control_panel: '控制面板',
  sys_sound_settings: '声音设置',
  open_network_connections: '网络连接',
  sys_apps_features: '程序和功能',
  sys_device_manager: '设备管理器',
  sys_disk_manager: '磁盘管理',
  sys_computer_manager: '计算机管理',
  sys_services: '服务',
  sys_task_manager: '任务管理器',
  sys_system_info: '系统信息',
  sys_env_vars: '环境变量',
  sys_event_viewer: '事件查看器',
  sys_registry: '注册表',
  sys_group_policy: '组策略',
  sys_cmd_prompt: '命令提示符',
  sys_security_policy: '安全策略',
  disable_firewall: '关闭防火墙',
  disable_update: '禁用系统更新',
  sys_power_options: '电源管理',
  sys_classic_context_menu: 'Win 传统右键',
  add_hosts_block: '编辑 Hosts',
  sys_system_clean: '系统清理',
  disable_uac: '禁用 UAC',
  activate_windows: '一键激活系统'
};

const NAV_ICONS = {
  overview: '⌁',
  account: '♙',
  mail: '✉',
  buttons: '▦',
  users: '♙',
  json: '▤',
  dock: '⌘'
};

function setupSidebar() {
  const sidebar = document.querySelector('.sidebar');
  if (!sidebar || sidebar.dataset.ready) return;
  sidebar.dataset.ready = '1';
  const brand = sidebar.querySelector('.brand');
  const toggle = document.createElement('button');
  toggle.id = 'sidebarToggle';
  toggle.type = 'button';
  toggle.className = 'sidebar-toggle';
  toggle.setAttribute('aria-label', '展开/收起菜单');
  toggle.textContent = '☰';
  sidebar.insertBefore(toggle, brand);

  sidebar.querySelectorAll('.nav').forEach((button) => {
    const view = button.dataset.view || '';
    const text = button.textContent.trim();
    button.innerHTML = `<span class="nav-icon">${NAV_ICONS[view] || '•'}</span><span class="nav-text">${escapeHtml(text)}</span>`;
    button.title = text;
  });

  const applyMobileDefault = () => {
    const mobile = window.matchMedia('(max-width: 900px)').matches;
    document.body.classList.toggle('sidebar-collapsed', mobile && !document.body.classList.contains('sidebar-open'));
  };
  toggle.onclick = () => {
    if (window.matchMedia('(max-width: 900px)').matches) {
      document.body.classList.toggle('sidebar-open');
      document.body.classList.toggle('sidebar-collapsed', !document.body.classList.contains('sidebar-open'));
    } else {
      document.body.classList.toggle('sidebar-collapsed');
      localStorage.setItem('toolbox_sidebar_collapsed', document.body.classList.contains('sidebar-collapsed') ? '1' : '0');
    }
  };
  if (localStorage.getItem('toolbox_sidebar_collapsed') === '1') {
    document.body.classList.add('sidebar-collapsed');
  }
  window.addEventListener('resize', applyMobileDefault);
  applyMobileDefault();
}

function setStatus(message, isError = false) {
  const status = $('status');
  if (status) status.textContent = '';
  if (!message) return;
  showToast(message, isError ? 'error' : 'success');
}

function getToastStack() {
  let stack = $('toastStack');
  if (!stack) {
    stack = document.createElement('div');
    stack.id = 'toastStack';
    stack.setAttribute('aria-live', 'polite');
  }
  stack.className = 'toast-stack';
  if (stack.parentElement !== document.body) {
    document.body.appendChild(stack);
  }
  return stack;
}

function showToast(message, type = 'success') {
  if (!message) return;
  const stack = getToastStack();
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  const icon = document.createElement('span');
  icon.className = 'toast-icon';
  icon.textContent = type === 'error' ? '!' : (type === 'warn' ? '!' : '✓');
  icon.setAttribute('aria-hidden', 'true');
  const text = document.createElement('div');
  text.className = 'toast-message';
  text.textContent = message;
  const close = document.createElement('button');
  close.className = 'toast-close';
  close.type = 'button';
  close.setAttribute('aria-label', '关闭提示');
  close.textContent = '×';
  toast.appendChild(icon);
  toast.appendChild(text);
  toast.appendChild(close);
  stack.appendChild(toast);

  const remove = () => {
    if (!toast.isConnected || toast.classList.contains('removing')) return;
    toast.classList.add('removing');
    setTimeout(() => toast.remove(), 180);
  };
  close.onclick = remove;
  setTimeout(remove, type === 'error' ? 5200 : 2600);
  while (stack.children.length > 4) {
    stack.firstElementChild?.remove();
  }
}

function authHeaders() {
  const headers = {
    'Content-Type': 'application/json; charset=utf-8'
  };
  if (state.token) {
    headers.Authorization = `Bearer ${state.token}`;
  }
  if (state.currentUser?.role === 'super' && state.targetUserId) {
    headers['X-Target-User'] = state.targetUserId;
  }
  return headers;
}

async function api(path, options = {}) {
  const res = await fetch(path, {
    ...options,
    headers: {
      ...authHeaders(),
      ...(options.headers || {})
    }
  });

  const contentType = res.headers.get('content-type') || '';
  const text = await res.text();
  const looksLikeHtml = /^\s*</.test(text);

  function parseJson() {
    try {
      return text ? JSON.parse(text) : null;
    } catch (error) {
      if (looksLikeHtml) {
        throw new Error(`接口 ${path} 返回了网页内容，不是 JSON。请检查 CDN/反向代理是否已放行 /api 路径。`);
      }
      throw new Error(`接口 ${path} 返回格式错误：${error.message}`);
    }
  }

  if (!res.ok) {
    if (contentType.includes('application/json')) {
      const parsed = parseJson();
      throw new Error(parsed?.error || `接口 ${path} 请求失败：HTTP ${res.status}`);
    }
    if (looksLikeHtml) {
      throw new Error(`接口 ${path} 被返回成网页了，不是后台数据。请检查 CDN/反代规则是否把 /api 转发到后端。`);
    }
    throw new Error(text || `接口 ${path} 请求失败：HTTP ${res.status}`);
  }

  if (contentType.includes('application/json')) {
    return parseJson();
  }
  if (path.startsWith('/api/')) {
    if (looksLikeHtml) {
      throw new Error(`接口 ${path} 返回了网页内容，不是 JSON。请检查 CDN/反向代理是否已放行 /api 路径。`);
    }
    throw new Error(`接口 ${path} 没有返回 JSON，请检查后端服务状态。`);
  }
  return text;
}

function setLoginMessage(message, type = 'error') {
  $('loginError').textContent = message || '';
  if (message) showToast(message, type);
}
async function loadAll() {
  if (!state.token) {
    await loadPublicBrand();
    showLogin();
    return;
  }

  showToast('正在读取配置...', 'warn');
  let me;
  try {
    me = await api('/api/admin/me');
  } catch (error) {
    handleLoadFailure(error);
    return;
  }
  state.currentUser = me.user;
  state.targetUser = me.targetUser;

  try {
    if (state.currentUser.role === 'super') {
      await loadUsers();
      await loadMailSettings();
      if (!state.targetUserId) {
        state.targetUserId = state.currentUser.id;
        localStorage.setItem('toolbox_target_user', state.targetUserId);
      }
    } else {
      state.targetUserId = state.currentUser.id;
      state.users = [];
    }

    state.config = await api('/api/admin/config');
    state.buttons = await api('/api/admin/buttons');
    renderAll();
    showToast('配置读取成功。', 'success');
  } catch (error) {
    handleLoadFailure(error);
  }
}

function handleLoadFailure(error) {
  const status = $('status');
  if (status) status.textContent = '';
  state.token = '';
  state.currentUser = null;
  state.targetUser = null;
  state.targetUserId = '';
  state.users = [];
  state.invites = [];
  localStorage.removeItem('toolbox_session_token');
  localStorage.removeItem('toolbox_target_user');
  showLogin();
  showToast(`读取配置失败：${error.message}`, 'error');
}

function showLogin() {
  $('loginScreen').classList.remove('hidden');
  document.querySelectorAll('aside, main').forEach((el) => el.style.visibility = 'hidden');
}

function showApp() {
  $('loginScreen').classList.add('hidden');
  document.querySelectorAll('aside, main').forEach((el) => el.style.visibility = '');
}

async function loadPublicBrand() {
  try {
    const brand = await api('/api/public/brand');
    $('loginTitle').textContent = brand.title || '工具箱后台登录';
    $('loginHint').textContent = brand.hint || '';
  } catch {
    $('loginTitle').textContent = '工具箱后台登录';
  }
}

async function login() {
  const username = $('loginUsername').value.trim();
  const password = $('loginPassword').value;
  setLoginMessage('');

  try {
    const result = await api('/api/login', {
      method: 'POST',
      body: JSON.stringify({ username, password })
    });
    state.token = result.token;
    state.currentUser = result.user;
    state.targetUserId = result.user.id;
    localStorage.setItem('toolbox_session_token', state.token);
    localStorage.setItem('toolbox_target_user', state.targetUserId);
    showApp();
    await loadAll();
  } catch (error) {
    setLoginMessage('登录失败：账号或密码不正确。');
  }
}

function setLoginMode(mode) {
  const isRegister = mode === 'register';
  const isForgot = mode === 'forgot';
  $('loginForm').hidden = isRegister || isForgot;
  $('registerForm').hidden = !isRegister;
  $('forgotForm').hidden = !isForgot;
  $('showLoginBtn').classList.toggle('active', !isRegister && !isForgot);
  $('showRegisterBtn').classList.toggle('active', isRegister);
  $('showForgotBtn').classList.toggle('active', isForgot);
  setLoginMessage('');
}

async function register() {
  const username = $('registerUsername').value.trim();
  const email = $('registerEmail').value.trim();
  const displayName = $('registerDisplayName').value.trim();
  const password = $('registerPassword').value;
  const inviteCode = $('registerInviteCode').value.trim();
  setLoginMessage('');

  if (!username || !email || !password || !inviteCode) {
    setLoginMessage('注册失败：用户名、邮箱、密码和邀请码都要填写。');
    return;
  }

  try {
    const result = await api('/api/register', {
      method: 'POST',
      body: JSON.stringify({ username, email, displayName, password, inviteCode })
    });
    state.token = result.token;
    state.currentUser = result.user;
    state.targetUserId = result.user.id;
    localStorage.setItem('toolbox_session_token', state.token);
    localStorage.setItem('toolbox_target_user', state.targetUserId);
    showApp();
    await loadAll();
  } catch (error) {
    setLoginMessage(`注册失败：${error.message || '邀请码无效或账号已存在。'}`);
  }
}

async function sendResetCode() {
  const email = $('forgotEmail').value.trim();
  setLoginMessage('');
  if (!email) {
    setLoginMessage('请先输入邮箱。');
    return;
  }
  const result = await api('/api/password/forgot', {
    method: 'POST',
    body: JSON.stringify({ email })
  });
  setLoginMessage(result.debugCode ? `${result.message} 验证码：${result.debugCode}` : result.message, result.debugCode ? 'warn' : 'success');
}

async function resetPassword() {
  const email = $('forgotEmail').value.trim();
  const code = $('resetCode').value.trim();
  const password = $('resetPassword').value;
  setLoginMessage('');
  try {
    await api('/api/password/reset', {
      method: 'POST',
      body: JSON.stringify({ email, code, password })
    });
    setLoginMessage('密码已重置，请返回登录。', 'success');
    $('resetCode').value = '';
    $('resetPassword').value = '';
  } catch (error) {
    setLoginMessage(`重置失败：${error.message || '验证码无效。'}`);
  }
}

function logout() {
  state.token = '';
  state.currentUser = null;
  state.targetUser = null;
  state.users = [];
  state.invites = [];
  localStorage.removeItem('toolbox_session_token');
  localStorage.removeItem('toolbox_target_user');
  showLogin();
}

function renderAll() {
  showApp();
  renderUserContext();
  renderApp();
  renderAccount();
  renderMailSettings();
  renderStats();
  renderManageControls();
  renderSelectors();
  renderButtons();
  const canJson = canViewJson();
  const jsonNav = document.querySelector('.nav[data-view="json"]');
  if (jsonNav) jsonNav.hidden = !canJson;
  if (!canJson && $('view-json')?.classList.contains('show')) switchView('overview');
  if ($('jsonEditor')) $('jsonEditor').value = canJson ? JSON.stringify(state.config, null, 2) : '';
  renderJsonPermissions();
  const endpointUser = state.targetUser || state.currentUser;
  const key = endpointUser?.apiKey ? `?key=${encodeURIComponent(endpointUser.apiKey)}` : '';
  $('publicEndpoint').textContent = `${location.origin}/api/toolbox/config${key}`;
}

async function loadUsers() {
  if (state.currentUser?.role !== 'super') return;
  const result = await api('/api/super/users');
  state.users = result.users || [];
  if (state.targetUserId && !state.users.some((user) => user.id === state.targetUserId)) {
    state.targetUserId = state.currentUser.id;
    localStorage.setItem('toolbox_target_user', state.targetUserId);
  }
  state.targetUser = state.users.find((user) => user.id === state.targetUserId) || state.currentUser;
  await loadInvites();
}

async function loadInvites() {
  if (state.currentUser?.role !== 'super') return;
  const result = await api('/api/super/invites');
  state.invites = result.invites || [];
}

async function loadMailSettings() {
  if (state.currentUser?.role !== 'super') return;
  state.mail = await api('/api/super/mail');
}

function renderUserContext() {
  const isSuper = state.currentUser?.role === 'super';
  document.querySelectorAll('.super-only').forEach((el) => {
    el.hidden = !isSuper;
  });

  if (!isSuper && ($('view-users')?.classList.contains('show') || $('view-mail')?.classList.contains('show'))) {
    switchView('overview');
  }

  $('currentUserLabel').textContent = state.currentUser
    ? `${state.currentUser.displayName || state.currentUser.username}（${isSuper ? '总管理员' : '普通用户'}）`
    : '未登录';

  const selector = $('targetUserSelect');
  if (isSuper && selector) {
    const previous = state.targetUserId || state.currentUser.id;
    selector.innerHTML = '';
    state.users.forEach((user) => {
      const opt = document.createElement('option');
      opt.value = user.id;
      opt.textContent = `${user.displayName || user.username} / ${user.username}`;
      selector.appendChild(opt);
    });
    selector.value = previous;
    state.targetUserId = selector.value || state.currentUser.id;
    state.targetUser = state.users.find((user) => user.id === state.targetUserId) || state.currentUser;
  }

  renderUsers();
  renderInvites();
}

function switchView(view) {
  if ((view === 'users' || view === 'mail') && state.currentUser?.role !== 'super') {
    view = 'overview';
  }
  if (view === 'json' && !canViewJson()) {
    setStatus('当前账号没有 JSON 管理权限。', true);
    view = 'overview';
  }
  document.querySelectorAll('.nav').forEach((x) => x.classList.remove('active'));
  document.querySelectorAll('.view').forEach((x) => x.classList.remove('show'));
  const nav = document.querySelector(`.nav[data-view="${view}"]`);
  const panel = $(`view-${view}`);
  if (nav) nav.classList.add('active');
  if (panel) panel.classList.add('show');
}

function canViewJson() {
  if (!state.currentUser) return false;
  if (state.currentUser.role === 'super') return true;
  return state.currentUser.canViewJson !== false;
}

function renderJsonPermissions() {
  const view = $('view-json');
  if (!view) return;
  let panel = $('jsonPermissionPanel');
  if (state.currentUser?.role !== 'super') {
    if (panel) panel.hidden = true;
    return;
  }
  if (!panel) {
    panel = document.createElement('div');
    panel.id = 'jsonPermissionPanel';
    panel.className = 'panel json-permission-panel';
    panel.innerHTML = `
      <div class="panel-head">
        <h2>JSON 查看权限</h2>
        <button id="saveJsonPermissionBtn" type="button">保存权限</button>
      </div>
      <div class="permission-list" id="jsonPermissionList"></div>
    `;
    view.insertBefore(panel, view.firstElementChild);
    $('saveJsonPermissionBtn').onclick = saveJsonPermissions;
  }
  panel.hidden = false;
  const list = $('jsonPermissionList');
  list.innerHTML = '';
  state.users.forEach((user) => {
    const item = document.createElement('label');
    item.className = 'permission-item';
    item.innerHTML = `
      <input class="json-permission-check" type="checkbox" value="${escapeAttr(user.id || '')}" ${user.canViewJson !== false ? 'checked' : ''} ${user.role === 'super' ? 'disabled' : ''}>
      <span>
        <strong>${escapeHtml(user.displayName || user.username || '')}</strong>
        <small>${escapeHtml(user.username || '')} · ${user.role === 'super' ? '总管理员默认可见' : '普通用户'}</small>
      </span>
    `;
    list.appendChild(item);
  });
}

function renderApp() {
  ensureExeMetaFields();
  ensureUpdateFields();
  ensureThemeSelect();
  organizeOverviewCards();
  const app = state.config.app || {};
  $('appTitle').value = app.title || '';
  $('appSubtitle').value = app.subtitle || '';
  $('appVersion').value = app.version || '';
  $('appTheme').value = app.theme || '午夜靛蓝';
  $('appThemeCount').value = app.theme_count || 19;
  $('appAllowClientTheme').checked = app.allow_client_theme !== false;
  $('appLogo').value = app.logo_text || '';
  $('appIcon').value = app.icon || app.icon_url || '';
  ensureExeIconField();
  $('appExeIcon').value = app.exe_icon || app.exe_icon_url || '';
  $('loginHintInput').value = app.login_hint || '';
  $('appWidth').value = app.window_width || 1080;
  $('appHeight').value = app.window_height || 700;
  $('appPasswordEnabled').checked = app.password_enabled === undefined ? !!app.password : !!app.password_enabled;
  $('appPassword').value = '';
  $('appPassword').disabled = !$('appPasswordEnabled').checked;
  $('appUpdateUrl').value = app.update_url || '';
  $('appUpdateTitle').value = app.update_title || '工具箱更新';
  $('appUpdateButton').value = app.update_button || '下载最新版';
  $('appExeTitle').value = app.exe_title || app.title || '';
  $('appExeDescription').value = app.exe_description || app.subtitle || '';
  $('appExeProduct').value = app.exe_product || app.title || '';
  $('appExeCompany').value = app.exe_company || '';
  $('appExeCopyright').value = app.exe_copyright || '';
  $('appExeVersion').value = app.exe_version || app.version || '1.0.0.0';
}

function organizeOverviewCards() {
  const view = $('view-overview');
  const firstPanel = view?.querySelector('.panel');
  const grid = firstPanel?.querySelector('.form-grid');
  if (!view || !firstPanel || !grid || $('appPropertyPanel')) return;
  firstPanel.querySelector('h2').textContent = '基础信息';

  const saveButton = $('saveAppBtn');
  const saveBar = document.createElement('div');
  saveBar.className = 'overview-savebar';
  if (saveButton) {
    saveButton.remove();
    saveBar.appendChild(saveButton);
  }
  view.insertBefore(saveBar, view.querySelector('.stats'));

  const passwordPanel = createOverviewPanel('启动密码', 'appPasswordPanel');
  const propertyPanel = createOverviewPanel('EXE 属性', 'appPropertyPanel');
  const updatePanel = createOverviewPanel('更新入口', 'appUpdatePanel');
  view.insertBefore(passwordPanel, saveBar);
  view.insertBefore(propertyPanel, saveBar);
  view.insertBefore(updatePanel, saveBar);

  moveLabels(grid, passwordPanel.querySelector('.form-grid'), ['appPasswordEnabled', 'appPassword']);
  moveLabels(grid, propertyPanel.querySelector('.form-grid'), ['appExeTitle', 'appExeDescription', 'appExeProduct', 'appExeVersion', 'appExeCompany', 'appExeCopyright']);
  moveLabels(grid, updatePanel.querySelector('.form-grid'), ['appUpdateUrl', 'appUpdateTitle', 'appUpdateButton']);
}

function createOverviewPanel(title, id) {
  const panel = document.createElement('div');
  panel.className = 'panel';
  panel.id = id;
  panel.innerHTML = `<div class="panel-head"><h2>${title}</h2></div><div class="form-grid"></div>`;
  return panel;
}

function moveLabels(sourceGrid, targetGrid, ids) {
  ids.forEach((id) => {
    const el = $(id);
    const label = el?.closest('label');
    if (label) targetGrid.appendChild(label);
  });
}

function ensureThemeSelect() {
  const input = $('appTheme');
  if (!input) return;
  if (!$('appThemeCount')) {
    const themeLabel = input.closest('label');
    const countLabel = document.createElement('label');
    countLabel.innerHTML = '工具箱可显示主题数<input id="appThemeCount" type="number" min="1" max="19" placeholder="最多 19 个">';
    themeLabel.insertAdjacentElement('afterend', countLabel);
    const allowLabel = document.createElement('label');
    allowLabel.className = 'toggle-line';
    allowLabel.innerHTML = '工具箱同步可自行修改主题<span><input id="appAllowClientTheme" type="checkbox"> 启用</span>';
    countLabel.insertAdjacentElement('afterend', allowLabel);
  }
  if (input.tagName === 'SELECT') return;
  const select = document.createElement('select');
  select.id = 'appTheme';
  [
    ['午夜靛蓝', '午夜靛蓝'],
    ['海雾蓝湖', '海雾蓝湖'],
    ['冰川浅蓝', '冰川浅蓝'],
    ['钻蓝冷辉', '钻蓝冷辉'],
    ['晴空蓝白', '晴空蓝白'],
    ['森境青绿', '森境青绿'],
    ['翡翠冷绿', '翡翠冷绿'],
    ['极光青碧', '极光青碧'],
    ['落日绯红', '落日绯红'],
    ['玫瑰粉雾', '玫瑰粉雾'],
    ['樱雾浅粉', '樱雾浅粉'],
    ['蓝雾淡紫', '蓝雾淡紫'],
    ['星云紫幕', '星云紫幕'],
    ['霓虹电缎', '霓虹电缎'],
    ['墨金深空', '墨金深空'],
    ['暖棕咖啡', '暖棕咖啡'],
    ['余烬橙焰', '余烬橙焰'],
    ['沙丘金黄', '沙丘金黄'],
    ['银光素白', '银光素白']
  ].forEach(([value, label]) => {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = label;
    select.appendChild(option);
  });
  input.replaceWith(select);
}

function ensureExeMetaFields() {
  if ($('appExeTitle')) return;
  const grid = $('appPassword')?.closest('.form-grid');
  if (!grid) return;
  const fields = [
    ['appExeTitle', 'EXE 文件说明', '属性里显示的文件说明'],
    ['appExeDescription', 'EXE 介绍', '属性里的说明/介绍'],
    ['appExeProduct', 'EXE 产品名称', '属性里的产品名称'],
    ['appExeVersion', 'EXE 文件版本', '例如：1.0.0.0'],
    ['appExeCompany', 'EXE 公司名称', '可留空'],
    ['appExeCopyright', 'EXE 版权', '例如：Copyright © 2026']
  ];
  fields.forEach(([id, labelText, placeholder]) => {
    const label = document.createElement('label');
    label.innerHTML = `${labelText}<input id="${id}" placeholder="${placeholder}">`;
    grid.appendChild(label);
  });
}

function ensureExeIconField() {
  if ($('appExeIcon')) return;
  const appIcon = $('appIcon');
  const grid = appIcon?.closest('.form-grid');
  if (!grid) return;
  const label = document.createElement('label');
  label.className = 'wide';
  label.innerHTML = 'EXE 图标链接<input id="appExeIcon" placeholder="建议填 .ico 或 PNG 图床链接，生成工具箱时使用">';
  appIcon.closest('label').insertAdjacentElement('afterend', label);
}

function ensureUpdateFields() {
  if ($('appUpdateUrl')) return;
  const grid = $('appPassword')?.closest('.form-grid');
  if (!grid) return;
  const updateUrl = document.createElement('label');
  updateUrl.className = 'wide';
  updateUrl.innerHTML = '工具箱更新链接<input id="appUpdateUrl" placeholder="粘贴新版 EXE 下载地址，留空不显示更新入口">';
  const updateTitle = document.createElement('label');
  updateTitle.innerHTML = '更新入口标题<input id="appUpdateTitle" placeholder="例如：工具箱更新">';
  const updateButton = document.createElement('label');
  updateButton.innerHTML = '更新按钮文字<input id="appUpdateButton" placeholder="例如：下载最新版">';
  grid.appendChild(updateUrl);
  grid.appendChild(updateTitle);
  grid.appendChild(updateButton);
}

function renderAccount() {
  const user = state.currentUser || {};
  $('accountUsername').value = user.username || '';
  $('accountEmail').value = user.email || '';
  $('accountDisplayName').value = user.displayName || '';
  $('accountCurrentPassword').value = '';
  $('accountNewPassword').value = '';
}

function renderMailSettings() {
  if (state.currentUser?.role !== 'super' || !state.mail) return;
  $('mailHost').value = state.mail.host || '';
  $('mailPort').value = state.mail.port || 465;
  $('mailUser').value = state.mail.user || '';
  $('mailFrom').value = state.mail.from || '';
  $('mailPassword').value = '';
  $('mailSecure').checked = state.mail.secure !== false;
  $('mailStatusText').value = state.mail.hasPassword ? '已保存 SMTP 密码' : '未保存 SMTP 密码';
}

async function saveMailSettings() {
  const body = {
    host: $('mailHost').value.trim(),
    port: Number($('mailPort').value || 465),
    user: $('mailUser').value.trim(),
    from: $('mailFrom').value.trim(),
    password: $('mailPassword').value,
    secure: $('mailSecure').checked
  };
  state.mail = await api('/api/super/mail', {
    method: 'PATCH',
    body: JSON.stringify(body)
  });
  renderMailSettings();
  setStatus('邮箱设置已保存。');
}

async function testMailSettings() {
  const email = $('mailTestTo').value.trim();
  if (!email) {
    setStatus('请输入测试收件邮箱。', true);
    return;
  }
  await api('/api/super/mail/test', {
    method: 'POST',
    body: JSON.stringify({ email })
  });
  setStatus('测试邮件已发送。');
}

async function saveAccount() {
  const body = {
    username: $('accountUsername').value.trim(),
    email: $('accountEmail').value.trim(),
    displayName: $('accountDisplayName').value.trim()
  };
  const newPassword = $('accountNewPassword').value;
  if (newPassword) {
    body.currentPassword = $('accountCurrentPassword').value;
    body.password = newPassword;
  }
  const result = await api('/api/admin/account', {
    method: 'PATCH',
    body: JSON.stringify(body)
  });
  state.currentUser = result.user;
  $('currentUserLabel').textContent = `${state.currentUser.displayName || state.currentUser.username}（${state.currentUser.role === 'super' ? '总管理员' : '用户'}）`;
  renderAccount();
  setStatus('账号已保存。');
}

function renderUsers() {
  const tbody = $('userRows');
  if (!tbody) return;
  tbody.innerHTML = '';

  if (state.currentUser?.role !== 'super') return;
  const tableWrap = tbody.closest('.table-wrap');
  if (tableWrap) tableWrap.hidden = true;
  const panel = tbody.closest('.panel');
  let cards = $('userCards');
  if (!cards && panel) {
    cards = document.createElement('div');
    cards.id = 'userCards';
    cards.className = 'user-card-list';
    panel.appendChild(cards);
  }
  ensureUserBatchTools(panel);
  if (!cards) return;
  cards.innerHTML = '';

  state.users.forEach((user) => {
    const endpoint = `${location.origin}/api/toolbox/config?key=${encodeURIComponent(user.apiKey || '')}`;
    const card = document.createElement('div');
    card.className = 'user-card';
    card.dataset.userId = user.id;
    card.innerHTML = `
      <div class="user-card-main">
        <input class="user-check" type="checkbox" value="${escapeAttr(user.id || '')}" ${user.id === 'admin' ? 'disabled' : ''}>
        <button class="user-expand" type="button">▸</button>
        <div class="user-avatar">${escapeHtml((user.displayName || user.username || 'U').slice(0, 1).toUpperCase())}</div>
        <div class="user-summary">
          <strong>${escapeHtml(user.displayName || user.username || '')}</strong>
          <span>${escapeHtml(user.username || '')} · ${escapeHtml(user.email || '未填写邮箱')}</span>
        </div>
        <span class="pill">${user.role === 'super' ? '总管理员' : '普通用户'}</span>
        <span class="pill ${user.active === false ? 'danger-pill' : ''}">${user.active === false ? '已停用' : '正常'}</span>
        <span class="pill ${user.canViewJson === false ? 'muted-pill' : ''}">JSON ${user.canViewJson === false ? '不可见' : '可见'}</span>
      </div>
      <div class="user-card-detail" hidden>
        <div class="form-grid">
          <label>账号<input data-field="username" value="${escapeAttr(user.username || '')}"><small>${escapeHtml(user.id || '')}</small></label>
          <label>邮箱<input data-field="email" type="email" value="${escapeAttr(user.email || '')}"></label>
          <label>显示名称<input data-field="displayName" value="${escapeAttr(user.displayName || '')}"></label>
          <label>角色
            <select data-field="role">
              <option value="user" ${user.role !== 'super' ? 'selected' : ''}>普通用户</option>
              <option value="super" ${user.role === 'super' ? 'selected' : ''}>总管理员</option>
            </select>
          </label>
          <label>新密码<input data-field="password" type="password" placeholder="留空不修改"></label>
          <label class="toggle-line">JSON 管理<span><input data-field="canViewJson" type="checkbox" ${user.canViewJson !== false ? 'checked' : ''} ${user.role === 'super' ? 'disabled' : ''}> 可查看</span></label>
          <label class="wide">工具箱对接地址<input class="user-endpoint" readonly value="${escapeAttr(endpoint)}"></label>
        </div>
        <div class="card-actions">
          <button data-action="download">下载工具箱</button>
          <button data-action="save">保存</button>
          <button data-action="reset-key">重置地址</button>
          <button class="danger" data-action="delete" ${user.id === 'admin' ? 'disabled' : ''}>删除</button>
        </div>
      </div>
    `;
    card.querySelector('.user-expand').onclick = () => {
      const detail = card.querySelector('.user-card-detail');
      const open = detail.hidden;
      detail.hidden = !open;
      card.querySelector('.user-expand').textContent = open ? '▾' : '▸';
    };
    card.querySelector('[data-action="download"]').onclick = () => downloadClient(user.id);
    card.querySelector('[data-action="save"]').onclick = () => saveUser(user.id, card);
    card.querySelector('[data-action="reset-key"]').onclick = () => resetUserApiKey(user.id);
    card.querySelector('[data-action="delete"]').onclick = () => deleteUser(user.id, user.username);
    cards.appendChild(card);
  });
}

function ensureUserBatchTools(panel) {
  if (!panel || $('userBatchBar')) return;
  const bar = document.createElement('div');
  bar.id = 'userBatchBar';
  bar.className = 'batch-bar';
  bar.innerHTML = `
    <label class="checkline"><input id="userSelectAll" type="checkbox"> 全选</label>
    <button data-user-batch="enable">批量启用</button>
    <button data-user-batch="disable">批量停用</button>
    <button data-user-batch="allow_json">允许 JSON</button>
    <button data-user-batch="deny_json">禁止 JSON</button>
    <button class="danger" data-user-batch="delete">批量删除</button>
  `;
  const head = panel.querySelector('.panel-head');
  head?.insertAdjacentElement('afterend', bar);
  $('userSelectAll').onchange = (event) => {
    document.querySelectorAll('.user-check:not(:disabled)').forEach((box) => { box.checked = event.target.checked; });
  };
  bar.querySelectorAll('[data-user-batch]').forEach((button) => {
    button.onclick = () => batchUsers(button.dataset.userBatch);
  });
}

function renderInvites() {
  const tbody = $('inviteRows');
  if (!tbody) return;
  ensureInviteTools();
  tbody.innerHTML = '';

  if (state.currentUser?.role !== 'super') return;

  state.invites.forEach((invite) => {
    const usedBy = (invite.usedBy || [])
      .map((item) => `${item.username || item.userId || ''} ${item.usedAt ? new Date(item.usedAt).toLocaleString() : ''}`)
      .join('；');
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><input type="checkbox" class="invite-check" value="${escapeAttr(invite.code || '')}"></td>
      <td><input readonly class="invite-code" value="${escapeAttr(invite.code || '')}"></td>
      <td>${invite.active ? '可用' : '已停用'}</td>
      <td>${Number(invite.usedCount || 0)} / ${Number(invite.maxUses || 1)}</td>
      <td>${escapeHtml(usedBy || '暂无')}</td>
      <td class="actions">
        <button data-invite-action="copy">复制</button>
        <button data-invite-action="toggle">${invite.active ? '停用' : '启用'}</button>
        <button data-invite-action="delete" class="danger">删除</button>
      </td>
    `;
    tr.dataset.inviteCode = invite.code || '';
    tr.dataset.inviteActive = invite.active ? '1' : '0';
    tbody.appendChild(tr);
  });

  tbody.querySelectorAll('[data-invite-action]').forEach((button) => {
    button.onclick = () => {
      const row = button.closest('tr');
      const code = row.dataset.inviteCode;
      const action = button.dataset.inviteAction;
      if (action === 'copy') copyText(code);
      if (action === 'toggle') toggleInvite(code, row.dataset.inviteActive !== '1').catch((error) => setStatus(error.message, true));
      if (action === 'delete') deleteInvite(code).catch((error) => setStatus(error.message, true));
    };
  });
}

function renderStats() {
  $('statPages').textContent = Object.keys(state.config.pages || {}).length;
  $('statTabs').textContent = (state.config.toolbox_tabs || []).length;
  $('statButtons').textContent = state.buttons.length;
}

function getPositions() {
  const positions = [];

  Object.entries(state.config.pages || {}).forEach(([pageId, page]) => {
    positions.push({
      value: `page:${pageId}`,
      scope: 'page',
      pageId,
      label: `页面 / ${page.title || pageId}`,
      name: page.title || pageId,
      container: page
    });
  });

  (state.config.toolbox_tabs || []).forEach((tab, index) => {
    positions.push({
      value: `toolbox:${index}`,
      scope: 'toolbox',
      tabIndex: index,
      label: `系统工具 / ${tab.name || index + 1}`,
      name: tab.name || `系统工具 ${index + 1}`,
      container: tab
    });
  });

  return positions;
}

function parsePositionValue(value) {
  const positions = getPositions();
  return positions.find((item) => item.value === value) || positions[0] || null;
}

function ensureSections(container) {
  if (!container.sections || !Array.isArray(container.sections)) {
    container.sections = [];
  }
  if (!container.sections.length) {
    container.sections.push({ title: '默认分组', buttons: [] });
  }
  container.sections.forEach((section) => {
    if (!Array.isArray(section.buttons)) section.buttons = [];
  });
  return container.sections;
}

function renderManageControls() {
  const scope = $('manageScope');
  if (!scope) return;

  const previous = scope.value;
  const positions = getPositions();
  scope.innerHTML = '';

  positions.forEach((item) => {
    const opt = document.createElement('option');
    opt.value = item.value;
    opt.textContent = item.label;
    scope.appendChild(opt);
  });

  if (positions.some((item) => item.value === previous)) {
    scope.value = previous;
  }

  scope.onchange = renderManagedSections;
  renderManagedSections();
}

function renderManagedSections() {
  const pos = parsePositionValue($('manageScope')?.value || '');
  const sectionSelect = $('manageSection');
  if (!pos || !sectionSelect) return;

  $('manageScopeName').value = pos.name || '';
  const previous = sectionSelect.value;
  const sections = ensureSections(pos.container);
  sectionSelect.innerHTML = '';

  sections.forEach((section, index) => {
    const opt = document.createElement('option');
    opt.value = String(index);
    opt.textContent = section.title || `默认分组 ${index + 1}`;
    sectionSelect.appendChild(opt);
  });

  if ([...sectionSelect.options].some((option) => option.value === previous)) {
    sectionSelect.value = previous;
  }

  sectionSelect.onchange = renderManagedSectionName;
  renderManagedSectionName();
}

function renderManagedSectionName() {
  const pos = parsePositionValue($('manageScope')?.value || '');
  if (!pos) return;
  const sectionIndex = Number($('manageSection').value || 0);
  const section = ensureSections(pos.container)[sectionIndex];
  $('manageSectionName').value = section ? (section.title || '') : '';
}

function renderSelectors() {
  const scope = $('addScope');
  scope.innerHTML = '';

  getPositions().forEach((item) => {
    const opt = document.createElement('option');
    opt.value = item.value;
    opt.textContent = item.label;
    scope.appendChild(opt);
  });

  scope.onchange = renderSectionSelector;
  renderSectionSelector();
}

function renderSectionSelector() {
  const section = $('addSection');
  const target = currentAddTarget();
  section.innerHTML = '';

  const sections = target?.sections || [];
  sections.forEach((sec, index) => {
    const opt = document.createElement('option');
    opt.value = String(index);
    opt.textContent = sec.title || `默认分组 ${index + 1}`;
    section.appendChild(opt);
  });

  if (!sections.length) {
    const opt = document.createElement('option');
    opt.value = '0';
    opt.textContent = '默认分组';
    section.appendChild(opt);
  }
}

function currentAddTarget() {
  const raw = $('addScope').value;
  if (!raw) return null;
  const [scope, id] = raw.split(':');
  if (scope === 'toolbox') {
    return state.config.toolbox_tabs?.[Number(id)];
  }
  return state.config.pages?.[id];
}

function renderButtons() {
  const tbody = $('buttonRows');
  const query = ($('buttonSearch').value || '').trim().toLowerCase();
  ensureButtonSortUi();
  ensureButtonFilters();
  renderButtonFilterOptions();
  const areaFilter = $('buttonAreaFilter')?.value || '';
  const sectionFilter = $('buttonSectionFilter')?.value || '';
  const actionFilter = $('buttonActionFilter')?.value || '';
  tbody.innerHTML = '';

  state.buttons
    .slice()
    .sort((a, b) =>
      String(a.area || '').localeCompare(String(b.area || ''), 'zh-Hans-CN') ||
      String(a.section || '').localeCompare(String(b.section || ''), 'zh-Hans-CN') ||
      Number(a.sort ?? a.raw?.sort ?? 0) - Number(b.sort ?? b.raw?.sort ?? 0) ||
      Number(a.buttonIndex || 0) - Number(b.buttonIndex || 0)
    )
    .filter((button) => {
      const targetLabel = displayTarget(button);
      const actionLabel = ACTION_LABELS[button.action] || button.action;
      const haystack = `${button.area} ${button.section} ${button.name} ${button.icon || ''} ${button.action} ${actionLabel} ${button.target} ${targetLabel}`.toLowerCase();
      if (areaFilter && button.area !== areaFilter) return false;
      if (sectionFilter && button.section !== sectionFilter) return false;
      if (actionFilter && button.action !== actionFilter) return false;
      return !query || haystack.includes(query);
    })
    .forEach((button) => {
      const icon = button.icon || button.raw?.icon || '';
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${escapeHtml(button.area || '')}<small>${escapeHtml(button.section || '')}</small></td>
        <td><input class="sort-input" type="number" value="${escapeAttr(button.sort ?? button.raw?.sort ?? 0)}" data-field="sort" title="数字越小越靠前"></td>
        <td><input value="${escapeAttr(button.name || '')}" data-field="name"></td>
        <td>
          <div class="icon-field">
            <span class="icon-preview">${icon ? `<img src="${escapeAttr(icon)}" alt="">` : ''}</span>
            <input value="${escapeAttr(icon)}" data-field="icon" placeholder="图床图片链接">
          </div>
        </td>
        <td><input value="${escapeAttr(button.raw?.description || button.raw?.intro || button.raw?.remark || '')}" data-field="description" placeholder="鼠标悬停说明"></td>
        <td>
          <select data-field="action">
            ${ACTIONS.map(([action, label]) =>
              `<option value="${action}" ${action === button.action ? 'selected' : ''}>${label}</option>`
            ).join('')}
          </select>
        </td>
        <td>
          <input class="target-input" value="${escapeAttr(displayTarget(button))}" data-field="target" title="${escapeAttr(button.target || '')}">
          <small class="target-note"></small>
        </td>
        <td class="actions">
          <button data-action="save">保存</button>
          <button class="danger" data-action="delete">删除</button>
        </td>
      `;

      updateRowTargetState(tr, button);
      tr.querySelector('[data-field="action"]').onchange = () => updateRowTargetState(tr, button);
      tr.querySelector('[data-field="icon"]').oninput = () => updateIconPreview(tr);
      tr.querySelector('[data-action="save"]').onclick = () => saveButton(button, tr);
      tr.querySelector('[data-action="delete"]').onclick = () => deleteButton(button);
      tbody.appendChild(tr);
    });
}

function ensureButtonSortUi() {
  const addName = $('addName');
  if (addName && !$('addSort')) {
    const label = document.createElement('label');
    label.innerHTML = '排序<input id="addSort" type="number" value="0" placeholder="越小越靠前">';
    addName.closest('label')?.insertAdjacentElement('beforebegin', label);
  }

  const headRow = document.querySelector('#buttonRows')?.closest('table')?.querySelector('thead tr');
  if (headRow && !headRow.querySelector('[data-sort-head]')) {
    const th = document.createElement('th');
    th.dataset.sortHead = '1';
    th.textContent = '排序';
    const nameHead = headRow.children[1];
    headRow.insertBefore(th, nameHead || null);
  }
}

function ensureButtonFilters() {
  const search = $('buttonSearch');
  if (!search || $('buttonFilterBar')) return;
  const bar = document.createElement('div');
  bar.id = 'buttonFilterBar';
  bar.className = 'button-filters';
  const area = document.createElement('select');
  area.id = 'buttonAreaFilter';
  const section = document.createElement('select');
  section.id = 'buttonSectionFilter';
  const action = document.createElement('select');
  action.id = 'buttonActionFilter';
  bar.appendChild(area);
  bar.appendChild(section);
  bar.appendChild(action);
  search.parentElement.insertBefore(bar, search);
  bar.appendChild(search);
  [area, section, action].forEach((select) => {
    select.onchange = renderButtons;
  });
}

function renderButtonFilterOptions() {
  const area = $('buttonAreaFilter');
  const section = $('buttonSectionFilter');
  const action = $('buttonActionFilter');
  if (!area || !section || !action) return;
  fillFilterOptions(area, '全部位置', uniqueSorted(state.buttons.map((button) => button.area || '')));
  fillFilterOptions(section, '全部分组', uniqueSorted(state.buttons.map((button) => button.section || '')));
  fillFilterOptions(action, '全部动作', ACTIONS.map(([value, label]) => ({ value, label })));
}

function fillFilterOptions(select, allLabel, items) {
  const previous = select.value;
  select.innerHTML = `<option value="">${allLabel}</option>`;
  items.forEach((item) => {
    const value = typeof item === 'string' ? item : item.value;
    const label = typeof item === 'string' ? item : item.label;
    if (!value) return;
    const opt = document.createElement('option');
    opt.value = value;
    opt.textContent = label || value;
    select.appendChild(opt);
  });
  select.value = [...select.options].some((option) => option.value === previous) ? previous : '';
}

function uniqueSorted(values) {
  return [...new Set(values.filter(Boolean))].sort((a, b) => a.localeCompare(b, 'zh-Hans-CN'));
}

function updateIconPreview(row) {
  const input = row.querySelector('[data-field="icon"]');
  const preview = row.querySelector('.icon-preview');
  const url = input.value.trim();
  preview.innerHTML = url ? `<img src="${escapeAttr(url)}" alt="">` : '';
}

function displayTarget(button) {
  if (button.action === 'script') {
    return SCRIPT_LABELS[button.target] || button.target || '';
  }
  return button.target || '';
}

function updateRowTargetState(row, button) {
  const action = row.querySelector('[data-field="action"]').value;
  const target = row.querySelector('[data-field="target"]');
  const note = row.querySelector('.target-note');
  const rawTarget = target.dataset.rawTarget || button.target || '';

  if (action === 'script') {
    target.dataset.rawTarget = rawTarget;
    target.value = SCRIPT_LABELS[rawTarget] || rawTarget;
    target.readOnly = true;
    target.classList.add('readonly-target');
    note.textContent = '';
    return;
  }

  if (target.readOnly) {
    target.value = rawTarget;
  }
  target.readOnly = false;
  target.classList.remove('readonly-target');
  note.textContent = '';
}

async function saveApp() {
  const passwordEnabled = $('appPasswordEnabled').checked;
  const newPassword = $('appPassword').value.trim();
  const hasExistingPassword = !!(state.config.app && state.config.app.password);

  if (passwordEnabled && !hasExistingPassword && !newPassword) {
    setStatus('开启工具箱密码时，请先填写新密码。', true);
    return;
  }

  const patch = {
    title: $('appTitle').value.trim(),
    subtitle: $('appSubtitle').value.trim(),
    version: $('appVersion').value.trim(),
    theme: $('appTheme').value.trim(),
    theme_count: Math.max(1, Math.min(19, Number($('appThemeCount')?.value || 19))),
    allow_client_theme: $('appAllowClientTheme')?.checked !== false,
    logo_text: $('appLogo').value.trim(),
    icon: $('appIcon').value.trim(),
    exe_icon: $('appExeIcon')?.value.trim() || '',
    login_hint: $('loginHintInput').value.trim(),
    window_width: Number($('appWidth').value || 1080),
    window_height: Number($('appHeight').value || 700),
    password_enabled: passwordEnabled,
    update_url: $('appUpdateUrl')?.value.trim() || '',
    update_title: $('appUpdateTitle')?.value.trim() || '工具箱更新',
    update_button: $('appUpdateButton')?.value.trim() || '下载最新版',
    exe_title: $('appExeTitle')?.value.trim() || '',
    exe_description: $('appExeDescription')?.value.trim() || '',
    exe_product: $('appExeProduct')?.value.trim() || '',
    exe_company: $('appExeCompany')?.value.trim() || '',
    exe_copyright: $('appExeCopyright')?.value.trim() || '',
    exe_version: $('appExeVersion')?.value.trim() || ''
  };

  if (newPassword) {
    patch.password = newPassword;
  }

  state.config = await api('/api/admin/app', {
    method: 'PATCH',
    body: JSON.stringify(patch)
  });
  await refreshButtons('应用信息已保存。');
}

async function saveWholeConfig(message) {
  await api('/api/admin/config', {
    method: 'PUT',
    body: JSON.stringify(state.config)
  });
  await reloadConfigAndButtons(message);
}

function newConfigId(prefix) {
  return `${prefix}_${Date.now().toString(36)}`;
}

async function addPosition() {
  const name = $('newScopeName').value.trim();
  const type = $('newScopeType').value;
  if (!name) {
    setStatus('先填写新增位置名称。', true);
    return;
  }

  if (type === 'toolbox') {
    if (!Array.isArray(state.config.toolbox_tabs)) state.config.toolbox_tabs = [];
    state.config.toolbox_tabs.push({
      id: newConfigId('tab'),
      name,
      sections: [{ title: '默认分组', buttons: [] }]
    });
  } else {
    const id = newConfigId('page');
    if (!Array.isArray(state.config.sidebar)) state.config.sidebar = [];
    if (!state.config.pages || typeof state.config.pages !== 'object') state.config.pages = {};
    state.config.sidebar.push({ id, name });
    state.config.pages[id] = {
      title: name,
      sections: [{ title: '默认分组', buttons: [] }]
    };
  }

  $('newScopeName').value = '';
  await saveWholeConfig('位置已新增。');
}

async function renamePosition() {
  const pos = parsePositionValue($('manageScope').value);
  const name = $('manageScopeName').value.trim();
  if (!pos || !name) {
    setStatus('先选择位置并填写名称。', true);
    return;
  }

  if (pos.scope === 'toolbox') {
    state.config.toolbox_tabs[pos.tabIndex].name = name;
  } else {
    state.config.pages[pos.pageId].title = name;
    const sidebarItem = (state.config.sidebar || []).find((item) => item.id === pos.pageId);
    if (sidebarItem) sidebarItem.name = name;
  }

  await saveWholeConfig('位置名称已保存。');
}

async function deletePosition() {
  const pos = parsePositionValue($('manageScope').value);
  if (!pos) return;
  if (!confirm(`删除位置「${pos.name}」以及里面的所有按钮？`)) return;

  if (pos.scope === 'toolbox') {
    state.config.toolbox_tabs.splice(pos.tabIndex, 1);
  } else {
    delete state.config.pages[pos.pageId];
    state.config.sidebar = (state.config.sidebar || []).filter((item) => item.id !== pos.pageId);
  }

  await saveWholeConfig('位置已删除。');
}

async function addSection() {
  const pos = parsePositionValue($('manageScope').value);
  const name = $('newSectionName').value.trim() || '默认分组';
  if (!pos) return;

  ensureSections(pos.container).push({ title: name, buttons: [] });
  $('newSectionName').value = '';
  await saveWholeConfig('分组已新增。');
}

async function renameSection() {
  const pos = parsePositionValue($('manageScope').value);
  if (!pos) return;
  const sectionIndex = Number($('manageSection').value || 0);
  const section = ensureSections(pos.container)[sectionIndex];
  if (!section) return;

  section.title = $('manageSectionName').value.trim();
  await saveWholeConfig('分组名称已保存。');
}

async function deleteSection() {
  const pos = parsePositionValue($('manageScope').value);
  if (!pos) return;
  const sections = ensureSections(pos.container);
  const sectionIndex = Number($('manageSection').value || 0);
  const section = sections[sectionIndex];
  if (!section) return;

  const title = section.title || `默认分组 ${sectionIndex + 1}`;
  const count = (section.buttons || []).length;
  if (!confirm(`删除分组「${title}」？里面有 ${count} 个按钮。`)) return;

  sections.splice(sectionIndex, 1);
  if (!sections.length) {
    sections.push({ title: '默认分组', buttons: [] });
  }

  await saveWholeConfig('分组已删除。');
}

async function addButton() {
  const [scope, id] = $('addScope').value.split(':');
  const name = $('addName').value.trim();
  const icon = $('addIcon').value.trim();
  const description = $('addDescription').value.trim();
  const sort = Number($('addSort')?.value || 0);
  const action = $('addAction').value;
  const target = $('addTarget').value.trim();
  if (!name) {
    setStatus('请先填写按钮名称。', true);
    return;
  }
  if (!target && !description && !icon) {
    setStatus('请至少填写网址/内容、介绍或图标。', true);
    return;
  }
  const request = {
    scope,
    sectionIndex: Number($('addSection').value || 0),
    button: {
      name,
      sort,
      icon,
      description,
      action,
      target
    }
  };

  if (scope === 'toolbox') request.tabIndex = Number(id);
  else request.pageId = id;

  await api('/api/admin/buttons', {
    method: 'POST',
    body: JSON.stringify(request)
  });

  $('addName').value = '';
  if ($('addSort')) $('addSort').value = '0';
  $('addIcon').value = '';
  $('addDescription').value = '';
  $('addTarget').value = '';
  await reloadConfigAndButtons('按钮已新增。');
}

async function saveButton(ref, row) {
  const request = {
    id: ref.id,
    scope: ref.scope,
    pageId: ref.pageId,
    tabIndex: ref.tabIndex,
    sectionIndex: ref.sectionIndex,
    buttonIndex: ref.buttonIndex,
    button: {
      name: row.querySelector('[data-field="name"]').value.trim(),
      sort: Number(row.querySelector('[data-field="sort"]')?.value || 0),
      icon: row.querySelector('[data-field="icon"]').value.trim(),
      description: row.querySelector('[data-field="description"]').value.trim(),
      action: row.querySelector('[data-field="action"]').value,
      target: readRowTarget(row)
    }
  };

  await api('/api/admin/buttons', {
    method: 'PATCH',
    body: JSON.stringify(request)
  });
  await reloadConfigAndButtons('按钮已保存。');
}

function readRowTarget(row) {
  const action = row.querySelector('[data-field="action"]').value;
  const target = row.querySelector('[data-field="target"]');
  if (action === 'script') {
    return target.dataset.rawTarget || target.value.trim();
  }
  return target.value.trim();
}

async function deleteButton(ref) {
  if (!confirm(`删除按钮「${ref.name}」？`)) return;

  await api('/api/admin/buttons', {
    method: 'DELETE',
    body: JSON.stringify({
      scope: ref.scope,
      pageId: ref.pageId,
      tabIndex: ref.tabIndex,
      sectionIndex: ref.sectionIndex,
      buttonIndex: ref.buttonIndex
    })
  });
  await reloadConfigAndButtons('按钮已删除。');
}

async function addUser() {
  const username = $('newUsername').value.trim();
  const email = $('newUserEmail').value.trim();
  const displayName = $('newDisplayName').value.trim();
  const password = $('newUserPassword').value.trim();
  const role = $('newUserRole').value;

  if (!username || !password) {
    setStatus('用户名和初始密码不能为空。', true);
    return;
  }

  await api('/api/super/users', {
    method: 'POST',
    body: JSON.stringify({ username, email, displayName, password, role })
  });

  $('newUsername').value = '';
  $('newUserEmail').value = '';
  $('newDisplayName').value = '';
  $('newUserPassword').value = '';
  await loadUsers();
  renderUserContext();
  setStatus('用户已创建。');
}

async function createInvite() {
  const prefix = $('newInviteCode').value.trim();
  const maxUses = Number($('newInviteMaxUses').value || 1);
  const count = Number($('newInviteCount')?.value || 1);
  const retentionDays = Number($('newInviteRetentionDays')?.value || 7);

  await api('/api/super/invites', {
    method: 'POST',
    body: JSON.stringify({ prefix, count, maxUses, retentionDays })
  });

  $('newInviteCode').value = '';
  if ($('newInviteCount')) $('newInviteCount').value = '1';
  if ($('newInviteRetentionDays')) $('newInviteRetentionDays').value = '7';
  $('newInviteMaxUses').value = '1';
  await loadInvites();
  renderInvites();
  setStatus(`邀请码已生成 ${Math.max(1, count)} 个。`);
}

function ensureInviteTools() {
  const table = $('inviteRows')?.closest('table');
  if (table && !table.dataset.inviteSelectReady) {
    const headRow = table.querySelector('thead tr');
    if (headRow) {
      const th = document.createElement('th');
      th.innerHTML = '<input id="inviteSelectAll" type="checkbox">';
      headRow.insertBefore(th, headRow.firstElementChild);
      table.dataset.inviteSelectReady = '1';
      th.querySelector('input').onchange = (event) => {
        document.querySelectorAll('.invite-check').forEach((box) => {
          box.checked = event.target.checked;
        });
      };
    }
  }

  const prefixInput = $('newInviteCode');
  if (prefixInput && !prefixInput.dataset.prefixReady) {
    prefixInput.placeholder = '例如：YQ，系统自动补随机码';
    prefixInput.closest('label').childNodes[0].textContent = '邀请码前缀';
    const countLabel = document.createElement('label');
    countLabel.textContent = '生成数量';
    countLabel.innerHTML = '生成数量<input id="newInviteCount" type="number" min="1" max="200" value="1">';
    prefixInput.closest('.invite-create').appendChild(countLabel);
    const retentionLabel = document.createElement('label');
    retentionLabel.innerHTML = '使用后保留天数<input id="newInviteRetentionDays" type="number" min="0" value="7">';
    prefixInput.closest('.invite-create').appendChild(retentionLabel);
    prefixInput.dataset.prefixReady = '1';
  }

  const panelHead = $('createInviteBtn')?.closest('.panel-head');
  if (panelHead && !$('exportInvitesBtn')) {
    const exportBtn = document.createElement('button');
    exportBtn.id = 'exportInvitesBtn';
    exportBtn.type = 'button';
    exportBtn.textContent = '导出选中';
    exportBtn.onclick = exportInvites;
    panelHead.insertBefore(exportBtn, $('createInviteBtn'));
    const deleteBtn = document.createElement('button');
    deleteBtn.id = 'deleteSelectedInvitesBtn';
    deleteBtn.type = 'button';
    deleteBtn.className = 'danger';
    deleteBtn.textContent = '删除选中';
    deleteBtn.onclick = deleteSelectedInvites;
    panelHead.insertBefore(deleteBtn, $('createInviteBtn'));
  }
}

function exportInvites() {
  const checked = [...document.querySelectorAll('.invite-check:checked')].map((box) => box.value).filter(Boolean);
  const codes = checked.length ? checked : state.invites.map((invite) => invite.code).filter(Boolean);
  if (!codes.length) {
    setStatus('没有可导出的邀请码。', true);
    return;
  }
  const blob = new Blob([codes.join('\r\n')], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `邀请码-${Date.now()}.txt`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  setStatus(`已导出 ${codes.length} 个邀请码。`);
}

async function toggleInvite(code, active) {
  await api('/api/super/invites', {
    method: 'PATCH',
    body: JSON.stringify({ code, active })
  });
  await loadInvites();
  renderInvites();
  setStatus(active ? '邀请码已启用。' : '邀请码已停用。');
}

async function deleteInvite(code) {
  if (!confirm(`删除邀请码「${code}」？`)) return;
  await api('/api/super/invites', {
    method: 'DELETE',
    body: JSON.stringify({ code })
  });
  await loadInvites();
  renderInvites();
  setStatus('邀请码已删除。');
}

async function deleteSelectedInvites() {
  const codes = [...document.querySelectorAll('.invite-check:checked')].map((box) => box.value).filter(Boolean);
  if (!codes.length) {
    setStatus('请先选择邀请码。', true);
    return;
  }
  if (!confirm(`确定删除选中的 ${codes.length} 个邀请码吗？`)) return;
  await api('/api/super/invites', {
    method: 'DELETE',
    body: JSON.stringify({ codes })
  });
  await loadInvites();
  renderInvites();
  setStatus(`已删除 ${codes.length} 个邀请码。`);
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    showToast('已复制。', 'success');
  } catch {
    showToast('复制失败，请手动复制。', 'error');
  }
}

async function saveUser(userId, row) {
  const body = {
    id: userId,
    username: row.querySelector('[data-field="username"]').value.trim(),
    email: row.querySelector('[data-field="email"]').value.trim(),
    displayName: row.querySelector('[data-field="displayName"]').value.trim(),
    role: row.querySelector('[data-field="role"]').value,
    canViewJson: row.querySelector('[data-field="canViewJson"]')?.checked !== false
  };
  const password = row.querySelector('[data-field="password"]').value.trim();
  if (password) body.password = password;

  await api('/api/super/users', {
    method: 'PATCH',
    body: JSON.stringify(body)
  });

  await loadUsers();
  renderUserContext();
  setStatus('用户已保存。');
}

async function batchUsers(action) {
  const ids = [...document.querySelectorAll('.user-check:checked')].map((box) => box.value).filter(Boolean);
  if (!ids.length) {
    setStatus('请先选择用户。', true);
    return;
  }
  if (action === 'delete' && !confirm(`确定删除选中的 ${ids.length} 个用户吗？`)) return;
  await api('/api/super/users/batch', {
    method: 'POST',
    body: JSON.stringify({ ids, action })
  });
  await loadUsers();
  renderUserContext();
  setStatus(`批量操作完成：${ids.length} 个用户。`);
}

async function saveJsonPermissions() {
  const checks = [...document.querySelectorAll('.json-permission-check')];
  for (const box of checks) {
    const user = state.users.find((item) => item.id === box.value);
    if (!user || user.role === 'super') continue;
    if ((user.canViewJson !== false) === box.checked) continue;
    await api('/api/super/users', {
      method: 'PATCH',
      body: JSON.stringify({ id: user.id, canViewJson: box.checked })
    });
  }
  await loadUsers();
  renderAll();
  setStatus('JSON 查看权限已保存。');
}

async function resetUserApiKey(userId) {
  if (!confirm('重置后，这个用户旧的工具箱对接地址会失效，继续吗？')) return;

  await api('/api/super/users', {
    method: 'PATCH',
    body: JSON.stringify({ id: userId, resetApiKey: true })
  });

  await loadUsers();
  renderUserContext();
  setStatus('用户对接地址已重置。');
}

async function deleteUser(userId, username) {
  if (!confirm(`删除用户「${username}」？他的配置数据不会在界面里显示。`)) return;

  await api('/api/super/users', {
    method: 'DELETE',
    body: JSON.stringify({ id: userId })
  });

  if (state.targetUserId === userId) {
    state.targetUserId = state.currentUser.id;
    localStorage.setItem('toolbox_target_user', state.targetUserId);
  }
  await loadUsers();
  renderUserContext();
  setStatus('用户已删除。');
}

async function downloadClient(userId = '') {
  const headers = authHeaders();
  if (userId) {
    headers['X-Target-User'] = userId;
  }
  delete headers['Content-Type'];

  const params = new URLSearchParams();
  if (userId) params.set('targetUserId', userId);
  params.set('_t', String(Date.now()));
  const suffix = `?${params.toString()}`;
  setStatus('正在生成工具箱 EXE...');
  const res = await fetch(`/api/admin/client/download${suffix}`, { headers });
  const contentType = res.headers.get('content-type') || '';
  if (!res.ok) {
    const text = await res.text();
    const trimmed = text.trim();
    if (contentType.includes('text/html') || trimmed.startsWith('<')) {
      throw new Error('/api/admin/client/download 被返回成网页了。请检查 CDN/反代规则，/api 必须转发到后端，不能走静态页面缓存。');
    }
    if (contentType.includes('application/json') || trimmed.startsWith('{')) {
      const parsed = JSON.parse(trimmed);
      throw new Error(parsed.error || `HTTP ${res.status}`);
    }
    throw new Error(trimmed || `HTTP ${res.status}`);
  }

  const blob = await res.blob();
  if (contentType.includes('text/html') || blob.type.includes('text/html')) {
    throw new Error('/api/admin/client/download 返回了网页，不是 EXE。请关闭 CDN 对 /api 的缓存，并确认反代转发到后端服务。');
  }
  const disposition = res.headers.get('content-disposition') || '';
  const match = disposition.match(/filename="?([^"]+)"?/i);
  const fileName = match ? match[1] : 'toolbox.exe';
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  setStatus('工具箱 EXE 已生成。');
}

async function saveJson() {
  let config;
  try {
    config = JSON.parse($('jsonEditor').value);
  } catch (error) {
    setStatus(`JSON 格式错误：${error.message}`, true);
    return;
  }

  await api('/api/admin/config', {
    method: 'PUT',
    body: JSON.stringify(config)
  });
  await reloadConfigAndButtons('完整配置已保存。');
}

async function refreshButtons(message) {
  state.buttons = await api('/api/admin/buttons');
  renderAll();
  setStatus(message);
}

async function reloadConfigAndButtons(message) {
  state.config = await api('/api/admin/config');
  state.buttons = await api('/api/admin/buttons');
  renderAll();
  setStatus(message);
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[c]));
}

function escapeAttr(value) {
  return escapeHtml(value).replace(/`/g, '&#96;');
}

setupSidebar();

document.querySelectorAll('.nav').forEach((button) => {
  button.onclick = () => {
    switchView(button.dataset.view);
    if (window.matchMedia('(max-width: 900px)').matches) {
      document.body.classList.remove('sidebar-open');
      document.body.classList.add('sidebar-collapsed');
    }
  };
});

$('loginBtn').onclick = () => login();
$('showLoginBtn').onclick = () => setLoginMode('login');
$('showRegisterBtn').onclick = () => setLoginMode('register');
$('showForgotBtn').onclick = () => setLoginMode('forgot');
$('registerBtn').onclick = () => register();
$('sendResetCodeBtn').onclick = () => sendResetCode().catch((error) => setLoginMessage(error.message));
$('resetPasswordBtn').onclick = () => resetPassword();
$('loginPassword').addEventListener('keydown', (event) => {
  if (event.key === 'Enter') login();
});
$('registerInviteCode').addEventListener('keydown', (event) => {
  if (event.key === 'Enter') register();
});
$('logoutBtn').onclick = () => logout();
$('targetUserSelect').onchange = async () => {
  state.targetUserId = $('targetUserSelect').value;
  localStorage.setItem('toolbox_target_user', state.targetUserId);
  await loadAll();
};

$('saveAppBtn').onclick = () => saveApp().catch((error) => setStatus(error.message, true));
$('saveAccountBtn').onclick = () => saveAccount().catch((error) => setStatus(error.message, true));
$('saveMailBtn').onclick = () => saveMailSettings().catch((error) => setStatus(error.message, true));
$('testMailBtn').onclick = () => testMailSettings().catch((error) => setStatus(error.message, true));
$('appPasswordEnabled').onchange = () => {
  $('appPassword').disabled = !$('appPasswordEnabled').checked;
  if (!$('appPasswordEnabled').checked) $('appPassword').value = '';
};
$('addScopeBtn').onclick = () => addPosition().catch((error) => setStatus(error.message, true));
$('renameScopeBtn').onclick = () => renamePosition().catch((error) => setStatus(error.message, true));
$('deleteScopeBtn').onclick = () => deletePosition().catch((error) => setStatus(error.message, true));
$('addSectionBtn').onclick = () => addSection().catch((error) => setStatus(error.message, true));
$('renameSectionBtn').onclick = () => renameSection().catch((error) => setStatus(error.message, true));
$('deleteSectionBtn').onclick = () => deleteSection().catch((error) => setStatus(error.message, true));
$('addButtonBtn').onclick = () => addButton().catch((error) => setStatus(error.message, true));
$('addUserBtn').onclick = () => addUser().catch((error) => setStatus(error.message, true));
$('createInviteBtn').onclick = () => createInvite().catch((error) => setStatus(error.message, true));
$('downloadCurrentClientBtn').onclick = () => downloadClient().catch((error) => setStatus(error.message, true));
$('refreshUsersBtn').onclick = async () => {
  await loadUsers();
  renderUserContext();
  setStatus('用户列表已刷新。');
};
$('saveJsonBtn').onclick = () => saveJson().catch((error) => setStatus(error.message, true));
$('buttonSearch').oninput = renderButtons;

loadAll().catch((error) => handleLoadFailure(error));

