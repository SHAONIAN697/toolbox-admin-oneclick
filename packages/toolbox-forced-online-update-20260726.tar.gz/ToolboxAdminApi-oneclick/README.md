# 工具箱后台一键部署版

这是一个面向 Windows 工具箱客户端的网页管理后台。后台可以集中配置品牌、页面、分组、功能按钮、单文件与多文件安装包、系统工具、用户账号、邀请码和通知，并为不同用户生成专属 EXE 客户端。

## 最新功能

- 多文件安装包：一个下载按钮可配置多个文件地址，适用于必须放在同一目录的 `.exe + .pak` 等安装资源。
- 自动文件命名：客户端从 URL、重定向响应或下载响应头识别真实文件名，无需后台手动填写。
- 主程序启动：整组文件全部成功后才运行后台选定的主程序，依赖文件不会被误打开。
- 下载可靠性：同批任务不会因相似名称被合并，重名路径自动避让，失败时保留已完成文件。
- 历史兼容：原有单文件 `download_url` 配置继续有效，无需迁移。

- 多用户管理：总管理员可管理用户、邀请码和每个用户的工具箱配置。
- 邀请码注册：支持批量生成邀请码、设置可用次数和使用后保留天数。
- 支付接口配置：系统设置中支持多套支付接口配置。
- 通知中心：支持未读状态、登录弹窗、单条删除、全部删除、邮件推送指定通知。
- 自定义页面和按钮：支持页面位置、按钮分组、下载记录、系统工具和自定义脚本。
- 隐藏入口弹窗：连续点击客户端左上角 Logo 可打开“联系我们 / 支持作者”弹窗，内容由后台配置。
- 主题自适配：后台通知框、隐藏入口弹窗和客户端界面跟随当前主题，浅色深色自动适配。
- 编译校验：后台生成的 EXE 会校验编译签名和文件哈希，防止篡改。
- 多电脑运行：同一个正版 EXE 可发给多台电脑运行，不绑定下载电脑；旧版 EXE 需要重新下载。
- 手机端适配：后台表单、通知、邀请码和复制操作已优化移动端显示。

## 多文件下载使用方法

1. 在后台进入“按钮”，新增或编辑一个按钮。
2. 动作选择“下载文件”，下载配置选择“多文件安装包”。
3. 填写安装包文件夹名称，通过“添加文件”录入全部下载地址。
4. 选择一个 `.exe` 作为“完成后运行”的文件并保存。
5. 重新生成并下载工具箱 EXE 后测试。

客户端下载时会创建独立安装包目录，把所有文件保存到同一位置。更新客户端模板后，旧 EXE 必须重新生成和分发。

## 一键管理脚本

安装、更新和维护统一使用以下命令：

```bash
(curl -fsSL --connect-timeout 5 --max-time 15 "https://raw.githubusercontent.com/SHAONIAN697/toolbox-admin-oneclick/refs/heads/main/script/toolbox-admin.sh" -o toolbox-admin.sh || curl -fsSL --retry 2 --connect-timeout 15 --max-time 120 "https://gh-proxy.org/https://raw.githubusercontent.com/SHAONIAN697/toolbox-admin-oneclick/refs/heads/main/script/toolbox-admin.sh" -o toolbox-admin.sh) && sudo bash toolbox-admin.sh
```

选择安装或更新后，脚本会询问是否使用 GitHub 代理。直接回车不使用代理并继续执行；需要加速时可填写 `https://gh-proxy.org/`。

> 更新服务端程序后，请在后台重新生成并下载工具箱 EXE。

## 数据保留

更新模式会自动识别原部署目录，并保留：

- 后台账号和密码
- 用户和邀请码
- 通知记录
- 系统设置、邮件设置和支付接口配置
- 每个用户的工具箱配置
- `data/` 数据目录

脚本复制新程序前会备份已有 `data/` 目录，避免覆盖客户数据。

## EXE 生成与校验

在线生成工具箱 EXE 需要服务器安装 C# 编译器，例如 `mono-devel`。如果服务器没有 Mono，后台部署和管理功能仍可正常使用，只是不能在线生成 EXE。

```bash
apt install -y mono-devel
systemctl restart toolbox-admin
```

CentOS / Rocky 可使用：

```bash
yum install -y mono-devel
systemctl restart toolbox-admin
```

新版本 EXE 内置编译签名和文件哈希校验：

- 正版 EXE 可复制到多台电脑运行。
- 文件被修改、密钥不匹配或账号停用会被拦截。
- 更新校验逻辑后，需要在后台重新下载 EXE 再分发。

## 常用维护命令

查看服务状态：

```bash
systemctl status toolbox-admin --no-pager -l
```

重启后台：

```bash
systemctl restart toolbox-admin
```

查看日志：

```bash
journalctl -u toolbox-admin -n 100 --no-pager
```
