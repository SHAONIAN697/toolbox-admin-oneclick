#!/usr/bin/env python3
import hashlib
import hmac
import base64
import gzip
import ipaddress
import json
import math
import mimetypes
import os
import re
import secrets
import shutil
import struct
import sys
import smtplib
import subprocess
import tempfile
import threading
import time
import urllib.request
import urllib.error
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone, timedelta
from email.message import EmailMessage
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urljoin, urlparse, urlencode

ROOT = Path(__file__).resolve().parent
WWW = ROOT / "wwwroot"
DATA = ROOT / "data"
CLOUD_RESOLVER_PATH = DATA / "cloud-resolver.json"
USERS_PATH = DATA / "users.json"
MAIL_PATH = DATA / "mail.json"
SYSTEM_PATH = DATA / "system.json"
NOTICES_PATH = DATA / "notices.json"
ADMIN_ANNOUNCEMENTS_PATH = DATA / "admin-announcements.json"
ADMIN_ANNOUNCEMENT_READS_PATH = DATA / "admin-announcement-reads.json"
ORDERS_PATH = DATA / "orders.json"
SESSIONS_PATH = DATA / "sessions.json"
USER_TEMPLATE_PATH = DATA / "user-template.json"
USER_DATA = DATA / "users"
CONFIG_SHARES_PATH = DATA / "config-shares.json"
CLIENT_TEMPLATE = ROOT / "client-template" / "ToolboxClient.cs"
ADMIN_DESKTOP_TEMPLATE = ROOT / "admin-desktop-template" / "ToolboxAdminDesktop.cs"
CLIENT_ICON = ROOT / "assets" / "toolbox-default.ico"
CLIENT_CACHE = DATA / "client-cache"
CLIENT_JOBS = DATA / "client-jobs"
CLIENT_INTEGRITY_PATH = DATA / "client-integrity.json"
CLIENT_DOWNLOAD_STATS_PATH = DATA / "client-download-stats.json"
AUDIT_LOG_PATH = DATA / "security-audit.jsonl"
AUDIT_LOG_MAX_BYTES = 8 * 1024 * 1024
AUDIT_LOG_KEEP_EVENTS = 5000
CLOUD_RESOLVER_DIAGNOSTIC_LOG_PATH = DATA / "cloud-resolver-diagnostics.jsonl"
CLOUD_RESOLVER_DIAGNOSTIC_LOG_MAX_BYTES = 32 * 1024 * 1024
CLOUD_RESOLVER_DIAGNOSTIC_LOG_MAX_EVENTS = 10000
IP_CACHE_PATH = DATA / "ip-location-cache.json"
BACKUP_DIR = DATA / "security-backups"
VARIANT_COVER_DIR = WWW / "uploads" / "variant-covers"
MENU_ICON_DIR = WWW / "uploads" / "menu-icons"
MENU_ICON_LIBRARY_DIR = WWW / "uploads" / "menu-icon-library"
MENU_ICON_LIBRARY_TOKEN_CACHE = {}
MENU_ICON_LIBRARY_LOGIN_LOCK = threading.Lock()
ICON_CACHE = DATA / "icon-cache"
DEFAULT_APP_ICON = "/assets/toolbox-default-icon.png"
DEFAULT_ADMIN_TITLE = "工具箱后台登录"
DEFAULT_LOGIN_HINT = ""
STUDIO_OVERVIEW_PAGE_ID = "system_overview"

CLOUD_RESOLVER_IMPORT_ERROR = ""
try:
    import cloud_resolver
except ImportError:
    try:
        import importlib.util as _importlib_util
        _resolver_spec = _importlib_util.spec_from_file_location("cloud_resolver", ROOT / "cloud_resolver.py")
        cloud_resolver = _importlib_util.module_from_spec(_resolver_spec)
        _resolver_spec.loader.exec_module(cloud_resolver)
    except Exception as exc:
        cloud_resolver = None
        CLOUD_RESOLVER_IMPORT_ERROR = f"{type(exc).__name__}: {exc}"


class _AppContext:
    """Attribute view used when this module was loaded without sys.modules registration."""
    def __getattr__(self, name):
        return globals()[name]


_APP_CONTEXT = _AppContext()


def _app_context():
    return sys.modules.get(__name__) or _APP_CONTEXT


def default_studio_overview_page():
    return {
        "title": "\u7cfb\u7edf\u6982\u89c8",
        "name": "\u7cfb\u7edf\u6982\u89c8",
        "sections": [{
            "title": "\u53f3\u4e0b\u89d2\u5feb\u6377\u56fe\u6807",
            "buttons": [
                {"id": "overview_browser", "name": "\u6d4f\u89c8\u5668", "sort": 10, "icon": "", "action": "link", "url": "https://www.microsoft.com/edge", "target": "https://www.microsoft.com/edge", "enabled": True},
                {"id": "overview_wechat", "name": "\u5fae\u4fe1", "sort": 20, "icon": "", "action": "link", "url": "", "target": "", "enabled": True},
                {"id": "overview_yy", "name": "YY\u8bed\u97f3", "sort": 30, "icon": "", "action": "link", "url": "", "target": "", "enabled": True},
                {"id": "overview_studio_one", "name": "Studio one", "sort": 40, "icon": "", "action": "link", "url": "", "target": "", "enabled": True},
                {"id": "overview_karaoke", "name": "\u5168\u6c11K\u6b4c", "sort": 50, "icon": "", "action": "link", "url": "", "target": "", "enabled": True},
                {"id": "overview_live", "name": "\u76f4\u64ad\u4f34\u4fa3", "sort": 60, "icon": "", "action": "link", "url": "", "target": "", "enabled": True},
            ]
        }]
    }


def ensure_studio_overview_page(config):
    if not isinstance(config, dict):
        return False
    pages = config.setdefault("pages", {})
    if not isinstance(pages, dict):
        config["pages"] = {}
        pages = config["pages"]
    if STUDIO_OVERVIEW_PAGE_ID not in pages or not isinstance(pages.get(STUDIO_OVERVIEW_PAGE_ID), dict):
        pages[STUDIO_OVERVIEW_PAGE_ID] = default_studio_overview_page()
        return True
    page = pages[STUDIO_OVERVIEW_PAGE_ID]
    changed = False
    if not page.get("title"):
        page["title"] = "\u7cfb\u7edf\u6982\u89c8"
        changed = True
    sections = page.setdefault("sections", [])
    if not isinstance(sections, list) or not sections:
        page["sections"] = default_studio_overview_page()["sections"]
        changed = True
    else:
        first = sections[0] if isinstance(sections[0], dict) else {}
        if not isinstance(sections[0], dict):
            sections[0] = first
            changed = True
        first.setdefault("title", "\u53f3\u4e0b\u89d2\u5feb\u6377\u56fe\u6807")
        if not isinstance(first.get("buttons"), list):
            first["buttons"] = []
            changed = True
    return changed
ADMIN_TOKEN = os.environ.get("TOOLBOX_ADMIN_TOKEN", "").strip()
ADMIN_USERNAME = os.environ.get("TOOLBOX_ADMIN_USERNAME", "admin").strip() or "admin"
SESSIONS = {}
SECURITY_LOCK = threading.RLock()
CLOUD_RESOLVER_DIAGNOSTIC_LOCK = threading.RLock()
LOGIN_ATTEMPTS = {}
SESSION_TTL_SECONDS = max(900, int(os.environ.get("TOOLBOX_SESSION_TTL_SECONDS", "43200")))
LOGIN_WINDOW_SECONDS = 15 * 60
LOGIN_MAX_FAILURES = 8
CLIENT_BUILD_JOBS = {}
CLIENT_BUILD_LOCK = threading.Lock()
ADMIN_ANNOUNCEMENT_LOCK = threading.RLock()
PUBLIC_CONFIG_CACHE_LOCK = threading.RLock()
PUBLIC_CONFIG_CACHE = {}
CLOUD_DOWNLOAD_REFRESH_LOCK = threading.RLock()
CLOUD_DOWNLOAD_REFRESH_CACHE = {}
CLOUD_DOWNLOAD_REFRESH_TTL = 20
API_KEY_CACHE_LOCK = threading.RLock()
API_KEY_CACHE = {"signature": None, "users": {}}
JSON_WRITE_LOCK = threading.RLock()
PAYMENT_LOCK = threading.RLock()
INVITE_LOCK = PAYMENT_LOCK
CLIENT_RUNTIME_TOKEN_TTL = 7 * 24 * 60 * 60
RESET_CODES = {}
RESET_CODE_REQUESTS = {}
RESET_VERIFY_ATTEMPTS = {}
RESET_CODE_COOLDOWN_SECONDS = 60
DEFAULT_CLIENT_VARIANT = "original"
CLIENT_VARIANT_ORDER = ("original", "studio", "tuner", "audio", "portal", "vst76")
CLIENT_VARIANTS = {
    "original": {
        "id": "original",
        "label": "原版工具箱",
        "file": "original",
        "description": "保留最开始的工具箱界面，继续跟随后台配置的主题、标题和按钮布局。",
    },
    "studio": {
        "id": "studio",
        "label": "调音师经典版",
        "file": "studio",
        "description": "左侧导航、分组面板和紧凑按钮布局，适合系统工具与音频维护场景。",
    },
    "tuner": {
        "id": "tuner",
        "label": "调音师工具箱简约版",
        "file": "tuner",
        "description": "按本地调音师工具箱的白色标题栏、左侧导航、折叠分组和底部状态栏复刻，继续使用当前后台配置和内置下载模块。",
    },
    "audio": {
        "id": "audio",
        "label": "音频工具箱火山版",
        "file": "audio",
        "description": "按火山源码新增的音频工具箱界面。",
    },
    "portal": {
        "id": "portal",
        "label": "导航首页版",
        "file": "portal",
        "description": "首页横幅、导航侧栏和资源卡片布局，适合软件中心与资源入口场景。",
    },
    "vst76": {
        "id": "vst76", "label": "调音师工具箱旗舰版", "file": "vst76", "badge": "对接中",
        "description": "按 VST615 工具箱复刻的旗舰版界面，软件目录、工具页和下载任务继续使用后台共享能力。",
    },
}

SOFTWARE_CATALOG_LOCK = threading.RLock()
SOFTWARE_CATALOG_CACHE = {"home": None, "search": {}}
SOFTWARE_CATALOG_RESOLVE_CACHE = {}
SOFTWARE_CATALOG_BUILTIN = [
    {"id": "builtin-vlc", "name": "VLC media player", "score": 4.8, "description": "开源跨平台媒体播放器", "website": "https://www.videolan.org/", "source": "builtin"},
    {"id": "builtin-7zip", "name": "7-Zip", "score": 4.9, "description": "高压缩比文件归档工具", "website": "https://www.7-zip.org/", "source": "builtin"},
    {"id": "builtin-audacity", "name": "Audacity", "score": 4.7, "description": "开源音频录制与编辑工具", "website": "https://www.audacityteam.org/", "source": "builtin"},
    {"id": "builtin-vc-runtime", "name": "微软 VC++ 运行库合集", "score": 4.9, "description": "Visual C++ 运行库合集，覆盖常用 VC 运行环境。", "website": "https://learn.microsoft.com/cpp/windows/latest-supported-vc-redist", "source": "builtin"},
]
SOFTWARE_CATALOG_ENABLED = os.environ.get("TOOLBOX_SOFTWARE_CATALOG_ENABLED", "1").strip().lower() not in ("0", "false", "no", "off", "disabled")
SOFTWARE_CATALOG_HOME_URL = os.environ.get("TOOLBOX_SOFTWARE_CATALOG_HOME_URL", "https://lestore.lenovo.com/api/webstorecontents/page/contents")
SOFTWARE_CATALOG_SEARCH_URL = os.environ.get("TOOLBOX_SOFTWARE_CATALOG_SEARCH_URL", "https://lestore.lenovo.com/api/webstorecontents/search/contents")
SOFTWARE_CATALOG_RESOLVE_URL = os.environ.get("TOOLBOX_SOFTWARE_CATALOG_RESOLVE_URL", "https://lestore.lenovo.com/api/webstorecontents/download/getDownloadUrl")
SOFTWARE_CATALOG_TIMEOUT = max(2, min(30, int(os.environ.get("TOOLBOX_SOFTWARE_CATALOG_TIMEOUT", "8"))))
SOFTWARE_CATALOG_HOME_TTL = max(30, min(3600, int(os.environ.get("TOOLBOX_SOFTWARE_CATALOG_HOME_TTL", "600"))))
SOFTWARE_CATALOG_SEARCH_TTL = max(15, min(900, int(os.environ.get("TOOLBOX_SOFTWARE_CATALOG_SEARCH_TTL", "120"))))
SOFTWARE_CATALOG_ALLOWED_DOWNLOAD_DOMAINS = tuple(x.strip().lower() for x in os.environ.get("TOOLBOX_SOFTWARE_CATALOG_ALLOWED_DOWNLOAD_DOMAINS", "").split(",") if x.strip())
SOFTWARE_CATALOG_AES_KEY = b"65023EC4BA7420BB"
SOFTWARE_CATALOG_UPSTREAM_SLOTS = threading.BoundedSemaphore(max(1, min(8, int(os.environ.get("TOOLBOX_SOFTWARE_CATALOG_CONCURRENCY", "3")))))
SOFTWARE_CATALOG_BREAKER = {"failures": 0, "until": 0.0}

SCRIPT_LABELS = {
    "preset_new_machine": "新机一键优化",
    "preset_audio_workstation": "音频工站优化",
    "preset_privacy_lockdown": "隐私加固",
    "preset_pure_activate": "纯净激活套装",
    "sys_control_panel": "控制面板",
    "sys_sound_settings": "声音设置",
    "open_network_connections": "网络连接",
    "sys_apps_features": "程序和功能",
    "sys_device_manager": "设备管理器",
    "sys_disk_manager": "磁盘管理",
    "sys_computer_manager": "计算机管理",
    "sys_services": "服务",
    "sys_task_manager": "任务管理器",
    "sys_system_info": "系统信息",
    "sys_env_vars": "环境变量",
    "sys_event_viewer": "事件查看器",
    "sys_registry": "注册表",
    "sys_group_policy": "组策略",
    "sys_cmd_prompt": "命令提示符",
    "sys_security_policy": "安全策略",
    "disable_firewall": "关闭防火墙",
    "disable_update": "禁用系统更新",
    "sys_power_options": "电源管理",
    "sys_classic_context_menu": "Win 传统右键",
    "add_hosts_block": "编辑 Hosts",
    "sys_system_clean": "系统清理",
    "disable_uac": "禁用 UAC",
    "activate_windows": "一键激活系统",
}
SCRIPT_ID_BY_LABEL = {label: key for key, label in SCRIPT_LABELS.items()}


def normalize_script_target(value):
    text = str(value or "").strip()
    return text if text in SCRIPT_LABELS else SCRIPT_ID_BY_LABEL.get(text, text)


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def parse_iso_datetime(value):
    text = str(value or "").strip()
    if not text:
        raise ValueError("empty datetime")
    native_parser = getattr(datetime, "fromisoformat", None)
    if native_parser:
        return native_parser(text.replace("Z", "+00:00"))
    normalized = text.replace("Z", "+0000")
    if re.search(r"[+-]\d\d:\d\d$", normalized):
        normalized = normalized[:-3] + normalized[-2:]
    for pattern in ("%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z"):
        try:
            return datetime.strptime(normalized, pattern)
        except ValueError:
            pass
    raise ValueError("invalid datetime")


def random_hex(n=24):
    return secrets.token_hex(n)


def new_id(prefix="id"):
    return f"{prefix}_{int(time.time() * 1000):x}_{random_hex(4)}"


def normalize_public_base_url(base_url):
    parsed = urlparse(str(base_url or "").strip())
    if not parsed.netloc:
        return str(base_url or "").rstrip("/")
    scheme = parsed.scheme or "http"
    return f"{scheme}://{parsed.netloc}"


def sha256_hex(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _aes_gf_mul(a, b):
    result = 0
    for _ in range(8):
        if b & 1: result ^= a
        a = ((a << 1) ^ (0x11B if a & 0x80 else 0)) & 0xFF
        b >>= 1
    return result


def _aes_sbox():
    table = []
    for value in range(256):
        inverse = 0 if value == 0 else next(x for x in range(1, 256) if _aes_gf_mul(value, x) == 1)
        table.append((inverse ^ ((inverse << 1) | (inverse >> 7)) ^ ((inverse << 2) | (inverse >> 6)) ^ ((inverse << 3) | (inverse >> 5)) ^ ((inverse << 4) | (inverse >> 4)) ^ 0x63) & 0xFF)
    return table


def aes128_cbc_encrypt(plain, key=SOFTWARE_CATALOG_AES_KEY, iv=SOFTWARE_CATALOG_AES_KEY):
    if len(key) != 16 or len(iv) != 16: raise ValueError("AES-128 requires 16-byte key and IV")
    sbox = _aes_sbox(); words = [list(key[i:i + 4]) for i in range(0, 16, 4)]; rcon = 1
    for index in range(4, 44):
        temp = words[index - 1][:]
        if index % 4 == 0:
            temp = [sbox[temp[1]], sbox[temp[2]], sbox[temp[3]], sbox[temp[0]]]; temp[0] ^= rcon; rcon = _aes_gf_mul(rcon, 2)
        words.append([words[index - 4][j] ^ temp[j] for j in range(4)])
    round_keys = [sum(words[4 * i:4 * i + 4], []) for i in range(11)]
    data = bytearray(plain); pad = 16 - len(data) % 16; data.extend(bytes([pad]) * pad); previous = bytearray(iv); output = bytearray()
    for offset in range(0, len(data), 16):
        state = [data[offset + i] ^ previous[i] ^ round_keys[0][i] for i in range(16)]
        for round_no in range(1, 11):
            state = [sbox[x] for x in state]
            state = [state[0], state[5], state[10], state[15], state[4], state[9], state[14], state[3], state[8], state[13], state[2], state[7], state[12], state[1], state[6], state[11]]
            if round_no != 10:
                mixed = []
                for col in range(4):
                    a = state[col * 4:col * 4 + 4]
                    mixed.extend([_aes_gf_mul(a[0], 2) ^ _aes_gf_mul(a[1], 3) ^ a[2] ^ a[3], a[0] ^ _aes_gf_mul(a[1], 2) ^ _aes_gf_mul(a[2], 3) ^ a[3], a[0] ^ a[1] ^ _aes_gf_mul(a[2], 2) ^ _aes_gf_mul(a[3], 3), _aes_gf_mul(a[0], 3) ^ a[1] ^ a[2] ^ _aes_gf_mul(a[3], 2)])
                state = mixed
            state = [state[i] ^ round_keys[round_no][i] for i in range(16)]
        output.extend(state); previous = bytearray(state)
    return bytes(output)


def aes128_cbc_decrypt(cipher, key=SOFTWARE_CATALOG_AES_KEY, iv=SOFTWARE_CATALOG_AES_KEY):
    if len(key) != 16 or len(iv) != 16: raise ValueError("AES-128 requires 16-byte key and IV")
    sbox = _aes_sbox(); inverse_sbox = [0] * 256
    for index, value in enumerate(sbox): inverse_sbox[value] = index
    words = [list(key[i:i + 4]) for i in range(0, 16, 4)]; rcon = 1
    for index in range(4, 44):
        temp = words[index - 1][:]
        if index % 4 == 0:
            temp = [sbox[temp[1]], sbox[temp[2]], sbox[temp[3]], sbox[temp[0]]]; temp[0] ^= rcon; rcon = _aes_gf_mul(rcon, 2)
        words.append([words[index - 4][j] ^ temp[j] for j in range(4)])
    round_keys = [sum(words[4 * i:4 * i + 4], []) for i in range(11)]
    if not cipher or len(cipher) % 16: raise ValueError("AES ciphertext length is invalid")
    previous = bytearray(iv); output = bytearray()
    for offset in range(0, len(cipher), 16):
        state = [cipher[offset + i] ^ round_keys[10][i] for i in range(16)]
        for round_no in range(9, 0, -1):
            state = [state[0], state[13], state[10], state[7], state[4], state[1], state[14], state[11],
                     state[8], state[5], state[2], state[15], state[12], state[9], state[6], state[3]]
            state = [inverse_sbox[x] for x in state]
            state = [state[i] ^ round_keys[round_no][i] for i in range(16)]
            mixed = []
            for col in range(4):
                a = state[col * 4:col * 4 + 4]
                mixed.extend([_aes_gf_mul(a[0], 14) ^ _aes_gf_mul(a[1], 11) ^ _aes_gf_mul(a[2], 13) ^ _aes_gf_mul(a[3], 9),
                              _aes_gf_mul(a[0], 9) ^ _aes_gf_mul(a[1], 14) ^ _aes_gf_mul(a[2], 11) ^ _aes_gf_mul(a[3], 13),
                              _aes_gf_mul(a[0], 13) ^ _aes_gf_mul(a[1], 9) ^ _aes_gf_mul(a[2], 14) ^ _aes_gf_mul(a[3], 11),
                              _aes_gf_mul(a[0], 11) ^ _aes_gf_mul(a[1], 13) ^ _aes_gf_mul(a[2], 9) ^ _aes_gf_mul(a[3], 14)])
            state = mixed
        state = [state[0], state[13], state[10], state[7], state[4], state[1], state[14], state[11],
                 state[8], state[5], state[2], state[15], state[12], state[9], state[6], state[3]]
        state = [inverse_sbox[x] for x in state]
        state = [state[i] ^ round_keys[0][i] for i in range(16)]
        output.extend(bytes(state[i] ^ previous[i] for i in range(16))); previous = bytearray(cipher[offset:offset + 16])
    pad = output[-1] if output else 0
    if not 1 <= pad <= 16 or output[-pad:] != bytes([pad]) * pad: raise ValueError("AES padding is invalid")
    return bytes(output[:-pad])


def _catalog_post_payload(payload):
    compact = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return json.dumps({"data": base64.b64encode(aes128_cbc_encrypt(compact)).decode("ascii")}, separators=(",", ":")).encode("utf-8")


def _catalog_http(url, method="GET", payload=None, timeout=None):
    if SOFTWARE_CATALOG_BREAKER["until"] > time.time(): raise RuntimeError("软件目录上游暂时熔断")
    data = _catalog_post_payload(payload) if payload is not None else None
    headers = {"User-Agent": "ToolboxAdminApi/1.0", "Accept": "application/json"}
    if data is not None: headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    if not SOFTWARE_CATALOG_UPSTREAM_SLOTS.acquire(timeout=SOFTWARE_CATALOG_TIMEOUT): raise TimeoutError("软件目录请求繁忙")
    try:
        with urllib.request.urlopen(request, timeout=timeout or SOFTWARE_CATALOG_TIMEOUT) as response:
            if int(response.headers.get("Content-Length") or 0) > 2 * 1024 * 1024: raise ValueError("软件目录响应过大")
            body = response.read(2 * 1024 * 1024 + 1)
            if len(body) > 2 * 1024 * 1024: raise ValueError("软件目录响应过大")
            result = json.loads(body.decode("utf-8")); SOFTWARE_CATALOG_BREAKER.update({"failures": 0, "until": 0.0}); return result
    except Exception:
        failures = SOFTWARE_CATALOG_BREAKER["failures"] + 1; SOFTWARE_CATALOG_BREAKER["failures"] = failures
        if failures >= 3: SOFTWARE_CATALOG_BREAKER["until"] = time.time() + 30
        raise
    finally:
        SOFTWARE_CATALOG_UPSTREAM_SLOTS.release()


def _catalog_entry(raw, source="lenovo"):
    if not isinstance(raw, dict): return None
    name = str(raw.get("softName") or raw.get("name") or raw.get("appName") or "").strip()
    if not name: return None
    icon = str(raw.get("logoFile") or raw.get("icon") or "").strip()
    # Several vendor feeds still publish HTTP image URLs. Upgrade them to HTTPS
    # so the client can use the source icon without weakening transport policy.
    # Keep the vendor's original scheme. Some catalog CDNs only serve images
    # over HTTP and the client is configured to support both schemes.
    if icon and not (icon.lower().startswith("https://") or icon.lower().startswith("http://")): icon = ""
    try: score = max(0, min(5, float(raw.get("score") or 0)))
    except (TypeError, ValueError): score = 0
    return {"id": str(raw.get("softID") or raw.get("id") or sha256_hex(name)[:16]), "name": name, "iconUrl": icon, "score": score,
            "downloadCount": raw.get("downloadCount") or 0, "installFileSize": raw.get("installFileSize") or "", "description": str(raw.get("introduction") or raw.get("description") or "").strip(),
            "bizInfo": str(raw.get("bizInfo") or ""), "source": source, "website": str(raw.get("website") or "").strip(), "downloadUrl": ""}


def _catalog_extract(payload, search=False):
    rows = []; data = payload.get("data") if isinstance(payload, dict) else None
    if search: candidates = data.get("apps", []) if isinstance(data, dict) else []
    else:
        candidates = []
        for group in data if isinstance(data, list) else []:
            for listing in group.get("dataList") or [] if isinstance(group, dict) else []:
                if isinstance(listing, dict): candidates.extend(listing.get("apps") or [])
    seen = set()
    for raw in candidates:
        item = _catalog_entry(raw)
        if item and item["id"] not in seen: seen.add(item["id"]); rows.append(item)
    return rows


def software_catalog_builtin():
    return [dict(item, iconUrl="", downloadUrl="") for item in SOFTWARE_CATALOG_BUILTIN]


def _catalog_name_key(value):
    """Normalize names so identical apps from different vendors collapse to the first result."""
    text = re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "", str(value or "").lower())
    for suffix in ("官方版", "最新版", "安装包", "客户端", "软件"):
        if text.endswith(suffix): text = text[:-len(suffix)]
    return text


def _catalog_merge_unique(*groups, limit=96):
    rows = []
    seen_ids = set()
    seen_names = set()
    for group in groups:
        for item in group or []:
            if not isinstance(item, dict): continue
            key = _catalog_name_key(item.get("name"))
            item_id = str(item.get("id") or "")
            if (item_id and item_id in seen_ids) or (key and key in seen_names): continue
            if item_id: seen_ids.add(item_id)
            if key: seen_names.add(key)
            rows.append(item)
            if len(rows) >= limit: return rows
    return rows


def software_catalog_home(force=False):
    if not SOFTWARE_CATALOG_ENABLED: return software_catalog_builtin(), "disabled"
    now = time.time()
    with SOFTWARE_CATALOG_LOCK:
        cached = SOFTWARE_CATALOG_CACHE.get("home")
        if cached and not force and now - cached["at"] < SOFTWARE_CATALOG_HOME_TTL: return cached["rows"], "online"
    try:
        rows = _catalog_merge_unique(_catalog_extract(_catalog_http(SOFTWARE_CATALOG_HOME_URL), False))
        if rows:
            with SOFTWARE_CATALOG_LOCK: SOFTWARE_CATALOG_CACHE["home"] = {"at": now, "rows": rows}
            return rows, "online"
    except Exception: pass
    with SOFTWARE_CATALOG_LOCK: cached = SOFTWARE_CATALOG_CACHE.get("home")
    return (cached["rows"], "stale") if cached else (software_catalog_builtin(), "offline")


def software_catalog_search(query):
    query = str(query or "").strip()[:120]
    if not query: return software_catalog_home()
    local = [x for x in software_catalog_builtin() if query.lower() in x["name"].lower() or query.lower() in x["description"].lower()]
    if not SOFTWARE_CATALOG_ENABLED: return local, "disabled"
    now = time.time()
    with SOFTWARE_CATALOG_LOCK:
        cached = SOFTWARE_CATALOG_CACHE["search"].get(query)
        if cached and now - cached["at"] < SOFTWARE_CATALOG_SEARCH_TTL: return cached["rows"], "online"
    try:
        rows = _catalog_merge_unique(_catalog_extract(_catalog_http(SOFTWARE_CATALOG_SEARCH_URL, "POST", {"searchKey": query}), True), local)
        with SOFTWARE_CATALOG_LOCK: SOFTWARE_CATALOG_CACHE["search"][query] = {"at": now, "rows": rows}
        return rows, "online"
    except Exception:
        with SOFTWARE_CATALOG_LOCK: cached = SOFTWARE_CATALOG_CACHE["search"].get(query)
        return (cached["rows"], "stale") if cached else (local, "offline")


def _safe_download_url(value):
    try:
        parsed = urlparse(str(value or "").strip())
        if parsed.scheme.lower() != "https" or not parsed.hostname: return ""
        hostname = parsed.hostname.rstrip(".").lower()
        if hostname in ("localhost", "localhost.localdomain") or hostname.endswith(".localhost"): return ""
        try:
            address = ipaddress.ip_address(hostname)
            if address.is_private or address.is_loopback or address.is_link_local or address.is_reserved or address.is_unspecified: return ""
        except ValueError: pass
        if SOFTWARE_CATALOG_ALLOWED_DOWNLOAD_DOMAINS and not any(hostname == allowed or hostname.endswith("." + allowed) for allowed in SOFTWARE_CATALOG_ALLOWED_DOWNLOAD_DOMAINS): return ""
        return parsed.geturl()
    except Exception: return ""


def software_catalog_resolve(item_id):
    item_id = str(item_id or "").strip()
    with SOFTWARE_CATALOG_LOCK: record = SOFTWARE_CATALOG_RESOLVE_CACHE.get(item_id)
    if record and record.get("resolvedUrl") and record.get("resolvedExpires", 0) >= time.time(): return record.get("resolvedUrl")
    if not record or record.get("expires", 0) < time.time(): return None
    payload = {"bizInfo": record.get("bizInfo", ""), "bizType": "1", "product": "3", "softId": item_id, "type": "0"}
    try:
        result = _catalog_http(SOFTWARE_CATALOG_RESOLVE_URL, "POST", payload)
        for row in ((result.get("data") or {}).get("downloadUrls") or []) if isinstance(result, dict) else []:
            candidate = _safe_download_url(row.get("downLoadUrl") if isinstance(row, dict) else row)
            if candidate:
                with SOFTWARE_CATALOG_LOCK:
                    cached = SOFTWARE_CATALOG_RESOLVE_CACHE.setdefault(item_id, {})
                    cached.update({"resolvedUrl": candidate, "resolvedExpires": time.time() + 900})
                return candidate
    except Exception: return None
    return None


def software_catalog_register(rows):
    with SOFTWARE_CATALOG_LOCK:
        for item in rows:
            if item.get("id") and item.get("bizInfo"):
                old = SOFTWARE_CATALOG_RESOLVE_CACHE.get(item["id"], {})
                SOFTWARE_CATALOG_RESOLVE_CACHE[item["id"]] = dict(old, bizInfo=item["bizInfo"], expires=time.time() + 900)


def software_catalog_attach_cached_urls(rows):
    """Include cached installer URLs so clients can download without another API round trip."""
    now = time.time()
    with SOFTWARE_CATALOG_LOCK:
        for item in rows or []:
            if not isinstance(item, dict):
                continue
            record = SOFTWARE_CATALOG_RESOLVE_CACHE.get(str(item.get("id") or "")) or {}
            if record.get("resolvedUrl") and record.get("resolvedExpires", 0) >= now:
                item["downloadUrl"] = record["resolvedUrl"]
    return rows


def stored_password(password):
    salt = secrets.token_bytes(16)
    rounds = 310000
    digest = hashlib.pbkdf2_hmac("sha256", str(password).encode("utf-8"), salt, rounds)
    return f"pbkdf2_sha256${rounds}${salt.hex()}${digest.hex()}"


def check_password(password, stored):
    if str(stored or "").startswith("pbkdf2_sha256$"):
        try:
            _, rounds, salt, digest = stored.split("$", 3)
            actual = hashlib.pbkdf2_hmac("sha256", str(password).encode("utf-8"), bytes.fromhex(salt), int(rounds))
            return hmac.compare_digest(actual, bytes.fromhex(digest))
        except (TypeError, ValueError):
            return False
    try:
        kind, salt, digest = stored.split("$", 2)
    except ValueError:
        return False
    return kind == "sha256" and sha256_hex(salt + password) == digest


def client_ip(handler):
    peer = str(handler.client_address[0] or "").strip()
    try:
        trusted_proxy = ipaddress.ip_address(peer).is_private or ipaddress.ip_address(peer).is_loopback
    except ValueError:
        trusted_proxy = False
    if trusted_proxy or os.environ.get("TOOLBOX_TRUST_PROXY", "").lower() in ("1", "true", "yes"):
        forwarded = (handler.headers.get("X-Forwarded-For") or "").split(",", 1)[0].strip()
        real_ip = (handler.headers.get("X-Real-IP") or "").strip()
        for candidate in (forwarded, real_ip):
            try:
                ipaddress.ip_address(candidate)
                return candidate[:64]
            except ValueError:
                continue
    return peer[:64]


def fetch_json_url(url):
    req = urllib.request.Request(url, headers={"User-Agent": "ToolboxAdmin/1.0"})
    with urllib.request.urlopen(req, timeout=4) as response:
        charset = response.headers.get_content_charset() or ("gbk" if "pconline" in url else "utf-8")
        return json.loads(response.read().decode(charset, "replace"))


IP_LOCATION_REGIONS = (
    ("beijing", ("\\u5317\\u4eac", "beijing")), ("shanghai", ("\\u4e0a\\u6d77", "shanghai")),
    ("tianjin", ("\\u5929\\u6d25", "tianjin")), ("chongqing", ("\\u91cd\\u5e86", "chongqing")),
    ("inner-mongolia", ("\\u5185\\u8499\\u53e4", "inner mongolia")),
    ("guangxi", ("\\u5e7f\\u897f", "guangxi")), ("tibet", ("\\u897f\\u85cf", "tibet", "xizang")),
    ("ningxia", ("\\u5b81\\u590f", "ningxia")), ("xinjiang", ("\\u65b0\\u7586", "xinjiang")),
    ("hebei", ("\\u6cb3\\u5317", "hebei")), ("shanxi", ("\\u5c71\\u897f", "shanxi")),
    ("liaoning", ("\\u8fbd\\u5b81", "liaoning")), ("jilin", ("\\u5409\\u6797", "jilin")),
    ("heilongjiang", ("\\u9ed1\\u9f99\\u6c5f", "heilongjiang")),
    ("jiangsu", ("\\u6c5f\\u82cf", "jiangsu")), ("zhejiang", ("\\u6d59\\u6c5f", "zhejiang")),
    ("anhui", ("\\u5b89\\u5fbd", "anhui")), ("fujian", ("\\u798f\\u5efa", "fujian")),
    ("jiangxi", ("\\u6c5f\\u897f", "jiangxi")), ("shandong", ("\\u5c71\\u4e1c", "shandong")),
    ("henan", ("\\u6cb3\\u5357", "henan")), ("hubei", ("\\u6e56\\u5317", "hubei")),
    ("hunan", ("\\u6e56\\u5357", "hunan")), ("guangdong", ("\\u5e7f\\u4e1c", "guangdong")),
    ("hainan", ("\\u6d77\\u5357", "hainan")), ("sichuan", ("\\u56db\\u5ddd", "sichuan")),
    ("guizhou", ("\\u8d35\\u5dde", "guizhou")), ("yunnan", ("\\u4e91\\u5357", "yunnan")),
    ("shaanxi", ("\\u9655\\u897f", "shaanxi")), ("gansu", ("\\u7518\\u8083", "gansu")),
    ("qinghai", ("\\u9752\\u6d77", "qinghai")), ("taiwan", ("\\u53f0\\u6e7e", "taiwan")),
    ("hong-kong", ("\\u9999\\u6e2f", "hong kong")), ("macao", ("\\u6fb3\\u95e8", "macao", "macau")),
)
IP_PROVIDER_PRIORITY = {"amap": 0, "tencent": 1, "baidu": 2, "pconline": 3, "system": 4, "ip-api": 5, "ipapi-co": 6, "ip-sb": 7}


def ip_location_region_key(address):
    value = str(address or "").strip().lower()
    for key, aliases in IP_LOCATION_REGIONS:
        decoded_aliases = [alias.encode("ascii").decode("unicode_escape") if "\\u" in alias else alias for alias in aliases]
        if any(alias.lower() in value for alias in decoded_aliases):
            return key
    return re.sub(r"[^a-z0-9\u3400-\u9fff]+", "", value)


def select_ip_location(results, cfg):
    if not results:
        return "未知位置"
    if cfg.get("mode") == "first":
        return results[0]["address"]
    buckets = {}
    for result in results:
        key = ip_location_region_key(result.get("address"))
        if key:
            buckets.setdefault(key, []).append(result)
    if not buckets:
        return results[0]["address"]
    threshold = max(1, int(cfg.get("threshold") or 2))
    qualified = [items for items in buckets.values() if len(items) >= threshold]
    candidates = qualified or list(buckets.values())
    winning = max(candidates, key=lambda items: (
        len(items),
        -min(IP_PROVIDER_PRIORITY.get(item.get("provider"), 99) for item in items),
    ))
    return min(winning, key=lambda item: (
        IP_PROVIDER_PRIORITY.get(item.get("provider"), 99),
        0 if re.search(r"[\u3400-\u9fff]", str(item.get("address") or "")) else 1,
    ))["address"]


def locate_ip(ip, bypass_cache=False):
    if not ip or ip in ("127.0.0.1", "::1"):
        return "本机/内网"
    cache = read_json(IP_CACHE_PATH, {})
    cfg = read_system_settings().get("ipLocation") or {}
    cached = cache.get(ip) if isinstance(cache.get(ip), dict) else {}
    if not bypass_cache and time.time() - cached.get("time", 0) < 86400 * 30:
        cached_address = str(cached.get("address") or "")
        if not cfg.get("unifiedChinese", True) or re.search(r"[\u3400-\u9fff]", cached_address):
            return cached_address
    providers = cfg.get("providers") or ["system"]
    if cfg.get("mode") == "system": providers = ["system"]
    results = []
    for provider in providers:
        address = ""
        try:
            if provider == "system":
                # Match ipchk.cn's own aggregation endpoint. It returns the
                # same ip-api result shown by the site and includes its local
                # database fallbacks in one response.
                try:
                    data = fetch_json_url("https://ipchk.cn/v1/location/%s" % quote(ip, safe=""))
                    if data.get("country") or data.get("region") or data.get("city"):
                        address = "".join(str(data.get(k) or "") for k in ("country", "region", "city"))
                except Exception:
                    # Keep a network failure fallback for deployments that
                    # cannot reach ipchk.cn.
                    data = fetch_json_url("http://ip-api.com/json/%s?lang=zh-CN" % quote(ip, safe=""))
                    if data.get("status") == "success": address = "".join(str(data.get(k) or "") for k in ("country", "regionName", "city", "district"))
            elif provider == "amap" and cfg.get("amapKey"):
                data = fetch_json_url("https://restapi.amap.com/v3/ip?output=json&ip=%s&key=%s" % (quote(ip), quote(cfg["amapKey"])))
                if str(data.get("status")) == "1": address = str(data.get("province") or "") + str(data.get("city") or "")
            elif provider == "baidu" and cfg.get("baiduKey"):
                data = fetch_json_url("https://api.map.baidu.com/location/ip?coor=bd09ll&ip=%s&ak=%s" % (quote(ip), quote(cfg["baiduKey"])))
                detail = (data.get("content") or {}).get("address_detail") or {}
                if data.get("status") == 0: address = "".join(str(detail.get(k) or "") for k in ("province", "city", "district", "street", "street_number"))
            elif provider == "tencent" and cfg.get("tencentKey"):
                data = fetch_json_url("https://apis.map.qq.com/ws/location/v1/ip?ip=%s&key=%s" % (quote(ip), quote(cfg["tencentKey"])))
                detail = (data.get("result") or {}).get("ad_info") or {}
                if data.get("status") == 0: address = "".join(str(detail.get(k) or "") for k in ("nation", "province", "city", "district"))
            elif provider == "ip-api":
                data = fetch_json_url("http://ip-api.com/json/%s?lang=zh-CN" % quote(ip))
                if data.get("status") == "success": address = "".join(str(data.get(k) or "") for k in ("country", "regionName", "city", "district"))
            elif provider == "ipapi-co":
                data = fetch_json_url("https://ipapi.co/%s/json/" % quote(ip))
                if not data.get("error"): address = "".join(str(data.get(k) or "") for k in ("country_name", "region", "city"))
            elif provider == "ip-sb":
                data = fetch_json_url("https://api.ip.sb/geoip/%s" % quote(ip))
                address = "".join(str(data.get(k) or "") for k in ("country", "region", "city"))
            elif provider == "pconline":
                data = fetch_json_url("https://whois.pconline.com.cn/ipJson.jsp?json=true&ip=%s" % quote(ip))
                address = "".join(str(data.get(k) or "") for k in ("pro", "city", "region", "addr"))
        except Exception:
            continue
        if address:
            results.append({"provider": provider, "address": address})
            if cfg.get("mode") == "first": break
    address = select_ip_location(results, cfg)
    if cfg.get("unifiedChinese", True):
        repeated = re.fullmatch(r"(.+?)\\1", address, flags=re.I)
        if repeated: address = repeated.group(1)
        location_names = {
            "Autonomous Region": "",
            "Hulun Buir": "呼伦贝尔市",
            "Hulunbuir": "呼伦贝尔市","Beijing": "北京市", "Shanghai": "上海市", "Tianjin": "天津市", "Chongqing": "重庆市", "Hebei": "河北省", "Shanxi": "山西省", "Liaoning": "辽宁省", "Jilin": "吉林省", "Heilongjiang": "黑龙江省", "Jiangsu": "江苏省", "Zhejiang": "浙江省", "Anhui": "安徽省", "Fujian": "福建省", "Jiangxi": "江西省", "Shandong": "山东省", "Henan": "河南省", "Hubei": "湖北省", "Hunan": "湖南省", "Guangdong": "广东省", "Hainan": "海南省", "Sichuan": "四川省", "Guizhou": "贵州省", "Yunnan": "云南省", "Shaanxi": "陕西省", "Gansu": "甘肃省", "Qinghai": "青海省", "Taiwan": "台湾省", "Inner Mongolia": "内蒙古自治区", "Guangxi": "广西壮族自治区", "Tibet": "西藏自治区", "Ningxia": "宁夏回族自治区", "Xinjiang": "新疆维吾尔自治区", "Hong Kong": "香港特别行政区", "Macao": "澳门特别行政区", "Macau": "澳门特别行政区"}
        for english in sorted(location_names, key=len, reverse=True):
            address = re.sub(re.escape(english), location_names[english], address, flags=re.I)
        if re.search(r"[\u3400-\u9fff]", address):
            address = re.sub(r"[A-Za-z][A-Za-z ._-]*", "", address).strip()
        address = re.sub(r"^(中国|China)", "", address, flags=re.I).strip()
    cache[ip] = {"address": address, "time": time.time()}
    write_json(IP_CACHE_PATH, cache)
    return address


def read_audit_events(limit=5000):
    if not AUDIT_LOG_PATH.exists(): return {"items": []}
    rows = []
    with AUDIT_LOG_PATH.open("r", encoding="utf-8") as stream:
        for line in stream:
            try:
                row = json.loads(line)
                row["eventKey"] = hashlib.sha256(line.rstrip("\r\n").encode("utf-8")).hexdigest()
                rows.append(row)
            except Exception: continue
    users = read_users().get("users", [])
    users_by_id = {str(user.get("id") or ""): user for user in users}
    users_by_name = {str(user.get("username") or ""): user for user in users}
    ip_cache = read_json(IP_CACHE_PATH, {})
    for row in rows:
        actor = users_by_id.get(str(row.get("actorId") or "")) or users_by_name.get(str(row.get("actor") or ""))
        if actor:
            row.setdefault("actorDisplayName", actor.get("displayName") or actor.get("username") or "")
            row.setdefault("actorEmail", actor.get("email") or "")
        cached_ip = ip_cache.get(str(row.get("ip") or ""))
        if isinstance(cached_ip, dict):
            row.setdefault("ipAddress", str(cached_ip.get("address") or ""))
    return {"items": list(reversed(rows[-limit:]))}


def audit_event(action, actor=None, target="", handler=None, details=None, success=True):
    ip = client_ip(handler) if handler else ""
    entry = {
        "time": now_iso(), "action": action, "success": bool(success),
        "actorId": (actor or {}).get("id", ""), "actor": (actor or {}).get("username", ""),
        "actorDisplayName": (actor or {}).get("displayName", ""),
        "actorEmail": (actor or {}).get("email", ""),
        "target": str(target or ""), "ip": ip,
        "ipAddress": locate_ip(ip) if ip else "",
        "details": details or {},
    }
    AUDIT_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with SECURITY_LOCK:
        with AUDIT_LOG_PATH.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(entry, ensure_ascii=False, separators=(",", ":")) + "\n")
        if AUDIT_LOG_PATH.stat().st_size > AUDIT_LOG_MAX_BYTES:
            lines = AUDIT_LOG_PATH.read_text(encoding="utf-8").splitlines()
            kept = []
            kept_bytes = 0
            for line in reversed(lines[-AUDIT_LOG_KEEP_EVENTS:]):
                line_bytes = len((line + "\n").encode("utf-8"))
                if kept and kept_bytes + line_bytes > AUDIT_LOG_MAX_BYTES:
                    break
                kept.append(line)
                kept_bytes += line_bytes
            kept.reverse()
            AUDIT_LOG_PATH.write_text(("\n".join(kept) + "\n") if kept else "", encoding="utf-8")


_CLOUD_DIAGNOSTIC_SECRET_KEYS = {
    "accesscode", "sharecode", "shareid", "fileid", "activationcode", "password", "pwd", "apikey", "token",
    "t", "k", "gtk",
    "authorization", "cookie", "setcookie", "secret", "privatekey", "signature", "sign",
    "auth", "key",
}
_CLOUD_DIAGNOSTIC_SIGNED_URL_KEYS = {
    "directlink", "downloadurl", "parserurl", "resolvedurl", "backupurl", "fileurl",
    "upstreamurl", "upstreambackupurl",
}
_CLOUD_DIAGNOSTIC_SENSITIVE_QUERY_KEYS = {
    "accesscode", "sharecode", "activationcode", "password", "pwd", "apikey", "token",
    "authorization", "cookie", "secret", "signature", "sign", "auth", "key", "code",
    "session", "credential", "sid", "t", "k", "gtk",
}


def _cloud_diagnostic_safe_url(value, hide_path=False, hide_query=False):
    text = str(value or "")[:10000]
    try:
        parsed = urlparse(text)
        if parsed.scheme.lower() not in ("http", "https") or not parsed.hostname:
            return text
        host = parsed.hostname
        if parsed.port:
            host += f":{parsed.port}"
        path = parsed.path or "/"
        if hide_path and path != "/":
            path = "/[已脱敏]"
        query = []
        for query_key, values in parse_qs(parsed.query, keep_blank_values=True).items():
            normalized_query_key = query_key.casefold().replace("-", "").replace("_", "")
            sensitive = hide_query or normalized_query_key in _CLOUD_DIAGNOSTIC_SENSITIVE_QUERY_KEYS or any(
                normalized_query_key.endswith(marker)
                for marker in _CLOUD_DIAGNOSTIC_SENSITIVE_QUERY_KEYS - {"t", "k", "gtk"}
            )
            for query_value in values or [""]:
                query.append((query_key, "[已脱敏]" if sensitive else query_value))
        return parsed._replace(netloc=host, path=path, query=urlencode(query, doseq=True), fragment="").geturl()
    except Exception:
        return _CLOUD_DIAGNOSTIC_INLINE_SECRET.sub(r"\1[已脱敏]", text)


_CLOUD_DIAGNOSTIC_EMBEDDED_URL = re.compile(r"https?://[^\s\"'<>]+", re.IGNORECASE)
_CLOUD_DIAGNOSTIC_INLINE_SECRET = re.compile(
    r'''(?i)(?<![a-z0-9_])(["']?(?:access[_-]?code|share[_-]?(?:code|id)|file[_-]?id|activation[_-]?code|password|pwd|api[_-]?key|access[_-]?token|token|authorization|set-cookie|cookie|secret|private[_-]?key|signature|sign|auth|gtk|t|k)["']?\s*[:=]\s*["']?)[^&\s,"'<>]+'''
)


def _sanitize_embedded_diagnostic_urls(text):
    def replace(match):
        candidate = match.group(0)
        suffix = ""
        while candidate and candidate[-1] in "),.;!?]}":
            suffix = candidate[-1] + suffix
            candidate = candidate[:-1]
        return _cloud_diagnostic_safe_url(candidate, hide_path=True, hide_query=True) + suffix

    return _CLOUD_DIAGNOSTIC_EMBEDDED_URL.sub(replace, text)


def _sanitize_cloud_diagnostic(value, key="", redact_values=(), depth=0):
    if depth > 12:
        return "[嵌套过深]"
    normalized_key = re.sub(r"[^a-z0-9]", "", str(key).casefold())
    if isinstance(value, bool) and normalized_key.endswith(("present", "configured", "set")):
        return value
    if normalized_key in _CLOUD_DIAGNOSTIC_SECRET_KEYS or any(
            marker in normalized_key for marker in ("password", "accesscode", "apikey", "authorization", "cookie", "secret", "privatekey", "token")):
        return "[已脱敏]"
    if normalized_key in _CLOUD_DIAGNOSTIC_SIGNED_URL_KEYS:
        return _cloud_diagnostic_safe_url(value, hide_path=True, hide_query=True)
    if normalized_key in ("url", "shareurl", "sharelink", "browserurl", "referer"):
        return _cloud_diagnostic_safe_url(value, hide_path=True, hide_query=True)
    if isinstance(value, dict):
        return {str(item_key)[:120]: _sanitize_cloud_diagnostic(item_value, item_key, redact_values, depth + 1)
                for item_key, item_value in list(value.items())[:500]}
    if isinstance(value, (list, tuple)):
        return [_sanitize_cloud_diagnostic(item, key, redact_values, depth + 1) for item in list(value)[:1000]]
    if isinstance(value, str):
        text = value[:2 * 1024 * 1024]
        if normalized_key in ("url", "endpoint", "requesturl", "baseurl"):
            text = _cloud_diagnostic_safe_url(text)
        text = _CLOUD_DIAGNOSTIC_INLINE_SECRET.sub(r"\1[已脱敏]", text)
        for secret in sorted({str(item) for item in (redact_values or []) if len(str(item)) >= 4}, key=len, reverse=True):
            text = re.sub(re.escape(secret), "[已脱敏]", text, flags=re.I)
        return _sanitize_embedded_diagnostic_urls(text)
    if isinstance(value, (int, float, bool)) or value is None:
        return value
    return str(value)[:2000]


def cloud_resolver_diagnostic_enabled():
    try:
        return read_system_settings().get("cloudResolverDiagnosticsEnabled") is True
    except Exception:
        return False


def cloud_resolver_diagnostic_log(event, details=None, redact_values=None):
    """Append a bounded, secret-redacted cloud resolver diagnostic event."""
    if not cloud_resolver_diagnostic_enabled():
        return False
    row = {
        "time": now_iso(),
        "event": str(event or "unknown")[:120],
        "details": _sanitize_cloud_diagnostic(details or {}, redact_values=redact_values or []),
    }
    try:
        line = json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n"
        if len(line.encode("utf-8")) > 3 * 1024 * 1024:
            row["details"] = {"truncated": True, "originalBytes": len(line.encode("utf-8")),
                              "preview": line[:2 * 1024 * 1024]}
            line = json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n"
        with CLOUD_RESOLVER_DIAGNOSTIC_LOCK:
            CLOUD_RESOLVER_DIAGNOSTIC_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
            log_fd = os.open(str(CLOUD_RESOLVER_DIAGNOSTIC_LOG_PATH), os.O_CREAT | os.O_APPEND | os.O_WRONLY, 0o600)
            with os.fdopen(log_fd, "a", encoding="utf-8") as stream:
                stream.write(line)
            if CLOUD_RESOLVER_DIAGNOSTIC_LOG_PATH.stat().st_size > CLOUD_RESOLVER_DIAGNOSTIC_LOG_MAX_BYTES:
                lines = CLOUD_RESOLVER_DIAGNOSTIC_LOG_PATH.read_text(encoding="utf-8").splitlines()
                kept = []
                kept_bytes = 0
                for item in reversed(lines[-CLOUD_RESOLVER_DIAGNOSTIC_LOG_MAX_EVENTS:]):
                    item_bytes = len((item + "\n").encode("utf-8"))
                    if kept and kept_bytes + item_bytes > CLOUD_RESOLVER_DIAGNOSTIC_LOG_MAX_BYTES:
                        break
                    kept.append(item)
                    kept_bytes += item_bytes
                kept.reverse()
                CLOUD_RESOLVER_DIAGNOSTIC_LOG_PATH.write_text(("\n".join(kept) + "\n") if kept else "", encoding="utf-8")
        return True
    except Exception:
        return False


def read_cloud_resolver_diagnostics(limit=300):
    path = CLOUD_RESOLVER_DIAGNOSTIC_LOG_PATH
    if not path.exists():
        return {"content": "", "events": 0, "sizeBytes": 0}
    try:
        with CLOUD_RESOLVER_DIAGNOSTIC_LOCK:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
            size = path.stat().st_size
        selected = lines[-max(1, min(2000, int(limit or 300))):]
        return {"content": "\n".join(selected), "events": len(lines), "shown": len(selected), "sizeBytes": size}
    except (OSError, ValueError, TypeError):
        return {"content": "", "events": 0, "sizeBytes": 0}


def clear_cloud_resolver_diagnostics():
    with CLOUD_RESOLVER_DIAGNOSTIC_LOCK:
        CLOUD_RESOLVER_DIAGNOSTIC_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        CLOUD_RESOLVER_DIAGNOSTIC_LOG_PATH.write_text("", encoding="utf-8")


AUDIT_DETAILED_PATHS = {
    "/api/admin/app", "/api/admin/popup", "/api/admin/buttons",
    "/api/super/template/app", "/api/super/template/popup", "/api/super/template/buttons",
}


def should_write_generic_audit(path, method):
    if method not in ("POST", "PUT", "PATCH", "DELETE"):
        return False
    if path in ("/api/super/ip-location/test", "/api/super/audit") or path in AUDIT_DETAILED_PATHS:
        return False
    if path in ("/api/admin/announcements/read-all", "/api/admin/announcements/read-batch"):
        return False
    if re.fullmatch(r"/api/admin/announcements/[^/]+/mail", path):
        return False
    if re.fullmatch(r"/api/admin/announcements/[^/]+/read", path):
        return False
    return True


def audit_display_value(value, limit=180):
    if value is True:
        return "已开启"
    if value is False:
        return "已关闭"
    if value is None or value == "":
        return "未设置"
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    text = str(value).strip()
    if re.match(r"^https?://", text, re.I):
        return "已设置（链接已隐藏）"
    return text if len(text) <= limit else text[:limit] + "…"


def audit_change_rows(before, after, field_labels, keys=None):
    rows = []
    for key in (keys or field_labels.keys()):
        old_value = (before or {}).get(key)
        new_value = (after or {}).get(key)
        if old_value == new_value:
            continue
        rows.append({
            "field": field_labels.get(key, key),
            "before": audit_display_value(old_value),
            "after": audit_display_value(new_value),
        })
    return rows


APP_AUDIT_FIELDS = {
    "title": "工具箱名称", "subtitle": "副标题", "version": "版本号", "theme": "默认主题",
    "theme_count": "主题数量", "allow_client_theme": "允许客户端切换主题",
    "default_view_mode": "默认显示方式", "logo_text": "Logo 文字", "icon": "程序图标",
    "exe_icon": "EXE 图标", "window_width": "窗口宽度", "window_height": "窗口高度",
    "admin_title": "后台标题", "login_hint": "登录提示", "button_content_layout": "按钮内容布局",
    "button_content_layout_rules": "按钮布局规则",
}


def apply_basic_settings_patch(config, patch):
    payload = dict(patch or {})
    marker = object()
    delete_downloads = payload.pop("delete_downloads_on_exit", marker)
    apply_app_patch(config, payload)
    if delete_downloads is not marker:
        features = config.setdefault("features", {})
        if not isinstance(features, dict):
            features = {}
            config["features"] = features
        features["delete_downloads_on_exit"] = delete_downloads is True
        normalize_feature_settings(config)
    return payload


def basic_settings_audit_details(before, after, requested_patch, path):
    requested = dict(requested_patch or {})
    keys = [key for key in APP_AUDIT_FIELDS if key in requested]
    changes = audit_change_rows((before or {}).get("app") or {}, (after or {}).get("app") or {}, APP_AUDIT_FIELDS, keys)
    if "delete_downloads_on_exit" in requested:
        old_value = ((before or {}).get("features") or {}).get("delete_downloads_on_exit") is True
        new_value = ((after or {}).get("features") or {}).get("delete_downloads_on_exit") is True
        if old_value != new_value:
            changes.append({"field": "关闭时删除已下载文件", "before": audit_display_value(old_value), "after": audit_display_value(new_value)})
    return {"title": "修改基础信息", "category": "basic", "method": "PATCH", "path": path, "changes": changes}


def popup_rows_summary(rows):
    items = rows if isinstance(rows, list) else []
    names = [str(item.get("title") or "").strip() for item in items if isinstance(item, dict) and str(item.get("title") or "").strip()]
    suffix = "（%s）" % "、".join(names[:6]) if names else ""
    if len(names) > 6:
        suffix = suffix[:-1] + "等）"
    return "%d 项%s" % (len(items), suffix)


POPUP_AUDIT_FIELDS = {
    "enabled": "联系方式弹窗", "clickCount": "触发点击次数", "cacheMinutes": "缓存时间（分钟）",
    "title": "弹窗标题", "thanksText": "感谢文字",
}


def popup_settings_audit_details(before, after, path):
    changes = audit_change_rows(before or {}, after or {}, POPUP_AUDIT_FIELDS)
    for key, label in (("contacts", "联系方式"), ("payments", "收款方式"), ("links", "相关链接")):
        old_rows = (before or {}).get(key) or []
        new_rows = (after or {}).get(key) or []
        if old_rows != new_rows:
            changes.append({"field": label, "before": popup_rows_summary(old_rows), "after": popup_rows_summary(new_rows)})
    return {"title": "修改联系方式", "category": "contacts", "method": "PATCH", "path": path, "changes": changes}


BUTTON_AUDIT_FIELDS = {
    "name": "按钮名称", "enabled": "启用状态", "sort": "排序", "icon": "按钮图标",
    "description": "按钮说明", "action": "操作类型", "download_mode": "下载模式", "package_name": "安装包名称", "guard": "按钮安全验证",
}
BUTTON_ACTION_LABELS = {"link": "打开链接", "download": "下载文件", "cmd": "执行命令", "script": "内置功能", "winget": "Winget 安装"}


def find_button_audit_row(config, body):
    rows, _ = button_rows(config)
    button_id = str((body or {}).get("id") or "")
    if button_id:
        return next((row for row in rows if str(row.get("id") or "") == button_id), None)
    for row in rows:
        if (row.get("scope") == (body or {}).get("scope") and
                row.get("pageId") == (body or {}).get("pageId") and
                row.get("tabIndex") == (body or {}).get("tabIndex") and
                int(row.get("sectionIndex") or 0) == int((body or {}).get("sectionIndex") or 0) and
                int(row.get("buttonIndex") or 0) == int((body or {}).get("buttonIndex") or 0)):
            return row
    return None


def button_location_text(row):
    if not row:
        return "未记录"
    area = str(row.get("area") or "").strip()
    section = str(row.get("section") or "").strip()
    return " / ".join(value for value in (area, section) if value) or "未记录"


def button_audit_value(key, value):
    if key == "action":
        return BUTTON_ACTION_LABELS.get(str(value or ""), audit_display_value(value))
    if key == "guard":
        guard = value if isinstance(value, dict) else {}
        return "密码验证：%s；确认提示：%s" % ("开启" if guard.get("requirePassword") else "关闭", "开启" if guard.get("requireConfirm") else "关闭")
    return audit_display_value(value)


def button_audit_details(operation, before_row, after_row, path):
    before_button = json_clone((before_row or {}).get("raw") or {})
    after_button = json_clone((after_row or {}).get("raw") or {})
    changes = []
    if operation == "create":
        for key, label in BUTTON_AUDIT_FIELDS.items():
            if key in after_button and after_button.get(key) not in (None, ""):
                changes.append({"field": label, "before": "未创建", "after": button_audit_value(key, after_button.get(key))})
        changes.append({"field": "所在位置", "before": "未创建", "after": button_location_text(after_row)})
    elif operation == "delete":
        for key, label in BUTTON_AUDIT_FIELDS.items():
            if key in before_button and before_button.get(key) not in (None, ""):
                changes.append({"field": label, "before": button_audit_value(key, before_button.get(key)), "after": "已删除"})
        changes.append({"field": "所在位置", "before": button_location_text(before_row), "after": "已删除"})
    else:
        for key, label in BUTTON_AUDIT_FIELDS.items():
            if before_button.get(key) != after_button.get(key):
                changes.append({"field": label, "before": button_audit_value(key, before_button.get(key)), "after": button_audit_value(key, after_button.get(key))})
        if get_target(before_button) != get_target(after_button) or before_button.get("files") != after_button.get("files"):
            changes.append({"field": "链接或执行目标", "before": "内容已隐藏", "after": "已修改（内容已隐藏）"})
        old_location = button_location_text(before_row)
        new_location = button_location_text(after_row)
        if old_location != new_location:
            changes.append({"field": "所在位置", "before": old_location, "after": new_location})
    name = str((after_button or before_button).get("name") or "未命名按钮")
    titles = {"create": "新增按钮", "update": "修改按钮", "delete": "删除按钮"}
    methods = {"create": "POST", "update": "PATCH", "delete": "DELETE"}
    return {
        "title": "%s：%s" % (titles[operation], name), "category": "buttons", "operation": operation,
        "method": methods[operation], "path": path, "itemName": name, "changes": changes,
    }


def security_backup(label, paths):
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    destination = BACKUP_DIR / f"{stamp}-{safe_id(label)}"
    destination.mkdir(parents=True, exist_ok=False)
    for path in paths:
        path = Path(path)
        if path.exists() and path.is_file():
            shutil.copy2(path, destination / path.name)
    return destination


def revoke_user_sessions(user_id, keep_token=""):
    with SECURITY_LOCK:
        expired = [token for token, row in SESSIONS.items()
                   if row.get("userId") == user_id and token != keep_token]
        for token in expired:
            SESSIONS.pop(token, None)
        if expired:
            save_sessions()
    return len(expired)


def hmac_sha256_hex(secret, text):
    return hmac.new(str(secret or "").encode("utf-8"), str(text or "").encode("utf-8"), hashlib.sha256).hexdigest()


def constant_time_equals(left, right):
    return hmac.compare_digest(str(left or ""), str(right or ""))


def read_json(path, fallback):
    if not path.exists():
        return fallback
    with path.open("r", encoding="utf-8-sig") as f:
        return json.load(f)


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = None
    with JSON_WRITE_LOCK:
        try:
            with tempfile.NamedTemporaryFile(
                mode="w",
                encoding="utf-8",
                dir=str(path.parent),
                prefix=path.name + ".",
                suffix=".tmp",
                delete=False,
            ) as f:
                tmp = Path(f.name)
                json.dump(value, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(str(tmp), str(path))
        finally:
            if tmp and tmp.exists():
                try:
                    tmp.unlink()
                except OSError:
                    pass


def read_json_recover_extra(path, fallback, label="JSON 文件"):
    try:
        return read_json(path, fallback)
    except json.JSONDecodeError as exc:
        if exc.msg != "Extra data":
            raise RuntimeError(f"{label} 已损坏：{exc}") from exc

    text = path.read_text(encoding="utf-8-sig")
    decoder = json.JSONDecoder()
    values = []
    index = 0
    while index < len(text):
        while index < len(text) and text[index].isspace():
            index += 1
        if index >= len(text):
            break
        try:
            value, index = decoder.raw_decode(text, index)
        except json.JSONDecodeError:
            break
        if isinstance(value, dict):
            values.append(value)
    if not values:
        raise RuntimeError(f"{label} 已损坏，且没有找到可恢复的完整数据。")

    backup_dir = path.parent / "json-recovery-backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    backup_path = backup_dir / f"{path.stem}-extra-data-{stamp}-{random_hex(4)}{path.suffix}"
    shutil.copy2(path, backup_path)
    recovered = values[-1]
    write_json(path, recovered)
    return recovered


def read_toolbox_config_json(path, fallback):
    return read_json_recover_extra(path, fallback, "工具箱配置 JSON")


ANNOUNCEMENT_TYPES = ("功能更新", "问题修复", "系统通知", "重要公告", "维护公告")
ANNOUNCEMENT_IMPORTANCE = ("普通", "重要", "紧急")


def read_json_safe(path, fallback):
    try:
        value = read_json(path, fallback)
        return value
    except Exception:
        return fallback


def read_admin_announcements():
    value = read_json_safe(ADMIN_ANNOUNCEMENTS_PATH, {"announcements": []})
    return value if isinstance(value, dict) and isinstance(value.get("announcements"), list) else {"announcements": []}


def read_admin_announcement_reads():
    value = read_json_safe(ADMIN_ANNOUNCEMENT_READS_PATH, {"reads": []})
    return value if isinstance(value, dict) and isinstance(value.get("reads"), list) else {"reads": []}


def ensure_admin_announcement_files():
    with ADMIN_ANNOUNCEMENT_LOCK:
        if not ADMIN_ANNOUNCEMENTS_PATH.exists():
            write_json(ADMIN_ANNOUNCEMENTS_PATH, {"announcements": []})
        if not ADMIN_ANNOUNCEMENT_READS_PATH.exists():
            write_json(ADMIN_ANNOUNCEMENT_READS_PATH, {"reads": []})


def clean_announcement_text(value, limit):
    text = str(value or "").replace("\x00", "").strip()
    return text[:limit]


def normalize_announcement_payload(body, current=None):
    body = body if isinstance(body, dict) else {}
    item = dict(current or {})
    item["title"] = clean_announcement_text(body.get("title", item.get("title")), 160)
    item["summary"] = clean_announcement_text(body.get("summary", item.get("summary")), 500)
    item["content"] = clean_announcement_text(body.get("content", item.get("content")), 30000)
    item["version"] = clean_announcement_text(body.get("version", item.get("version")), 80)
    announcement_type = clean_announcement_text(body.get("type", item.get("type") or "功能更新"), 30)
    item["type"] = announcement_type if announcement_type in ANNOUNCEMENT_TYPES else "功能更新"
    importance = clean_announcement_text(body.get("importance", item.get("importance") or "普通"), 20)
    item["importance"] = importance if importance in ANNOUNCEMENT_IMPORTANCE else "普通"
    item["popup_enabled"] = bool(body.get("popup_enabled", item.get("popup_enabled", True)))
    item["force_popup"] = False
    item["publish_time"] = clean_announcement_text(body.get("publish_time", item.get("publish_time")), 50)
    item["expire_time"] = clean_announcement_text(body.get("expire_time", item.get("expire_time")), 50)
    item["enabled"] = bool(body.get("enabled", item.get("enabled", True)))
    return item


def announcement_is_available(item):
    if item.get("status") != "published" or item.get("enabled", True) is False:
        return False
    publish_time = str(item.get("publish_time") or "").strip()
    if publish_time:
        try:
            if parse_iso_datetime(publish_time) > datetime.now(timezone.utc):
                return False
        except Exception:
            pass
    expires = str(item.get("expire_time") or "").strip()
    if expires:
        try:
            if parse_iso_datetime(expires) <= datetime.now(timezone.utc):
                return False
        except Exception:
            pass
    return True


def announcement_read_record(reads, announcement_id, user_id, revision):
    return next((row for row in reads if row.get("announcement_id") == announcement_id and row.get("user_id") == user_id and int(row.get("notification_revision") or 1) == revision), None)


def public_admin_announcement(item, user_id, reads, include_readers=False):
    result = dict(item)
    revision = int(item.get("notification_revision") or 1)
    result["read"] = announcement_read_record(reads, item.get("id"), user_id, revision) is not None
    if include_readers:
        matching = [row for row in reads if row.get("announcement_id") == item.get("id") and int(row.get("notification_revision") or 1) == revision]
        result["readCount"] = len({row.get("user_id") for row in matching})
        result["readUsers"] = [{"userId": row.get("user_id"), "username": row.get("username") or "", "readTime": row.get("read_time") or ""} for row in matching]
    return result


def mark_admin_announcement_read(announcement_id, user, revision):
    with ADMIN_ANNOUNCEMENT_LOCK:
        store = read_admin_announcement_reads()
        reads = store["reads"]
        record = announcement_read_record(reads, announcement_id, user.get("id"), revision)
        if not record:
            reads.append({
                "announcement_id": announcement_id,
                "user_id": user.get("id"),
                "username": user.get("username"),
                "read_time": now_iso(),
                "notification_revision": revision,
            })
            write_json(ADMIN_ANNOUNCEMENT_READS_PATH, store)


def mark_admin_announcement_batch_read(rows, reads, user, references):
    """Mark exactly the announcement revisions displayed in a one-time popup."""
    if not isinstance(references, list):
        return 0
    user_id = user.get("id")
    by_id = {str(item.get("id") or ""): item for item in rows if item.get("id")}
    marked = 0
    seen = set()
    for reference in references[:200]:
        if isinstance(reference, dict):
            announcement_id = clean_announcement_text(reference.get("id"), 160)
            requested_revision = reference.get("notification_revision")
        else:
            announcement_id = clean_announcement_text(reference, 160)
            requested_revision = None
        item = by_id.get(announcement_id)
        if not item or announcement_id in seen or not announcement_is_available(item):
            continue
        revision = int(item.get("notification_revision") or 1)
        if requested_revision not in (None, ""):
            try:
                if int(requested_revision) != revision:
                    continue
            except (TypeError, ValueError):
                continue
        seen.add(announcement_id)
        if announcement_read_record(reads, announcement_id, user_id, revision):
            continue
        reads.append({
            "announcement_id": announcement_id,
            "user_id": user_id,
            "username": user.get("username"),
            "read_time": now_iso(),
            "notification_revision": revision,
        })
        marked += 1
    return marked


def client_build_cleanup_settings():
    settings = read_system_settings().get("clientBuild") or {}
    try:
        cache_hours = max(1, min(24 * 30, int(settings.get("cacheRetentionHours") or 24)))
    except Exception:
        cache_hours = 24
    try:
        job_hours = max(1, min(24 * 30, int(settings.get("jobRetentionHours") or 24)))
    except Exception:
        job_hours = 24
    try:
        interval_minutes = max(10, min(24 * 60, int(settings.get("cleanupIntervalMinutes") or 360)))
    except Exception:
        interval_minutes = 360
    try:
        max_entries = max(1, min(200, int(settings.get("maxCacheEntries") or 30)))
    except Exception:
        max_entries = 30
    return {
        "cacheSeconds": cache_hours * 60 * 60,
        "jobSeconds": job_hours * 60 * 60,
        "intervalSeconds": interval_minutes * 60,
        "maxEntries": max_entries,
    }


def read_client_integrity():
    data = read_json_recover_extra(
        CLIENT_INTEGRITY_PATH,
        {"builds": {}, "tokens": {}},
        "客户端完整性记录 JSON",
    )
    if not isinstance(data, dict):
        data = {"builds": {}, "tokens": {}}
    data.setdefault("builds", {})
    data.setdefault("tokens", {})
    return data


def write_client_integrity(data):
    data.setdefault("builds", {})
    data.setdefault("tokens", {})
    write_json(CLIENT_INTEGRITY_PATH, data)


def load_sessions():
    try:
        value = read_json(SESSIONS_PATH, {})
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def save_sessions():
    try:
        write_json(SESSIONS_PATH, SESSIONS)
    except Exception:
        pass


SESSIONS.update(load_sessions())


def default_popup_settings():
    return {
        "enabled": False,
        "clickCount": 3,
        "title": "联系我们 / 支持作者",
        "thanksText": "感谢你的支持，我们会持续维护和更新工具箱。",
        "cacheMinutes": 60,
        "contacts": [],
        "payments": [],
        "links": [],
    }


def default_config():
    return {
        "app": {
            "title": "Toolbox",
            "subtitle": "",
            "version": "V1.0",
            "logo_text": "Y",
            "icon": DEFAULT_APP_ICON,
            "admin_title": DEFAULT_ADMIN_TITLE,
            "login_hint": "",
            "window_width": 1080,
            "window_height": 700,
            "password": "",
            "theme": "鍗堝闈涜摑",
            "theme_count": 19,
            "allow_client_theme": True,
            "default_view_mode": "grid",
            "button_linkage_enabled": False,
            "button_content_layout": "icon_left",
            "button_content_layout_rules": {
                "icon_left": {"enabled": False, "pages": []},
                "icon_top": {"enabled": False, "pages": []},
            },
            "bg_path": "",
            "output_dir": "",
        },
        "license": {"enabled": False, "api_base": "", "product_code": ""},
        "popup": default_popup_settings(),
        "features": {
            "software_catalog_enabled": True,
            "resource_search_enabled": False,
            "delete_downloads_on_exit": False,
        },
        "page_locks": {},
        "page_lock_groups": {},
        "sidebar": [],
        "toolbox_tabs": [],
        "pages": {},
    }


def config_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return value != 0
    text = str(value).strip().lower()
    if text in ("1", "true", "yes", "on", "enabled", "enable", "启用", "开启"):
        return True
    if text in ("0", "false", "no", "off", "disabled", "disable", "停用", "禁用", "关闭"):
        return False
    return default


def normalize_view_mode(value, default="grid"):
    text = str(value or "").strip().lower()
    if text in ("list", "列表", "listmode", "list_mode"):
        return "list"
    if text in ("grid", "宫格", "gongge", "gridmode", "grid_mode"):
        return "grid"
    return default


def normalize_button_content_layout(value):
    value = str(value or "").strip().lower()
    return value if value in ("none", "icon_left", "icon_top") else "icon_left"


def normalize_feature_settings(config):
    changed = False
    features = config.get("features")
    if not isinstance(features, dict):
        features = {}
        config["features"] = features
        changed = True
    enabled = config_bool(features.get("software_catalog_enabled"), True)
    if features.get("software_catalog_enabled") is not enabled:
        features["software_catalog_enabled"] = enabled
        changed = True
    resource_search_enabled = config_bool(features.get("resource_search_enabled"), False)
    if features.get("resource_search_enabled") is not resource_search_enabled:
        features["resource_search_enabled"] = resource_search_enabled
        changed = True
    delete_downloads_on_exit = config_bool(features.get("delete_downloads_on_exit"), False)
    if features.get("delete_downloads_on_exit") is not delete_downloads_on_exit:
        features["delete_downloads_on_exit"] = delete_downloads_on_exit
        changed = True
    return changed


def normalize_page_locks(config):
    changed = False
    locks = config.get("page_locks")
    if not isinstance(locks, dict):
        locks = {}
        config["page_locks"] = locks
        changed = True
    for raw_page_id in list(locks.keys()):
        page_id = str(raw_page_id or "").strip()
        if not page_id:
            locks.pop(raw_page_id, None)
            changed = True
            continue
        if page_id != raw_page_id:
            locks[page_id] = locks.pop(raw_page_id)
            changed = True
        lock = locks.get(page_id)
        if not isinstance(lock, dict):
            lock = {"enabled": config_bool(lock, False), "password": ""}
            locks[page_id] = lock
            changed = True
        enabled = config_bool(lock.get("enabled"), False)
        if lock.get("enabled") is not enabled:
            lock["enabled"] = enabled
            changed = True
        password = str(lock.get("password") or "").strip()
        if password and not password.startswith(("sha256$", "pbkdf2_sha256$")):
            lock["password_plain"] = password
            password = stored_password(password)
        if lock.get("password") != password:
            lock["password"] = password
            changed = True
        if "title" in lock:
            title = str(lock.get("title") or "").strip()
            if lock.get("title") != title:
                lock["title"] = title
                changed = True
    return changed


def normalize_page_lock_groups(config):
    changed = False
    groups = config.get("page_lock_groups")
    if not isinstance(groups, dict):
        groups = {}
        config["page_lock_groups"] = groups
        changed = True
    for raw_group_id in list(groups.keys()):
        group_id = str(raw_group_id or "").strip()
        if not group_id:
            groups.pop(raw_group_id, None)
            changed = True
            continue
        if group_id != raw_group_id:
            groups[group_id] = groups.pop(raw_group_id)
            changed = True
        group = groups.get(group_id)
        if not isinstance(group, dict):
            group = {"title": "", "password": "", "pages": []}
            groups[group_id] = group
            changed = True
        password = str(group.get("password") or "").strip()
        if password and not password.startswith(("sha256$", "pbkdf2_sha256$")):
            group["password_plain"] = password
            password = stored_password(password)
        if group.get("password") != password:
            group["password"] = password
            changed = True
        pages = group.get("pages")
        if not isinstance(pages, list):
            pages = []
        normalized_pages = []
        for page_id in pages:
            page_id = str(page_id or "").strip()
            if page_id and page_id not in normalized_pages:
                normalized_pages.append(page_id)
        if group.get("pages") != normalized_pages:
            group["pages"] = normalized_pages
            changed = True
        title = str(group.get("title") or "").strip()
        if group.get("title") != title:
            group["title"] = title
            changed = True
    return changed


def safe_id(value):
    text = "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in str(value).lower()).strip("_")
    return text or "user"


def user_display_name(user):
    if not user:
        return ""
    return (user.get("displayName") or user.get("username") or user.get("id") or "").strip()


def find_user_display_name(user_id="", username=""):
    user = find_user_by_id(user_id) if user_id else None
    if not user and username:
        user = find_user_by_username(username)
    return user_display_name(user) or username or user_id or ""


def exe_file_stem(user):
    return safe_id(user_display_name(user) or "user")


def clean_download_name_part(value):
    text = str(value or "").strip()
    invalid = '<>:"/\\|?*\r\n\t\0'
    text = "".join("_" if ch in invalid else ch for ch in text)
    text = " ".join(text.split()).strip(" ._")
    return (text[:80].strip(" ._") or "user")


def ascii_file_name_part(value, fallback="user"):
    text = str(value or "").strip()
    chars = []
    for ch in text:
        if ord(ch) < 128 and (ch.isalnum() or ch in "_-."):
            chars.append(ch)
        elif ch.isspace() or ch in "-_.":
            chars.append("_")
    cleaned = "".join(chars).strip("._-")
    while "__" in cleaned:
        cleaned = cleaned.replace("__", "_")
    return (cleaned[:80].strip("._-") or fallback)


def client_exe_filename(user, timestamp=None, variant=DEFAULT_CLIENT_VARIANT):
    stamp = int(timestamp or time.time())
    stem = ascii_file_name_part((user or {}).get("username") or (user or {}).get("id") or "user")
    suffix = client_variant_file_suffix(variant)
    return f"toolbox-{stem}-{suffix}-{stamp}.exe"


def ascii_download_fallback(filename):
    path = Path(str(filename or "download.bin"))
    suffix = path.suffix or ".bin"
    stem = "".join(ch if (ord(ch) < 128 and (ch.isalnum() or ch in "_-.")) else "_" for ch in path.stem).strip("._")
    stem = stem[:80].strip("._") or "download"
    return f"{stem}{suffix}"


def normalize_client_variant(value):
    variant = str(value or "").strip().lower()
    return variant if variant in CLIENT_VARIANTS else DEFAULT_CLIENT_VARIANT


def client_variant_info(value):
    return CLIENT_VARIANTS[normalize_client_variant(value)]


def public_client_variants():
    configured = read_system_settings().get("clientVariants") or {}
    counts = read_client_download_counts()
    variants = []
    for variant_id in CLIENT_VARIANT_ORDER:
        item = dict(CLIENT_VARIANTS[variant_id])
        values = configured.get(variant_id) if isinstance(configured.get(variant_id), dict) else {}
        for key in ("name", "badge", "description", "coverMode", "coverUrl"):
            if key in values:
                item[key] = values[key]
        item["downloadCount"] = counts.get(variant_id, 0)
        variants.append(item)
    return {"variants": variants}


def read_client_download_counts():
    data = read_json(CLIENT_DOWNLOAD_STATS_PATH, {})
    return {
        variant_id: max(0, int(data.get(variant_id) or 0))
        for variant_id in CLIENT_VARIANTS
    } if isinstance(data, dict) else {variant_id: 0 for variant_id in CLIENT_VARIANTS}


def record_client_download(variant):
    variant = normalize_client_variant(variant)
    with SECURITY_LOCK:
        counts = read_client_download_counts()
        counts[variant] = counts.get(variant, 0) + 1
        write_json(CLIENT_DOWNLOAD_STATS_PATH, counts)
        return counts[variant]


def record_client_build_download(job_id, actor):
    if is_super(actor):
        return False
    with CLIENT_BUILD_LOCK:
        job = CLIENT_BUILD_JOBS.get(job_id)
        if not job or job.get("downloadCounted"):
            return False
        job["downloadCounted"] = True
        variant = job.get("variant")
    record_client_download(variant)
    return True


def request_client_variant(handler, body=None):
    if body and body.get("variant"):
        return normalize_client_variant(body.get("variant"))
    if hasattr(handler, "query"):
        return normalize_client_variant(handler.query.get("variant", [""])[0])
    return DEFAULT_CLIENT_VARIANT


def client_variant_file_suffix(variant):
    return client_variant_info(variant).get("file") or normalize_client_variant(variant)


def find_csharp_compiler():
    compiler = shutil.which("mcs") or shutil.which("csc")
    if compiler:
        return compiler
    windows_dir = Path(os.environ.get("WINDIR", r"C:\Windows"))
    candidates = [
        windows_dir / "Microsoft.NET" / "Framework64" / "v4.0.30319" / "csc.exe",
        windows_dir / "Microsoft.NET" / "Framework" / "v4.0.30319" / "csc.exe",
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Mono" / "lib" / "mono" / "4.5" / "mcs.exe",
        Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Mono" / "lib" / "mono" / "4.5" / "mcs.exe",
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Mono" / "bin" / "mcs.exe",
        Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Mono" / "bin" / "mcs.exe",
    ]
    for candidate in candidates:
        if candidate.exists():
            return str(candidate)
    return None


def csharp_compile_command(compiler, args):
    compiler_path = Path(str(compiler or ""))
    if os.name == "nt" and compiler_path.suffix.lower() == ".exe":
        parts = [p.lower() for p in compiler_path.parts]
        if "mono" in parts and compiler_path.name.lower() in ("mcs.exe", "csc.exe"):
            mono = Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Mono" / "bin" / "mono.exe"
            if not mono.exists():
                mono = Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Mono" / "bin" / "mono.exe"
            if mono.exists():
                return [str(mono), str(compiler_path)] + args
    return [str(compiler)] + args


def is_windows_exe(data):
    if not isinstance(data, (bytes, bytearray)) or len(data) < 0x40 or data[:2] != b"MZ":
        return False
    try:
        pe_offset = struct.unpack_from("<I", data, 0x3C)[0]
        if pe_offset < 0x40 or pe_offset + 24 > len(data) or data[pe_offset:pe_offset + 4] != b"PE\0\0":
            return False

        file_header = pe_offset + 4
        section_count = struct.unpack_from("<H", data, file_header + 2)[0]
        optional_size = struct.unpack_from("<H", data, file_header + 16)[0]
        optional_header = file_header + 20
        if section_count == 0 or optional_size < 2 or optional_header + optional_size > len(data):
            return False

        magic = struct.unpack_from("<H", data, optional_header)[0]
        if magic == 0x10B:
            number_of_directories_offset, directories_offset = 92, 96
        elif magic == 0x20B:
            number_of_directories_offset, directories_offset = 108, 112
        else:
            return False
        if optional_size < directories_offset + 15 * 8:
            return False
        directory_count = struct.unpack_from("<I", data, optional_header + number_of_directories_offset)[0]
        if directory_count <= 14:
            return False

        clr_offset = optional_header + directories_offset + 14 * 8
        clr_rva, clr_size = struct.unpack_from("<II", data, clr_offset)
        if clr_rva == 0 or clr_size < 0x48:
            return False

        section_table = optional_header + optional_size
        if section_table + section_count * 40 > len(data):
            return False
        for index in range(section_count):
            section = section_table + index * 40
            virtual_size, virtual_address, raw_size, raw_pointer = struct.unpack_from("<IIII", data, section + 8)
            span = max(virtual_size, raw_size)
            if virtual_address <= clr_rva and clr_rva + 0x48 <= virtual_address + span:
                clr_header = raw_pointer + clr_rva - virtual_address
                if clr_rva - virtual_address + 0x48 > raw_size or clr_header + 0x48 > len(data):
                    return False
                header_size = struct.unpack_from("<I", data, clr_header)[0]
                return 0x48 <= header_size <= clr_size and clr_header + header_size <= len(data)
        return False
    except (struct.error, OverflowError):
        return False


def binary_header_preview(data, limit=16):
    if not isinstance(data, (bytes, bytearray)) or not data:
        return "empty"
    sample = bytes(data[:limit])
    return " ".join(f"{byte:02X}" for byte in sample)


def user_config_path(user_id):
    safe = safe_id(user_id)
    return USER_DATA / safe / "config.json"


def ensure_config_defaults(config):
    app = config.setdefault("app", {})
    changed = False
    if not app.get("icon") and not app.get("icon_url") and not app.get("icon_path"):
        app["icon"] = DEFAULT_APP_ICON
        changed = True
    if "login_hint" not in app:
        app["login_hint"] = DEFAULT_LOGIN_HINT
        changed = True
    if "admin_title" not in app:
        app["admin_title"] = DEFAULT_ADMIN_TITLE
        changed = True
    default_view_mode = normalize_view_mode(app.get("default_view_mode"), "grid")
    if app.get("default_view_mode") != default_view_mode:
        app["default_view_mode"] = default_view_mode
        changed = True
    linkage_enabled = app.get("button_linkage_enabled") is True
    if app.get("button_linkage_enabled") != linkage_enabled:
        app["button_linkage_enabled"] = linkage_enabled
        changed = True
    button_content_layout = normalize_button_content_layout(app.get("button_content_layout"))
    if app.get("button_content_layout") != button_content_layout:
        app["button_content_layout"] = button_content_layout
        changed = True
    rules = app.get("button_content_layout_rules")
    if not isinstance(rules, dict):
        rules = {}
    normalized_rules = {}
    for layout_id in ("icon_left", "icon_top"):
        source = rules.get(layout_id) if isinstance(rules.get(layout_id), dict) else {}
        pages = []
        for page_id in source.get("pages") or []:
            value = str(page_id or "").strip()
            if value and value not in pages:
                pages.append(value[:120])
        normalized_rules[layout_id] = {"enabled": source.get("enabled") is True, "pages": pages[:100]}
    if app.get("button_content_layout_rules") != normalized_rules:
        app["button_content_layout_rules"] = normalized_rules
        changed = True
    if normalize_feature_settings(config):
        changed = True
    if normalize_page_locks(config):
        changed = True
    if normalize_page_lock_groups(config):
        changed = True
    if ensure_studio_overview_page(config):
        changed = True
    normalized_popup = normalize_popup_settings(config.get("popup") or {})
    if config.get("popup") != normalized_popup:
        config["popup"] = normalized_popup
        changed = True
    return changed


def read_config(user_id=""):
    path = user_config_path(user_id) if user_id else DATA / "config.json"
    if not path.exists():
        if user_id and USER_TEMPLATE_PATH.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(USER_TEMPLATE_PATH, path)
        elif (DATA / "config.json").exists() and user_id:
            path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(DATA / "config.json", path)
        else:
            write_json(path, default_config())
    config = read_toolbox_config_json(path, default_config())
    changed = ensure_config_defaults(config)
    if changed:
        write_json(path, config)
    return config


def write_config(config, user_id=""):
    path = user_config_path(user_id) if user_id else DATA / "config.json"
    if not isinstance(config, dict):
        raise ValueError("配置格式错误。")
    ensure_config_defaults(config)
    write_json(path, config)
    invalidate_public_config_cache(user_id or None)


def read_user_template_config():
    if not USER_TEMPLATE_PATH.exists():
        write_json(USER_TEMPLATE_PATH, default_config())
    config = read_json(USER_TEMPLATE_PATH, default_config())
    if ensure_config_defaults(config):
        write_json(USER_TEMPLATE_PATH, config)
    return config


def write_user_template_config(config):
    if not isinstance(config, dict):
        raise ValueError("模板配置格式错误。")
    ensure_config_defaults(config)
    write_json(USER_TEMPLATE_PATH, config)


def reset_user_template_config():
    config = default_config()
    write_user_template_config(config)
    return read_user_template_config()


def copy_user_config_to_template(user_id):
    if not find_user_by_id(user_id):
        raise ValueError("用户不存在。")
    config = read_config(user_id)
    write_user_template_config(config)
    return read_user_template_config()


def should_sync_default_config(actor, user_id):
    if not actor or not is_super(actor):
        return False
    target = find_user_by_id(user_id)
    return bool(target and is_super(target))


def write_config_for_actor(config, user_id, actor):
    path = user_config_path(user_id)
    if path.exists():
        security_backup(f"config-{user_id}", [path])
    write_config(config, user_id)


def json_clone(value):
    return json.loads(json.dumps(value, ensure_ascii=False))


def exportable_config(config):
    cfg = json_clone(config if isinstance(config, dict) else {})
    cfg.pop("_sync", None)
    if not isinstance(cfg.get("app"), dict):
        cfg["app"] = {}
    if not isinstance(cfg.get("pages"), dict):
        cfg["pages"] = {}
    if not isinstance(cfg.get("toolbox_tabs"), list):
        cfg["toolbox_tabs"] = []
    if not isinstance(cfg.get("sidebar"), list):
        cfg["sidebar"] = []
    ensure_config_defaults(cfg)
    return cfg


def config_button_count(config):
    total = 0
    for page in (config.get("pages") or {}).values():
        if not isinstance(page, dict):
            continue
        for section in page.get("sections") or []:
            if isinstance(section, dict):
                total += len(section.get("buttons") or [])
    for tab in config.get("toolbox_tabs") or []:
        if not isinstance(tab, dict):
            continue
        for section in tab.get("sections") or []:
            if isinstance(section, dict):
                total += len(section.get("buttons") or [])
    return total


def config_summary(config):
    cfg = config if isinstance(config, dict) else {}
    return {
        "title": ((cfg.get("app") or {}).get("title") or "Toolbox"),
        "subtitle": ((cfg.get("app") or {}).get("subtitle") or ""),
        "pages": len(cfg.get("pages") or {}),
        "tabs": len(cfg.get("toolbox_tabs") or []),
        "buttons": config_button_count(cfg),
    }


def config_export_package(config, user=None, base_url=""):
    cfg = exportable_config(config)
    summary = config_summary(cfg)
    return {
        "format": "toolbox-config-export",
        "version": 1,
        "exportedAt": now_iso(),
        "title": summary["title"],
        "summary": summary,
        "source": {
            "userId": (user or {}).get("id", ""),
            "name": user_display_name(user or {}),
            "baseUrl": normalize_public_base_url(base_url) if base_url else "",
        },
        "config": cfg,
    }


def normalize_import_config(payload):
    if not isinstance(payload, dict):
        raise ValueError("导入内容必须是 JSON 对象。")
    config = payload.get("config") if isinstance(payload.get("config"), dict) else payload
    if not isinstance(config, dict):
        raise ValueError("导入配置格式错误。")
    if not any(key in config for key in ("app", "sidebar", "toolbox_tabs", "pages", "popup")):
        raise ValueError("没有识别到工具箱配置内容。")
    cfg = exportable_config(config)
    if "app" not in cfg or not isinstance(cfg.get("app"), dict):
        cfg["app"] = default_config()["app"]
    cfg.setdefault("sidebar", [])
    cfg.setdefault("toolbox_tabs", [])
    cfg.setdefault("pages", {})
    return cfg


def read_config_shares():
    data = read_json(CONFIG_SHARES_PATH, {"shares": {}})
    if not isinstance(data, dict):
        data = {"shares": {}}
    shares = data.get("shares")
    if not isinstance(shares, dict):
        data["shares"] = {}
    return data


def write_config_shares(data):
    if not isinstance(data, dict):
        data = {"shares": {}}
    data.setdefault("shares", {})
    write_json(CONFIG_SHARES_PATH, data)


def config_share_url(base_url, token):
    return f"{normalize_public_base_url(base_url).rstrip('/')}/api/public/config-share?token={quote(token)}"


def public_config_share(row, base_url="", include_config=True):
    config = exportable_config(row.get("config") or {})
    payload = {
        "format": "toolbox-config-export",
        "version": 1,
        "cloud": True,
        "shareToken": row.get("token", ""),
        "shareUrl": config_share_url(base_url, row.get("token", "")) if base_url and row.get("token") else "",
        "title": row.get("title") or config_summary(config)["title"],
        "createdAt": row.get("createdAt", ""),
        "source": {
            "userId": row.get("ownerUserId", ""),
            "name": row.get("ownerName", ""),
            "baseUrl": normalize_public_base_url(base_url) if base_url else row.get("baseUrl", ""),
        },
        "summary": config_summary(config),
    }
    if include_config:
        payload["config"] = config
    return payload


def create_config_share(config, user, base_url):
    token = random_hex(18)
    cfg = exportable_config(config)
    summary = config_summary(cfg)
    data = read_config_shares()
    data.setdefault("shares", {})[token] = {
        "token": token,
        "title": summary["title"],
        "ownerUserId": (user or {}).get("id", ""),
        "ownerName": user_display_name(user or {}),
        "baseUrl": normalize_public_base_url(base_url),
        "createdAt": now_iso(),
        "config": cfg,
    }
    write_config_shares(data)
    return public_config_share(data["shares"][token], base_url, include_config=False)


def read_config_share(token):
    token = (token or "").strip()
    if not token:
        raise ValueError("分享链接缺少 token。")
    row = (read_config_shares().get("shares") or {}).get(token)
    if not row:
        raise ValueError("分享链接不存在或已失效。")
    return row


def fetch_remote_config_payload(url):
    text = str(url or "").strip()
    parsed = urlparse(text)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ValueError("请填写 http 或 https 开头的云端链接。")
    req = urllib.request.Request(text, headers={"User-Agent": "ToolboxAdminConfigImporter/1.0", "Accept": "application/json"})
    limit = 3 * 1024 * 1024
    with urllib.request.urlopen(req, timeout=15) as resp:
        length = resp.headers.get("Content-Length")
        if length and int(length) > limit:
            raise ValueError("云端配置文件过大。")
        data = resp.read(limit + 1)
    if len(data) > limit:
        raise ValueError("云端配置文件过大。")
    try:
        return json.loads(data.decode("utf-8-sig"))
    except Exception as exc:
        raise ValueError(f"云端链接没有返回有效 JSON：{exc}")


def _cloud_proxy_download_url(base_url, source_id, api_key):
    path = "/api/cloud-resolver/download-file?sourceId=" + quote(str(source_id)) + "&key=" + quote(str(api_key))
    return (normalize_public_base_url(base_url).rstrip("/") + path) if base_url else path


def _rewrite_cloud_download_sources(cfg, user_id, base_url=""):
    """Expose cloud resources through the server proxy so provider hotlink guards stay server-side."""
    if not cloud_resolver:
        return
    user = find_user_by_id(user_id) or {}
    api_key = str(user.get("apiKey") or "").strip()
    if not api_key:
        return
    store = cloud_resolver._load(_app_context())
    sources = [row for row in store.get("sources", [])
               if row.get("ownerUserId") == user_id and row.get("enabled", True) is not False]
    by_id = {str(row.get("id")): row for row in sources if row.get("id")}
    by_button = {}
    for row in sources:
        by_button.setdefault(str(row.get("buttonId") or ""), []).append(row)
    for rows in by_button.values():
        rows.sort(key=lambda row: (0 if row.get("isPrimary") else 1, int(row.get("priority") or 0), str(row.get("createdAt") or "")))

    def rewrite_button(button):
        if not isinstance(button, dict):
            return
        source_ids = [str(item.get("id")) for item in (button.get("cloudSources") or [])
                      if isinstance(item, dict) and item.get("id")]
        source_rows = [by_id[item_id] for item_id in source_ids if item_id in by_id]
        if not source_rows and button.get("id"):
            source_rows = list(by_button.get(str(button.get("id")), []))
        if not source_rows:
            return
        source_rows.sort(key=lambda row: (0 if row.get("isPrimary") else 1, int(row.get("priority") or 0), str(row.get("createdAt") or "")))
        urls = []
        original_target = str(button.get("download_url") or button.get("url") or button.get("target") or "").strip()
        primary_source_ids = {str(row.get("id")) for row in source_rows if row.get("isPrimary")}
        weiyun_browser_only = all(row.get("provider") == "weiyun" and not (row.get("downloadUrl") or "").strip() for row in source_rows)
        for row in source_rows:
            # Tianyi's public share API cannot provide an anonymous file URL.
            # Xiaofeiji can issue a short-lived direct URL at download time, so
            # keep it behind the local proxy even when the stored URL is empty.
            if row.get("provider") in ("tianyi", "weiyun") and not (row.get("downloadUrl") or "").strip():
                share_url = str(row.get("shareUrl") or "").strip()
                if share_url:
                    urls.append(share_url)
                    continue
            urls.append(_cloud_proxy_download_url(base_url, row["id"], api_key))
        if original_target and original_target not in urls and not primary_source_ids:
            urls.insert(0, original_target)
        manual_backups = button.get("backup_urls") if isinstance(button.get("backup_urls"), list) else []
        if not manual_backups and button.get("backup_url"):
            manual_backups = [button.get("backup_url")]
        for backup in manual_backups:
            backup = str(backup or "").strip()
            if backup and backup not in urls:
                urls.append(backup)
        button["download_url"] = urls[0]
        if weiyun_browser_only:
            button["action"] = "link"
        button["url"] = urls[0]
        button["target"] = urls[0]
        button["backup_urls"] = urls[1:]
        if len(urls) > 1:
            button["backup_url"] = urls[1]
        else:
            button.pop("backup_url", None)

    for page in (cfg.get("pages") or {}).values():
        for section in (page or {}).get("sections") or []:
            for button in (section or {}).get("buttons") or []:
                rewrite_button(button)
    for tab in cfg.get("toolbox_tabs") or []:
        for section in (tab or {}).get("sections") or []:
            for button in (section or {}).get("buttons") or []:
                rewrite_button(button)


def public_toolbox_config(user_id, base_url=""):
    cfg = read_config(user_id)
    app = cfg.setdefault("app", {})
    app.pop("password_plain", None)
    for lock in (cfg.get("page_locks") or {}).values():
        if isinstance(lock, dict): lock.pop("password_plain", None)
    for group in (cfg.get("page_lock_groups") or {}).values():
        if isinstance(group, dict): group.pop("password_plain", None)
    for page in (cfg.get("pages") or {}).values():
        for section in (page or {}).get("sections") or []:
            for button in (section or {}).get("buttons") or []:
                if isinstance(button, dict) and isinstance(button.get("guard"), dict):
                    button["guard"].pop("password_plain", None)
    for tab in cfg.get("toolbox_tabs") or []:
        for section in (tab or {}).get("sections") or []:
            for button in (section or {}).get("buttons") or []:
                if isinstance(button, dict) and isinstance(button.get("guard"), dict):
                    button["guard"].pop("password_plain", None)
    if app.get("password_enabled") is False:
        app["password"] = ""
    normalize_client_config(cfg, user_id=user_id)
    _rewrite_cloud_download_sources(cfg, user_id, base_url)
    resolver_app = _app_context()
    if cloud_resolver and resolver_app:
        resolver_store = cloud_resolver._load(resolver_app)
        cfg["cloudResolver"] = {
            "enabled": bool(resolver_store.get("enabled", True)),
            "apiBase": "/api/cloud-resolver",
        }
    path = user_config_path(user_id)
    meta = dict(cfg.get("_sync") or {})
    meta["userId"] = user_id
    meta["updatedAt"] = int(path.stat().st_mtime) if path.exists() else int(time.time())
    cfg["_sync"] = meta
    return cfg


def file_signature(path):
    try:
        stat = path.stat()
        return stat.st_mtime_ns, stat.st_size
    except OSError:
        return None


def public_toolbox_config_payload(user_id, base_url=""):
    path = user_config_path(user_id)
    signature = (
        file_signature(path),
        file_signature(USERS_PATH),
        file_signature(SYSTEM_PATH),
        file_signature(CLOUD_RESOLVER_PATH),
    )
    with PUBLIC_CONFIG_CACHE_LOCK:
        cached = PUBLIC_CONFIG_CACHE.get(user_id)
        if cached and cached["signature"] == signature:
            return cached["data"], cached["gzip"], cached["etag"]

    payload = public_toolbox_config(user_id, base_url)
    data = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    compressed = gzip.compress(data, compresslevel=5)
    etag = '"' + hashlib.sha256(data).hexdigest() + '"'
    final_signature = (
        file_signature(path),
        file_signature(USERS_PATH),
        file_signature(SYSTEM_PATH),
        file_signature(CLOUD_RESOLVER_PATH),
    )
    with PUBLIC_CONFIG_CACHE_LOCK:
        PUBLIC_CONFIG_CACHE[user_id] = {
            "signature": final_signature,
            "data": data,
            "gzip": compressed,
            "etag": etag,
        }
    return data, compressed, etag


def invalidate_public_config_cache(user_id=None):
    with PUBLIC_CONFIG_CACHE_LOCK:
        if user_id:
            PUBLIC_CONFIG_CACHE.pop(user_id, None)
        else:
            PUBLIC_CONFIG_CACHE.clear()


GLOBAL_BUILTIN_PREFIX = "builtin:"


def builtin_function_rows(include_urls=False):
    rows = []
    configured = {
        str(item.get("id")): item
        for item in read_system_settings().get("builtinFunctions") or []
        if isinstance(item, dict) and item.get("id")
    }
    for function_id, label in SCRIPT_LABELS.items():
        item = configured.pop(function_id, {})
        row = {"id": function_id, "name": str(item.get("name") or label),
               "enabled": item.get("enabled", True) is not False, "builtIn": True,
               "action": str(item.get("action") or "script")}
        if not include_urls and not row["enabled"]:
            continue
        if include_urls:
            row["target"] = str(item.get("target") or item.get("downloadUrl") or "")
            row["downloadUrl"] = row["target"] if row["action"] == "download" else ""
            if row["action"] == "download":
                row["backup_url"] = get_backup_url(item)
                row["backup_page_url"] = get_backup_url(item, True)
        rows.append(row)
    for function_id, item in configured.items():
        if item.get("enabled", True) is False:
            continue
        row = {"id": function_id, "name": str(item.get("name") or "未命名功能"), "enabled": True,
               "builtIn": False, "action": str(item.get("action") or "download")}
        if include_urls:
            row["target"] = str(item.get("target") or item.get("downloadUrl") or "")
            row["downloadUrl"] = row["target"] if row["action"] == "download" else ""
            if row["action"] == "download":
                row["backup_url"] = get_backup_url(item)
                row["backup_page_url"] = get_backup_url(item, True)
        rows.append(row)
    return rows


def find_builtin_function(function_id):
    return next((item for item in builtin_function_rows(True) if item.get("id") == function_id), None)


def proxy_builtin_download(handler):
    api_key = (handler.query.get("key", [""])[0] or handler.headers.get("X-Client-Api-Key", "")).strip()
    if not find_user_by_api_key(api_key):
        return handler.send_json({"error": "工具箱对接密钥无效或账号已停用。"}, 403)
    item = find_builtin_function((handler.query.get("id", [""])[0] or "").strip())
    if not item:
        return handler.send_json({"error": "内置功能不存在或已停用。"}, 404)
    headers = {"User-Agent": "ToolboxClient/1.0"}
    if handler.headers.get("Range"):
        headers["Range"] = handler.headers.get("Range")
    urls = [item.get("target") or item.get("downloadUrl")]
    backup_url = get_backup_url(item)
    if backup_url and backup_url not in urls:
        urls.append(backup_url)
    upstream = None
    active_candidate = None
    for target_url in urls:
        request = urllib.request.Request(target_url, headers=headers)
        try:
            upstream = urllib.request.urlopen(request, timeout=60)
        except urllib.error.HTTPError as exc:
            upstream = exc
        except Exception:
            upstream = None
        if upstream is not None:
            status = getattr(upstream, "status", None) or upstream.getcode()
            if status < 400:
                break
            upstream.close()
            upstream = None
    if upstream is None:
        return handler.send_json({"error": "下载源暂时不可用。"}, 502)
    status = getattr(upstream, "status", None) or upstream.getcode()
    if status >= 400:
        upstream.close()
        return handler.send_json({"error": "下载源暂时不可用。"}, 502)
    handler.send_response(status)
    for header in ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges", "Content-Disposition", "ETag", "Last-Modified"):
        value = upstream.headers.get(header)
        if value:
            handler.send_header(header, value)
    if not upstream.headers.get("Content-Type"):
        handler.send_header("Content-Type", "application/octet-stream")
    handler.send_header("Cache-Control", "private, no-store")
    handler.end_headers()
    if handler.command.upper() != "HEAD":
        shutil.copyfileobj(upstream, handler.wfile, length=1024 * 256)
    upstream.close()


def _refresh_cloud_download_source(source, store, resolver, force=False):
    """Refresh one provider hotlink once for a burst of segmented requests."""
    provider = source.get("provider")
    aggregate = source.get("resolverType") == "qaiu" or provider not in ("lanzou", "mock")
    if not source.get("shareUrl") or (provider != "lanzou" and not aggregate):
        return source
    if aggregate and not force and source.get("downloadUrl"):
        return source
    cache_key = str(source.get("id") or source.get("shareUrl"))
    now = time.monotonic()
    with CLOUD_DOWNLOAD_REFRESH_LOCK:
        cached = CLOUD_DOWNLOAD_REFRESH_CACHE.get(cache_key)
        if cached and now - cached.get("createdAt", 0) < CLOUD_DOWNLOAD_REFRESH_TTL:
            source.update({key: value for key, value in cached.items() if key in ("downloadUrl", "backupUrl", "downloadHeaders")})
            return source
        try:
            access_code = resolver._unprotect(_app_context(), source.get("accessCodeEncrypted"))
            if provider == "lanzou":
                files = resolver._lanzou_parse(source.get("shareUrl"), access_code)
            else:
                api_key = resolver._qaiu_api_key(_app_context(), store)
                files = resolver._provider_parse(provider, source.get("shareUrl"), access_code, api_key)
            match = next((row for row in files if str(row.get("id")) == str(source.get("fileId"))), None)
            if not match or not match.get("downloadUrl"):
                CLOUD_DOWNLOAD_REFRESH_CACHE[cache_key] = {"createdAt": now}
                return source
            source.update({"downloadUrl": match.get("downloadUrl") or "",
                           "backupUrl": match.get("backupUrl") or "",
                           "downloadHeaders": match.get("downloadHeaders") or source.get("downloadHeaders") or {},
                           "resolverType": match.get("resolverType") or ("official" if provider == "lanzou" else "qaiu"),
                           "updatedAt": now_iso(), "status": "draft"})
            CLOUD_DOWNLOAD_REFRESH_CACHE[cache_key] = {
                "createdAt": now,
                "downloadUrl": source.get("downloadUrl") or "",
                "backupUrl": source.get("backupUrl") or "",
                "downloadHeaders": source.get("downloadHeaders") or {},
            }
            resolver._save(_app_context(), store)
        except Exception:
            # Keep the stored URL available as a fallback. The upstream opener
            # still validates the provider response before streaming it.
            CLOUD_DOWNLOAD_REFRESH_CACHE[cache_key] = {"createdAt": now}
            return source
    return source


def _invalidate_cloud_download_cache(source):
    cache_key = str(source.get("id") or source.get("shareUrl") or "")
    if cache_key:
        with CLOUD_DOWNLOAD_REFRESH_LOCK:
            CLOUD_DOWNLOAD_REFRESH_CACHE.pop(cache_key, None)
    source["downloadUrl"] = ""
    source["backupUrl"] = ""


def proxy_cloud_download(handler):
    """Stream a cloud-resolver source through the server after solving provider guards."""
    api_key = (handler.query.get("key", [""])[0] or handler.headers.get("X-Client-Api-Key", "")).strip()
    user = find_user_by_api_key(api_key)
    if not user:
        return handler.send_json({"error": "工具箱对接密钥无效或账号已停用。"}, 403)
    source_id = (handler.query.get("sourceId", [""])[0] or "").strip()
    resolver = cloud_resolver
    if not resolver or not source_id:
        return handler.send_json({"error": "下载源不存在。"}, 404)
    store = resolver._load(_app_context())
    source = next((row for row in store.get("sources", []) if str(row.get("id")) == source_id and row.get("ownerUserId") == user.get("id")), None)
    if not source or source.get("enabled") is False:
        return handler.send_json({"error": "下载源不存在或已停用。"}, 404)
    owner_id = user.get("id")
    source_rows = [row for row in store.get("sources", [])
                   if row.get("ownerUserId") == owner_id
                   and row.get("buttonId") == source.get("buttonId")
                   and row.get("enabled", True) is not False]
    source_rows.sort(key=lambda row: (
        0 if row.get("isPrimary") else 1,
        int(row.get("priority") or 0),
        str(row.get("createdAt") or ""),
    ))
    # Keep the requested source first so a client-selected backup line is honored.
    source_rows = [source] + [row for row in source_rows if row.get("id") != source.get("id")]
    # Lanzou's CDN rejects the client marker used by the desktop app
    # (``ToolboxClient/1.0``) with an HTML anti-hotlink page.  The proxy is
    # the provider-facing hop, so use the same browser-compatible identity
    # as the successful share-page flow while retaining the client's Range.
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
        "Accept": "*/*",
        "Accept-Encoding": "identity",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    }
    if handler.headers.get("Range"):
        headers["Range"] = handler.headers.get("Range")
    if source.get("provider") == "lanzou" and source.get("shareUrl"):
        headers["Referer"] = source.get("shareUrl")
    request_method = handler.command.upper()
    upstream = None
    # A provider hotlink can expire between the client's probe and its first
    # Range request. Retry each source once with a forced fresh official URL,
    # otherwise segmented clients repeatedly hit the same dead URL.
    for refresh_round in range(2):
        for candidate in source_rows:
            if refresh_round:
                _invalidate_cloud_download_cache(candidate)
            candidate = _refresh_cloud_download_source(candidate, store, resolver, force=bool(refresh_round))
            urls = [candidate.get("downloadUrl") or "", candidate.get("backupUrl") or ""]
            for target_url in urls:
                if not target_url:
                    continue
                try:
                    request_headers = dict(headers)
                    for key, value in (candidate.get("downloadHeaders") or {}).items():
                        if key in resolver.QAIU_DOWNLOAD_HEADER_NAMES.values() and isinstance(value, str):
                            request_headers[key] = value
                    if handler.headers.get("Range"):
                        request_headers["Range"] = handler.headers.get("Range")
                    if candidate.get("provider") == "lanzou":
                        upstream = resolver.lanzou_download_response(target_url, headers=request_headers, timeout=60, method=request_method)
                    elif candidate.get("resolverType") == "qaiu":
                        upstream = resolver.qaiu_download_response(target_url, headers=request_headers, timeout=60, method=request_method)
                    else:
                        upstream = urllib.request.urlopen(urllib.request.Request(target_url, headers=request_headers, method=request_method), timeout=60)
                    # A proxy must never turn a full 200 response into a
                    # partial client response. Treat that as a stale or
                    # range-incompatible hotlink and refresh it immediately.
                    if handler.headers.get("Range") and request_method != "HEAD":
                        upstream_status = getattr(upstream, "status", None) or upstream.getcode()
                        if upstream_status != 206:
                            try: upstream.close()
                            except Exception: pass
                            upstream = None
                            _invalidate_cloud_download_cache(candidate)
                            continue
                    if upstream is not None:
                        upstream_status = getattr(upstream, "status", None) or upstream.getcode()
                        if upstream_status < 400:
                            active_candidate = candidate
                            break
                        try: upstream.close()
                        except Exception: pass
                        upstream = None
                except Exception:
                    if upstream is not None:
                        try: upstream.close()
                        except Exception: pass
                    upstream = None
            if upstream is not None:
                break
        if upstream is not None:
            break
    if upstream is None:
        unavailable_provider = any(row.get("provider") == "xiaofeiji" for row in source_rows)
        if unavailable_provider:
            return handler.send_json({"error": "小飞机官方接口未提供可用下载地址，请更换分享链接。", "errorCode": "DOWNLOAD_URL_UNAVAILABLE"}, 410)
        return handler.send_json({"error": "下载源暂时不可用。"}, 502)
    status = getattr(upstream, "status", None) or upstream.getcode()
    handler.send_response(status)
    for header in ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges", "Content-Disposition", "ETag", "Last-Modified"):
        value = upstream.headers.get(header)
        if value:
            handler.send_header(header, value)
    if not upstream.headers.get("Content-Type"):
        handler.send_header("Content-Type", "application/octet-stream")
    handler.send_header("Cache-Control", "private, no-store")
    handler.end_headers()
    try:
        if handler.command.upper() != "HEAD":
            shutil.copyfileobj(upstream, handler.wfile, length=1024 * 256)
    except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
        # The provider stream may have expired after headers were sent. The
        # next client retry must obtain a new signed URL instead of reusing the
        # cached one.
        if active_candidate is not None:
            _invalidate_cloud_download_cache(active_candidate)
    finally:
        upstream.close()


def normalize_client_config(cfg, user_id=""):
    def visible_buttons(buttons):
        return [button for button in buttons or [] if (button or {}).get("enabled", True) is not False]

    def normalize_button(button):
        if not isinstance(button, dict):
            return
        action = button.get("action", "link")
        target = get_target(button)
        if action == "download":
            files = normalize_download_files(button.get("files"))
            if files:
                button["files"] = files
                button["download_mode"] = "multiple" if len(files) > 1 or button.get("download_mode") == "multiple" else "single"
                if not get_backup_url(button) and get_backup_url(files[0]): button["backup_url"] = get_backup_url(files[0])
                if not get_backup_url(button, True) and get_backup_url(files[0], True): button["backup_page_url"] = get_backup_url(files[0], True)
            button["download_url"] = target
            if get_backup_url(button): button["backup_url"] = get_backup_url(button)
            if get_backup_url(button, True): button["backup_page_url"] = get_backup_url(button, True)
            download_directory = str(button.get("download_directory") or button.get("download_path") or "").strip()[:1000]
            if download_directory:
                button["download_directory"] = download_directory
                button["download_delete_on_exit"] = button.get("download_delete_on_exit") is True
            else:
                button.pop("download_directory", None)
                button.pop("download_path", None)
                button.pop("download_delete_on_exit", None)
            button.setdefault("url", target)
            button.setdefault("target", target)
        elif action == "script":
            if str(target).startswith(GLOBAL_BUILTIN_PREFIX) or str(target) in SCRIPT_LABELS:
                function_id = str(target)[len(GLOBAL_BUILTIN_PREFIX):] if str(target).startswith(GLOBAL_BUILTIN_PREFIX) else str(target)
                item = find_builtin_function(function_id)
                if item and item.get("action") == "download" and (item.get("target") or item.get("downloadUrl")):
                    user = find_user_by_id(user_id) if user_id else None
                    api_key = (user or {}).get("apiKey") or ""
                    button["action"] = "download"
                    button["download_url"] = "/api/toolbox/builtin-download?id=" + quote(function_id) + "&key=" + quote(api_key)
                    button["url"] = button["download_url"]
                    button["target"] = button["download_url"]
                    if get_backup_url(item, True): button["backup_page_url"] = get_backup_url(item, True)
                    button["name"] = button.get("name") or item.get("name")
                    return
                if item and item.get("action") not in ("", "script") and item.get("target"):
                    global_action = item.get("action")
                    global_target = item.get("target")
                    button["action"] = global_action
                    button["target"] = global_target
                    if global_action == "link": button["url"] = global_target
                    elif global_action == "cmd": button["command"] = global_target
                    elif global_action == "winget": button["package_id"] = global_target
                    return
            button["script_id"] = target
            button.setdefault("script", target)
            if target not in SCRIPT_LABELS:
                button["custom_script"] = target
            button.setdefault("target", target)
        elif action == "cmd":
            button["command"] = target
            button.setdefault("target", target)
        elif action == "winget":
            button["package_id"] = target
            button.setdefault("winget", target)
            button.setdefault("package", target)
            button.setdefault("target", target)
        else:
            button["url"] = target
            button.setdefault("target", target)

    def normalize_sections(sections):
        for section in sections or []:
            if isinstance(section, dict):
                section["buttons"] = visible_buttons(section.get("buttons") or [])
            for button in (section or {}).get("buttons") or []:
                normalize_button(button)

    for page in (cfg.get("pages") or {}).values():
        normalize_sections((page or {}).get("sections") or [])
    for tab in cfg.get("toolbox_tabs") or []:
        normalize_sections((tab or {}).get("sections") or [])


def inject_update_entry(cfg):
    # 更新由客户端启动时的版本弹窗处理，不再向侧栏注入独立更新页面。
    return


def public_brand_config():
    app = read_config("").get("app", {})
    return {
        "title": app.get("admin_title") or DEFAULT_ADMIN_TITLE,
        "hint": app.get("login_hint") or DEFAULT_LOGIN_HINT,
        "icon": app.get("icon") or DEFAULT_APP_ICON,
        "logoText": app.get("logo_text") or "Y",
    }


def sync_public_brand_config(app_patch):
    keys = ("admin_title", "login_hint", "icon", "icon_url", "logo_text")
    if not any(key in app_patch for key in keys):
        return
    cfg = read_config("")
    app = cfg.setdefault("app", {})
    for key in keys:
        if key in app_patch:
            app[key] = app_patch[key]
    write_config(cfg, "")


def apply_app_patch(config, patch):
    app = config.setdefault("app", {})
    for key, value in patch.items():
        if key == "password_enabled" and not value:
            app["password_enabled"] = False
        elif key == "password_enabled":
            app["password_enabled"] = True
        elif key == "password":
            plain = str(value or "")
            app["password"] = stored_password(plain) if plain else ""
            app["password_plain"] = plain
        elif key == "default_view_mode":
            app[key] = normalize_view_mode(value, "grid")
        elif key == "button_content_layout":
            app[key] = normalize_button_content_layout(value)
        elif key == "button_content_layout_rules" and isinstance(value, dict):
            app[key] = value
        else:
            app[key] = value
    ensure_config_defaults(config)
    return config


def read_users():
    DATA.mkdir(parents=True, exist_ok=True)
    USER_DATA.mkdir(parents=True, exist_ok=True)
    store = read_json(USERS_PATH, {"users": [], "inviteCodes": []})
    store.setdefault("users", [])
    store.setdefault("inviteCodes", [])
    store.setdefault("settings", {})
    changed = False
    settings = read_system_settings()
    for user in store["users"]:
        if (user.get("id") == "admin" and check_password("dev-token", user.get("passwordHash", ""))
                and len(ADMIN_TOKEN) >= 12 and ADMIN_TOKEN.lower() != "dev-token"):
            user["passwordHash"] = stored_password(ADMIN_TOKEN)
            changed = True
            audit_event("default_admin_password_migrated", actor=user)
        role = normalize_role(user.get("role"))
        if user.get("role") != role:
            user["role"] = role
            changed = True
        if role == "agent":
            try:
                balance = round(float(user.get("balance") or 0), 2)
            except (TypeError, ValueError):
                balance = 0.0
            if balance < 0:
                balance = 0.0
            if user.get("balance") != balance:
                user["balance"] = balance
                changed = True
            if "parentAgentId" not in user:
                user["parentAgentId"] = ""
                changed = True
            level = resolve_agent_level(user, settings, user.get("agentLevelId"))
            if user.get("agentLevelId") != level.get("id"):
                user["agentLevelId"] = level.get("id")
                changed = True
            if user.get("agentLevelName") != level.get("name"):
                user["agentLevelName"] = level.get("name")
                changed = True
        elif "balance" in user:
            user.pop("balance", None)
            changed = True
        if role != "agent":
            for key in ("agentLevelId", "agentLevelName"):
                if key in user:
                    user.pop(key, None)
                    changed = True
        if role != "user" and user.get("parentAgentId"):
            user["parentAgentId"] = ""
            changed = True
    for invite in store["inviteCodes"]:
        # 停用状态需要记录操作者。没有历史标记的旧数据按总管理员停用处理，
        # 这样代理不能通过 PATCH active=true 绕过总管理员的停用决定。
        if (invite.get("active") is False and int(invite.get("usedCount") or 0) <= 0
                and "superDisabled" not in invite):
            invite["superDisabled"] = invite.get("disabledByRole") != "agent"
            if invite["superDisabled"]:
                invite["disabledByRole"] = "super"
                invite["disabledById"] = invite.get("disabledById") or "legacy"
            changed = True
        if "price" in invite:
            try:
                normalized_price = round(float(invite.get("price") or 0), 2)
            except (TypeError, ValueError):
                normalized_price = 0.0
            if invite.get("price") != normalized_price:
                invite["price"] = normalized_price
                changed = True
        if "chargedAmount" in invite:
            try:
                normalized_charge = round(float(invite.get("chargedAmount") or 0), 2)
            except (TypeError, ValueError):
                normalized_charge = 0.0
            if invite.get("chargedAmount") != normalized_charge:
                invite["chargedAmount"] = normalized_charge
                changed = True
    cleanup_invites(store)
    if not store["users"]:
        if len(ADMIN_TOKEN) < 12 or ADMIN_TOKEN.lower() in ("dev-token", "password", "admin"):
            raise RuntimeError("首次启动必须通过 TOOLBOX_ADMIN_TOKEN 设置至少 12 位的管理员密码。")
        admin = {
            "id": "admin",
            "username": ADMIN_USERNAME,
            "displayName": "总管理员",
            "role": "super",
            "active": True,
            "canViewJson": True,
            "passwordHash": stored_password(ADMIN_TOKEN),
            "apiKey": random_hex(20),
            "createdAt": now_iso(),
        }
        store["users"] = [admin]
        write_json(USERS_PATH, store)
        write_config(read_config(""), "admin")
    elif changed:
        write_json(USERS_PATH, store)
    return store


def write_users(store):
    store.setdefault("users", [])
    store.setdefault("inviteCodes", [])
    store.setdefault("settings", {})
    cleanup_invites(store)
    write_json(USERS_PATH, store)
    with API_KEY_CACHE_LOCK:
        API_KEY_CACHE["signature"] = None
        API_KEY_CACHE["users"] = {}
    invalidate_public_config_cache()


def is_super(user):
    return user.get("role") == "super"


def is_agent(user):
    return user.get("role") == "agent"


def can_manage_users(user):
    return is_super(user) or is_agent(user)


def role_label(role):
    return {"super": "总管理员", "agent": "代理", "user": "普通用户"}.get(role, "普通用户")


def is_login_api_path(path):
    normalized = "/" + str(path or "").strip("/").lower()
    return normalized in ("/api/login", "/desktop/login") or normalized.endswith("/api/login") or normalized.endswith("/desktop/login")


def handle_desktop_login(handler):
    body = handler.read_body()
    username = (body.get("username") or "").strip()
    key = f"{client_ip(handler)}:{username.lower()}"
    now = time.time()
    attempts = [stamp for stamp in LOGIN_ATTEMPTS.get(key, []) if now - stamp < LOGIN_WINDOW_SECONDS]
    if len(attempts) >= LOGIN_MAX_FAILURES:
        audit_event("login_blocked", target=username, handler=handler, success=False)
        return handler.send_json({"error": "登录尝试过多，请 15 分钟后重试。"}, 429)
    user = find_user_by_username(username)
    if not user or user.get("active", True) is False or not check_password(str(body.get("password") or ""), user.get("passwordHash", "")):
        attempts.append(now)
        LOGIN_ATTEMPTS[key] = attempts
        audit_event("login_failed", target=username, handler=handler, success=False)
        return handler.send_json({"error": "用户名或密码错误。"}, 401)
    LOGIN_ATTEMPTS.pop(key, None)
    token = random_hex(32)
    user = mark_user_login(user["id"], handler)
    SESSIONS[token] = {"userId": user["id"], "createdAt": now_iso(), "lastSeenAt": now_iso()}
    save_sessions()
    audit_event("login_success", actor=user, handler=handler)
    return handler.send_json({"token": token, "user": public_user(user)})


def default_system_settings():
    return {
        "cloudResolverOrderExpiryMinutes": 30,
        "cloudResolverDiagnosticsEnabled": False,
        "builtinFunctions": [],
        "menuIconFolders": [{"id": "default", "name": "默认", "sort": 0}],
        "menuIcons": [],
        "locations": {
            "noticeAreaTitle": "全部未读",
            "adminSystemName": "系统管理",
            "frontendActiveGlow": True,
            "frontendShowGroupCount": True,
        },
        "agent": {
            "invitePrice": 0,
            "cloudCodePrice": 0,
            "currency": "CNY",
            "allowNegativeBalance": False,
            "orderCooldownMinutes": 30,
            "levels": [{
                "id": "level-default",
                "name": "默认代理级别",
                "price": 0,
                "sort": 10,
                "enabled": True,
            }],
        },
        "pay": {
            "wechatChannel": "disabled",
            "alipayChannel": "disabled",
            "wechatOrder": 10,
            "alipayOrder": 20,
            "easypay": {"enabled": False, "name": "", "apiUrl": "", "pid": "", "key": "", "notifyUrl": "", "returnUrl": "", "mapiUrl": "", "pcScan": False},
            "easypay2": {"enabled": False, "name": "", "apiUrl": "", "pid": "", "key": "", "notifyUrl": "", "returnUrl": "", "mapiUrl": "", "pcScan": False},
            "alipayOfficial": {"enabled": False, "appId": "", "privateKey": "", "publicKey": "", "gateway": "", "notifyUrl": "", "returnUrl": ""},
            "wechatOfficial": {"enabled": False, "mchId": "", "appId": "", "apiV3Key": "", "serialNo": "", "privateKey": "", "notifyUrl": ""},
        },
        "clientBuild": {
            "cacheRetentionHours": 24,
            "jobRetentionHours": 24,
            "cleanupIntervalMinutes": 360,
            "maxCacheEntries": 30,
        },
        "clientVariants": {
            variant_id: {
                "name": variant.get("label", ""),
                "badge": "",
                "description": variant.get("description", ""),
                "coverMode": "default",
                "coverUrl": "",
            }
            for variant_id, variant in CLIENT_VARIANTS.items()
        },
        "menuIcons": [],
        "menuIconLibraryUrl": "",
        "menuIconLibraryToken": "",
        "menuIconLibraryUsername": "",
        "menuIconLibraryPassword": "",
        "ipLocation": {"mode": "consensus", "threshold": 2, "providers": ["amap", "tencent", "ip-api", "ipapi-co", "pconline"], "unifiedChinese": True,
            "amapKey": "", "amapSecret": "", "baiduKey": "", "tencentKey": "", "tencentSecret": ""},
        "integrity": {
            "enabled": True,
            "secret": "",
            "tokenTtlMinutes": 10080,
            "lockBuildAfterFirstIssue": False,
        },
    }


def normalize_agent_levels(value, fallback_price=0):
    """Normalize configurable agent levels while keeping old single-price data usable."""
    rows = []
    used_ids = set()
    if isinstance(value, list):
        for index, source in enumerate(value[:100]):
            if not isinstance(source, dict):
                continue
            level_id = re.sub(r"[^a-zA-Z0-9_-]", "", str(source.get("id") or ""))
            if not level_id:
                level_id = f"level-{index + 1}"
            if level_id in used_ids:
                level_id = f"{level_id}-{index + 1}"
            used_ids.add(level_id)
            name = str(source.get("name") or "").strip()[:80]
            if not name:
                name = f"代理级别 {index + 1}"
            try:
                price = round(float(source.get("price") or 0), 2)
            except (TypeError, ValueError):
                price = 0.0
            if price < 0:
                price = 0.0
            try:
                sort = max(-999999, min(999999, int(source.get("sort", (index + 1) * 10))))
            except (TypeError, ValueError):
                sort = (index + 1) * 10
            rows.append({
                "id": level_id,
                "name": name,
                "price": price,
                "sort": sort,
                "enabled": source.get("enabled", True) is not False,
            })
    if not rows:
        try:
            price = round(float(fallback_price or 0), 2)
        except (TypeError, ValueError):
            price = 0.0
        rows = [{"id": "level-default", "name": "默认代理级别", "price": max(0, price), "sort": 10, "enabled": True}]
    if not any(row["enabled"] for row in rows):
        rows[0]["enabled"] = True
    return sorted(rows, key=lambda row: (row.get("sort", 0), row.get("name", "")))


def agent_levels(settings=None, enabled_only=False):
    settings = settings or read_system_settings()
    agent = settings.get("agent") or {}
    rows = normalize_agent_levels(agent.get("levels"), agent.get("invitePrice", 0))
    return [row for row in rows if row.get("enabled") is not False] if enabled_only else rows


def resolve_agent_level(user=None, settings=None, requested_id="", enabled_only=False):
    rows = agent_levels(settings, enabled_only=enabled_only)
    requested_id = str(requested_id or (user or {}).get("agentLevelId") or "").strip()
    match = next((row for row in rows if row.get("id") == requested_id), None)
    if match:
        return match
    return rows[0] if rows else {"id": "level-default", "name": "默认代理级别", "price": 0, "sort": 10, "enabled": True}


def http_url(value):
    text = str(value or "").strip()
    return text if text.lower().startswith(("http://", "https://")) else ""


def popup_image_url(value):
    text = str(value or "").strip()
    return text if text.lower().startswith(("http://", "https://")) else ""


def popup_abs_url(value, base_url):
    text = str(value or "").strip()
    if text.lower().startswith(("http://", "https://")):
        return text
    if text.startswith("/"):
        return base_url.rstrip("/") + text
    return text


def popup_int(value, fallback, minimum=0, maximum=9999):
    try:
        return max(minimum, min(maximum, int(value)))
    except Exception:
        return fallback


def normalize_popup_qr_items(items):
    rows = []
    if not isinstance(items, list):
        return rows
    for index, item in enumerate(items):
        if not isinstance(item, dict):
            continue
        row = {
            "title": str(item.get("title") or "").strip(),
            "description": str(item.get("description") or "").strip(),
            "image": popup_image_url(item.get("image")),
            "enabled": item.get("enabled", True) is not False,
            "sort": popup_int(item.get("sort"), index + 1, -999999, 999999),
            "buttonText": str(item.get("buttonText") or "").strip(),
            "buttonUrl": http_url(item.get("buttonUrl")),
        }
        rows.append(row)
    return rows


def normalize_popup_links(items):
    rows = []
    if not isinstance(items, list):
        return rows
    for index, item in enumerate(items):
        if not isinstance(item, dict):
            continue
        row = {
            "title": str(item.get("title") or item.get("name") or "").strip(),
            "description": str(item.get("description") or "").strip(),
            "url": http_url(item.get("url")),
            "buttonText": str(item.get("buttonText") or "打开链接").strip() or "打开链接",
            "enabled": item.get("enabled", True) is not False,
            "sort": popup_int(item.get("sort"), index + 1, -999999, 999999),
        }
        rows.append(row)
    return rows


def normalize_popup_settings(value):
    default = default_popup_settings()
    popup = value if isinstance(value, dict) else {}
    normalized = {
        "enabled": popup.get("enabled", default["enabled"]) is True,
        "clickCount": popup_int(popup.get("clickCount"), default["clickCount"], 1, 20),
        "title": str(popup.get("title") or default["title"]).strip() or default["title"],
        "thanksText": str(popup.get("thanksText") or default["thanksText"]).strip() or default["thanksText"],
        "cacheMinutes": popup_int(popup.get("cacheMinutes"), default["cacheMinutes"], 0, 1440),
        "contacts": normalize_popup_qr_items(popup.get("contacts")),
        "payments": normalize_popup_qr_items(popup.get("payments")),
        "links": normalize_popup_links(popup.get("links")),
    }
    return normalized


def public_popup_config(user_id, base_url):
    popup = normalize_popup_settings(read_config(user_id).get("popup") or {})
    def public_qr_rows(rows):
        result = []
        for row in sorted([x for x in rows if x.get("enabled")], key=lambda x: (x.get("sort", 0), x.get("title", ""))):
            result.append({
                "title": row.get("title") or "",
                "description": row.get("description") or "",
                "image": popup_abs_url(row.get("image") or "", base_url),
                "enabled": True,
                "sort": row.get("sort", 0),
                "buttonText": row.get("buttonText") or "",
                "buttonUrl": row.get("buttonUrl") or "",
            })
        return result

    links = []
    for row in sorted([x for x in popup.get("links", []) if x.get("enabled") and x.get("url")], key=lambda x: (x.get("sort", 0), x.get("title", ""))):
        links.append({
            "title": row.get("title") or "",
            "description": row.get("description") or "",
            "url": row.get("url") or "",
            "buttonText": row.get("buttonText") or "打开链接",
            "enabled": True,
            "sort": row.get("sort", 0),
        })
    cache_minutes = popup_int(popup.get("cacheMinutes"), 60, 0, 1440)
    return {
        "enabled": popup.get("enabled") is True,
        "clickCount": popup_int(popup.get("clickCount"), 3, 1, 20),
        "title": popup.get("title") or "联系我们 / 支持作者",
        "thanksText": popup.get("thanksText") or "",
        "cacheMinutes": cache_minutes,
        "cacheSeconds": cache_minutes * 60,
        "contacts": public_qr_rows(popup.get("contacts", [])),
        "payments": public_qr_rows(popup.get("payments", [])),
        "links": links,
    }


def read_system_settings():
    data = read_json(SYSTEM_PATH, default_system_settings())
    defaults = default_system_settings()
    raw_agent = data.get("agent") if isinstance(data.get("agent"), dict) else {}
    had_agent_levels = "levels" in raw_agent
    legacy_agent_price = raw_agent.get("invitePrice", 0)
    changed = False
    for key, value in defaults.items():
        if isinstance(value, dict):
            if key not in data or not isinstance(data.get(key), dict):
                data[key] = {}
                changed = True
            for sub_key, sub_value in value.items():
                if isinstance(sub_value, dict):
                    if sub_key not in data[key] or not isinstance(data[key].get(sub_key), dict):
                        data[key][sub_key] = {}
                        changed = True
                    for item_key, item_value in sub_value.items():
                        if item_key not in data[key][sub_key]:
                            data[key][sub_key][item_key] = item_value
                            changed = True
                else:
                    if sub_key not in data[key]:
                        data[key][sub_key] = sub_value
                        changed = True
        else:
            if key not in data:
                data[key] = value
                changed = True
    pay = data.get("pay") or {}
    agent = data.setdefault("agent", {})
    normalized_levels = normalize_agent_levels(agent.get("levels") if had_agent_levels else None, legacy_agent_price)
    if agent.get("levels") != normalized_levels:
        agent["levels"] = normalized_levels
        changed = True
    try:
        normalized_legacy_price = round(float(agent.get("invitePrice") or 0), 2)
    except (TypeError, ValueError):
        normalized_legacy_price = 0.0
    if normalized_legacy_price < 0:
        normalized_legacy_price = 0.0
    if agent.get("invitePrice") != normalized_legacy_price:
        agent["invitePrice"] = normalized_legacy_price
        changed = True
    for selected_key in (pay.get("wechatChannel"), pay.get("alipayChannel")):
        if selected_key and selected_key != "disabled" and isinstance(pay.get(selected_key), dict):
            pay[selected_key].setdefault("enabled", True)
    if "popup" in data:
        data.pop("popup", None)
        changed = True
    integrity = data.setdefault("integrity", {})
    if len(str(integrity.get("secret") or "").strip()) < 32:
        integrity["secret"] = random_hex(24)
        changed = True
    if changed:
        write_json(SYSTEM_PATH, data)
    return data


def public_system_settings():
    data = read_system_settings()
    public = json.loads(json.dumps(data, ensure_ascii=False))
    public.pop("popup", None)
    public["builtinFunctions"] = builtin_function_rows(True)
    if isinstance(public.get("integrity"), dict):
        public["integrity"]["secret"] = ""
        public["integrity"]["secretConfigured"] = True
    return public


def cache_library_icon(source_url, token=""):
    digest = hashlib.sha256(source_url.encode("utf-8")).hexdigest()
    parsed = urlparse(source_url)
    suffix = Path(parsed.path).suffix.lower()
    if suffix not in (".png", ".jpg", ".jpeg", ".webp", ".gif", ".ico", ".bmp"):
        suffix = ".png"
    target = MENU_ICON_LIBRARY_DIR / (digest + suffix)
    if target.exists() and target.stat().st_size:
        return "/uploads/menu-icon-library/" + target.name
    headers = {"User-Agent": "ToolboxAdmin/1.0"}
    if token:
        headers["Authorization"] = "Bearer " + token
    request = urllib.request.Request(source_url, headers=headers)
    with urllib.request.urlopen(request, timeout=12) as response:
        raw = response.read(5 * 1024 * 1024 + 1)
        content_type = str(response.headers.get("Content-Type") or "").lower()
    if len(raw) > 5 * 1024 * 1024 or not raw or (content_type and "image/" not in content_type):
        raise ValueError("图标文件格式无效或超过 5MB")
    MENU_ICON_LIBRARY_DIR.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(target.name + "." + secrets.token_hex(4) + ".tmp")
    temporary.write_bytes(raw)
    os.replace(str(temporary), str(target))
    return "/uploads/menu-icon-library/" + target.name


def openlist_icon_sources(library_url, token):
    parsed = urlparse(library_url)
    path = unquote(parsed.path or "/")
    if path.startswith("/d/"):
        path = path[2:]
    elif path == "/d":
        path = "/"
    api_url = parsed.scheme + "://" + parsed.netloc + "/api/fs/list"
    body = json.dumps({"path": path, "password": "", "page": 1, "per_page": 500, "refresh": False}).encode("utf-8")
    headers = {"Content-Type": "application/json", "User-Agent": "ToolboxAdmin/1.0"}
    if token:
        headers["Authorization"] = "Bearer " + token
    request = urllib.request.Request(api_url, data=body, headers=headers, method="POST")
    with urllib.request.urlopen(request, timeout=12) as response:
        payload = json.loads(response.read(2 * 1024 * 1024).decode("utf-8-sig"))
    if int(payload.get("code") or 0) != 200:
        message = str(payload.get("message") or "目录接口拒绝访问")
        if "guest user is disabled" in message.lower():
            message = "目录禁止游客访问，请填写图标库登录账号和密码或访问令牌"
        raise ValueError(message)
    content = ((payload.get("data") or {}).get("content") or [])
    rows = []
    image_suffixes = (".png", ".jpg", ".jpeg", ".webp", ".gif", ".ico", ".bmp")
    for item in content:
        name = str(item.get("name") or "").strip()
        if item.get("is_dir") or not name.lower().endswith(image_suffixes):
            continue
        raw_url = str(item.get("raw_url") or "").strip()
        if not raw_url:
            raw_url = parsed.scheme + "://" + parsed.netloc + "/d" + quote(path.rstrip("/") + "/" + name, safe="/")
        rows.append({"name": Path(name).stem, "url": raw_url})
    return rows


def openlist_login(library_url, username, password):
    parsed = urlparse(library_url)
    api_url = parsed.scheme + "://" + parsed.netloc + "/api/auth/login"
    body = json.dumps({"username": username, "password": password, "otp_code": ""}).encode("utf-8")
    request = urllib.request.Request(api_url, data=body, headers={"Content-Type": "application/json", "User-Agent": "ToolboxAdmin/1.0"}, method="POST")
    with urllib.request.urlopen(request, timeout=12) as response:
        payload = json.loads(response.read(1024 * 1024).decode("utf-8-sig"))
    if int(payload.get("code") or 0) != 200:
        raise ValueError(payload.get("message") or "图标库账号或密码错误")
    token = str((payload.get("data") or {}).get("token") or "").strip()
    if not token:
        raise ValueError("图标库登录成功但未返回访问令牌")
    return token


def cached_openlist_token(library_url, username, password, force=False):
    parsed = urlparse(library_url)
    key = (parsed.scheme.lower(), parsed.netloc.lower(), str(username))
    with MENU_ICON_LIBRARY_LOGIN_LOCK:
        cached = MENU_ICON_LIBRARY_TOKEN_CACHE.get(key) or {}
        if not force and cached.get("token") and time.time() - float(cached.get("created") or 0) < 1800:
            return cached["token"]
        token = openlist_login(library_url, username, password)
        MENU_ICON_LIBRARY_TOKEN_CACHE[key] = {"token": token, "created": time.time()}
        return token


def read_remote_menu_icons(library_url, token="", username="", password=""):
    library_url = str(library_url or "").strip()
    if not library_url:
        return [], ""
    try:
        token = str(token or "").strip()
        account_login = not token and bool(username and password)
        if account_login:
            token = cached_openlist_token(library_url, str(username), str(password))
        headers = {
            "Accept": "application/json, text/plain;q=0.9, */*;q=0.1",
            "User-Agent": "ToolboxAdmin/1.0",
        }
        if token:
            headers["Authorization"] = "Bearer " + token
        request = urllib.request.Request(library_url, headers=headers)
        with urllib.request.urlopen(request, timeout=8) as response:
            raw = response.read(1024 * 1024 + 1)
            final_url = response.geturl()
            content_type = str(response.headers.get("Content-Type") or "").lower()
        if len(raw) > 1024 * 1024:
            raise ValueError("图标库清单不能超过 1MB")
        text = raw.decode("utf-8-sig", errors="replace").strip()
        sources = None
        if "text/html" in content_type or text[:100].lower().startswith(("<!doctype html", "<html")):
            try:
                sources = openlist_icon_sources(library_url, token)
            except ValueError as exc:
                if account_login and "token is invalidated" in str(exc).lower():
                    token = cached_openlist_token(library_url, str(username), str(password), force=True)
                    sources = openlist_icon_sources(library_url, token)
                else:
                    raise
        try:
            payload = json.loads(text)
            if isinstance(payload, dict):
                payload = payload.get("icons", payload.get("files", []))
            if isinstance(payload, list):
                sources = payload
        except json.JSONDecodeError:
            pass
        if sources is None:
            if "<html" in text[:500].lower() or "<!doctype" in text[:100].lower():
                raise ValueError("该地址是网页而不是图标清单，请填写访问令牌后重试")
            sources = []
            for line in text.splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "|" in line:
                    name, icon_url = line.split("|", 1)
                    sources.append({"name": name.strip(), "url": icon_url.strip()})
                else:
                    sources.append(line)

        icons = []
        used = set()
        candidates = []
        for source in sources[:500]:
            if isinstance(source, str):
                icon_url = source.strip()
                name = Path(urlparse(icon_url).path).stem
            elif isinstance(source, dict):
                icon_url = str(source.get("url") or source.get("downloadUrl") or source.get("link") or "").strip()
                name = str(source.get("name") or source.get("title") or "").strip()
            else:
                continue
            icon_url = urljoin(final_url, icon_url)
            if not http_url(icon_url) or icon_url in used:
                continue
            used.add(icon_url)
            candidates.append((icon_url, (name or Path(urlparse(icon_url).path).stem or "图标")[:80]))
        if not candidates:
            directory = unquote(urlparse(library_url).path or "/")
            raise ValueError("目录读取成功，但未发现图片文件，当前目录：" + directory)

        def build_icon(candidate):
            icon_url, icon_name = candidate
            cached_url = cache_library_icon(icon_url, token)
            return {
                "id": "library_" + hashlib.sha256(icon_url.encode("utf-8")).hexdigest()[:16],
                "name": icon_name,
                "url": cached_url,
                "library": True,
            }

        failures = []
        with ThreadPoolExecutor(max_workers=min(12, len(candidates))) as executor:
            futures = {executor.submit(build_icon, candidate): candidate for candidate in candidates}
            for future in as_completed(futures):
                try:
                    icons.append(future.result())
                except Exception as exc:
                    failures.append(str(exc))
        icons.sort(key=lambda item: item.get("name", "").lower())
        if not icons:
            raise ValueError("目录中发现图片，但缓存全部失败：" + (failures[0] if failures else "未知错误"))
        return icons, ""
    except Exception as exc:
        return [], "图标库读取失败：" + str(exc)[:160]


def write_system_settings(body):
    current = read_system_settings()
    if "cloudResolverDiagnosticsEnabled" in body:
        current["cloudResolverDiagnosticsEnabled"] = body.get("cloudResolverDiagnosticsEnabled") is True
    if "cloudResolverOrderExpiryMinutes" in body:
        try:
            current["cloudResolverOrderExpiryMinutes"] = max(1, min(10080, int(body.get("cloudResolverOrderExpiryMinutes") or 1)))
        except (TypeError, ValueError):
            raise ValueError("网盘订单有效时间必须是 1 到 10080 分钟之间的整数。")
    if isinstance(body.get("menuIconFolders"), list):
        folders = []
        used = set()
        used_names = set()
        for index, source in enumerate(body.get("menuIconFolders")[:100]):
            if not isinstance(source, dict):
                continue
            folder_id = re.sub(r"[^a-zA-Z0-9_-]", "", str(source.get("id") or "")) or new_id("folder")
            name = str(source.get("name") or "").strip()[:80]
            name_key = name.casefold()
            if not name or folder_id in used or name_key in used_names:
                continue
            used.add(folder_id)
            used_names.add(name_key)
            try:
                sort = max(-999999, min(999999, int(source.get("sort", index))))
            except (TypeError, ValueError):
                sort = index
            folders.append({"id": folder_id, "name": name, "sort": sort})
        if not any(item["id"] == "default" for item in folders):
            folders.insert(0, {"id": "default", "name": "默认", "sort": -999999})
        current["menuIconFolders"] = folders
    if "menuIconLibraryUrl" in body:
        library_url = str(body.get("menuIconLibraryUrl") or "").strip()[:1000]
        if library_url and not http_url(library_url):
            raise ValueError("图标库清单地址必须是 HTTP/HTTPS 地址。")
        current["menuIconLibraryUrl"] = library_url
    if "menuIconLibraryToken" in body:
        current["menuIconLibraryToken"] = str(body.get("menuIconLibraryToken") or "").strip()[:4000]
    if "menuIconLibraryUsername" in body:
        current["menuIconLibraryUsername"] = str(body.get("menuIconLibraryUsername") or "").strip()[:200]
    if "menuIconLibraryPassword" in body:
        current["menuIconLibraryPassword"] = str(body.get("menuIconLibraryPassword") or "")[:500]
    if isinstance(body.get("menuIcons"), list):
        current["menuIconLibraryUrl"] = ""
        current["menuIconLibraryToken"] = ""
        current["menuIconLibraryUsername"] = ""
        current["menuIconLibraryPassword"] = ""
        rows = []
        used = set()
        for source in body.get("menuIcons")[:500]:
            if not isinstance(source, dict):
                continue
            icon_id = re.sub(r"[^a-zA-Z0-9_-]", "", str(source.get("id") or "")) or new_id("icon")
            name = str(source.get("name") or "").strip()[:80]
            url = str(source.get("url") or "").strip()[:1000]
            valid_url = http_url(url) or (url if url.startswith("/uploads/menu-icons/") else "")
            if not name or not valid_url or icon_id in used:
                continue
            used.add(icon_id)
            folder_id = re.sub(r"[^a-zA-Z0-9_-]", "", str(source.get("folderId") or "default")) or "default"
            try:
                sort = max(-999999, min(999999, int(source.get("sort", 0))))
            except (TypeError, ValueError):
                sort = 0
            rows.append({"id": icon_id, "name": name, "url": valid_url, "folderId": folder_id, "sort": sort})
        current["menuIcons"] = rows
    if isinstance(body.get("builtinFunctions"), list):
        rows = []
        used = set()
        for source in body.get("builtinFunctions"):
            if not isinstance(source, dict):
                continue
            function_id = re.sub(r"[^a-zA-Z0-9_-]", "", str(source.get("id") or "")) or new_id("builtin")
            if function_id in used:
                raise ValueError("内置功能 ID 不能重复。")
            name = str(source.get("name") or "").strip()
            action = str(source.get("action") or ("script" if function_id in SCRIPT_LABELS else "download"))
            if action not in ("link", "download", "cmd", "script", "winget"):
                raise ValueError("不支持的内置功能动作。")
            target = str(source.get("target") or source.get("downloadUrl") or "").strip()
            if action in ("link", "download") and target and not http_url(target):
                raise ValueError("网页和下载动作必须填写 HTTP/HTTPS 地址。")
            if not name:
                raise ValueError("内置功能名称不能为空。")
            if action != "script" and not target:
                raise ValueError("内置功能的目标内容不能为空。")
            if action == "script" and function_id not in SCRIPT_LABELS and not target:
                raise ValueError("自定义内置功能请选择或填写要执行的内置功能。")
            used.add(function_id)
            row = {"id": function_id, "name": name, "action": action, "target": target,
                   "downloadUrl": target if action == "download" else "",
                   "enabled": source.get("enabled", True) is not False}
            if action == "download":
                if get_backup_url(source): row["backup_url"] = get_backup_url(source)
                if get_backup_url(source, True): row["backup_page_url"] = get_backup_url(source, True)
            rows.append(row)
        current["builtinFunctions"] = rows
    for section in ("locations", "agent", "pay", "integrity", "clientBuild", "clientVariants", "ipLocation"):
        patch = body.get(section)
        if not isinstance(patch, dict):
            continue
        if section == "agent":
            current_agent = current.setdefault("agent", {})
            has_levels = "levels" in patch
            if "invitePrice" in patch:
                try:
                    current_agent["invitePrice"] = max(0, round(float(patch.get("invitePrice") or 0), 2))
                except (TypeError, ValueError):
                    raise ValueError("每个邀请码扣费必须是数字。")
            if "currency" in patch:
                current_agent["currency"] = str(patch.get("currency") or "CNY").strip()[:12] or "CNY"
            if "cloudCodePrice" in patch:
                try:
                    current_agent["cloudCodePrice"] = max(0, round(float(patch.get("cloudCodePrice") or 0), 2))
                except (TypeError, ValueError):
                    raise ValueError("网盘激活码扣费必须是数字。")
            if "orderCooldownMinutes" in patch:
                try:
                    current_agent["orderCooldownMinutes"] = max(0, min(10080, int(patch.get("orderCooldownMinutes") or 0)))
                except (TypeError, ValueError):
                    current_agent["orderCooldownMinutes"] = 30
            if "allowNegativeBalance" in patch:
                current_agent["allowNegativeBalance"] = bool(patch.get("allowNegativeBalance"))
            if "levels" in patch:
                current_agent["levels"] = normalize_agent_levels(patch.get("levels"), current_agent.get("invitePrice", 0))
            elif "invitePrice" in patch:
                # Keep the compatibility field and the first level in sync for old clients.
                levels = normalize_agent_levels(current_agent.get("levels"), current_agent.get("invitePrice", 0))
                levels[0]["price"] = current_agent["invitePrice"]
                current_agent["levels"] = levels
            if has_levels and current_agent.get("levels"):
                current_agent["invitePrice"] = current_agent["levels"][0].get("price", 0)
            continue
        if section == "integrity":
            current.setdefault("integrity", {})
            if "enabled" in patch:
                current["integrity"]["enabled"] = patch.get("enabled") is not False
            if "tokenTtlMinutes" in patch:
                try:
                    current["integrity"]["tokenTtlMinutes"] = max(5, min(43200, int(patch.get("tokenTtlMinutes") or 10080)))
                except Exception:
                    current["integrity"]["tokenTtlMinutes"] = 10080
            if "lockBuildAfterFirstIssue" in patch:
                current["integrity"]["lockBuildAfterFirstIssue"] = patch.get("lockBuildAfterFirstIssue") is not False
            if patch.get("rotateSecret"):
                current["integrity"]["secret"] = random_hex(24)
            continue
        if section == "clientBuild":
            current.setdefault("clientBuild", {})
            if "cacheRetentionHours" in patch:
                try:
                    current["clientBuild"]["cacheRetentionHours"] = max(1, min(24 * 30, int(patch.get("cacheRetentionHours") or 24)))
                except Exception:
                    current["clientBuild"]["cacheRetentionHours"] = 24
            if "jobRetentionHours" in patch:
                try:
                    current["clientBuild"]["jobRetentionHours"] = max(1, min(24 * 30, int(patch.get("jobRetentionHours") or 24)))
                except Exception:
                    current["clientBuild"]["jobRetentionHours"] = 24
            if "cleanupIntervalMinutes" in patch:
                try:
                    current["clientBuild"]["cleanupIntervalMinutes"] = max(10, min(24 * 60, int(patch.get("cleanupIntervalMinutes") or 360)))
                except Exception:
                    current["clientBuild"]["cleanupIntervalMinutes"] = 360
            if "maxCacheEntries" in patch:
                try:
                    current["clientBuild"]["maxCacheEntries"] = max(1, min(200, int(patch.get("maxCacheEntries") or 30)))
                except Exception:
                    current["clientBuild"]["maxCacheEntries"] = 30
            continue
        if section == "clientVariants":
            variants = current.setdefault("clientVariants", {})
            for variant_id, values in patch.items():
                if variant_id not in CLIENT_VARIANTS or not isinstance(values, dict):
                    continue
                existing = variants.setdefault(variant_id, {})
                mode = str(values.get("coverMode") or existing.get("coverMode") or "default").strip()
                cover_url = str(values.get("coverUrl") or "").strip()
                if mode not in ("default", "upload", "url"):
                    mode = "default"
                if mode == "url" and not http_url(cover_url):
                    cover_url = ""
                if mode == "upload" and not cover_url.startswith("/uploads/variant-covers/"):
                    cover_url = ""
                variants[variant_id] = {
                    "name": str(values.get("name") or CLIENT_VARIANTS[variant_id].get("label") or "").strip()[:80],
                    "badge": str(values.get("badge") or "").strip()[:80],
                    "description": str(values.get("description") or "").strip()[:500],
                    "coverMode": mode,
                    "coverUrl": cover_url,
                }
            continue
        for key, value in patch.items():
            if isinstance(current.get(section, {}).get(key), dict) and isinstance(value, dict):
                current[section][key].update(value)
            else:
                current.setdefault(section, {})[key] = value
    pay = current.setdefault("pay", {})
    for selected_key in (pay.get("wechatChannel"), pay.get("alipayChannel")):
        if selected_key and selected_key != "disabled" and isinstance(pay.get(selected_key), dict):
            pay[selected_key].setdefault("enabled", True)
    write_json(SYSTEM_PATH, current)
    return public_system_settings()


def read_notices():
    data = read_json(NOTICES_PATH, {"notices": [], "reads": {}})
    data.setdefault("notices", [])
    data.setdefault("reads", {})
    # Old pending notices did not store a reference; reconcile them on reads too.
    orders = {str(row.get("id")): row for row in read_orders().get("orders", []) if row.get("id")}
    changed = False
    for notice in data["notices"]:
        if notice.get("createdBy") != "system" or notice.get("title") not in ("订单待处理", "Agent order pending"):
            continue
        order_id = notice.get("refId") if notice.get("refType") == "order" else ""
        if not order_id:
            match = re.search(r"\border_[A-Za-z0-9_]+\b", str(notice.get("content") or ""))
            order_id = match.group(0) if match else ""
        order = orders.get(order_id)
        if order and (order.get("status") in ("paid", "done", "cancelled") or order.get("fulfilledAt")):
            notice["active"] = False
            changed = True
    if changed:
        write_json(NOTICES_PATH, data)
    return data


def write_notices(data):
    data.setdefault("notices", [])
    data.setdefault("reads", {})
    write_json(NOTICES_PATH, data)


def read_orders():
    data = read_json(ORDERS_PATH, {"orders": []})
    data.setdefault("orders", [])
    return data


def write_orders(data):
    data.setdefault("orders", [])
    write_json(ORDERS_PATH, data)


def public_order(order):
    user_id = order.get("userId") or order.get("agentId", "")
    username = order.get("username") or order.get("agentUsername", "")
    display_name = order.get("displayName") or order.get("agentDisplayName") or find_user_display_name(user_id, username)
    pending_expires_at = order.get("pendingExpiresAt", "")
    remaining_seconds = int(order.get("remainingSeconds", 0) or 0)
    is_expired = bool(order.get("isExpired", False) or order.get("status") == "expired")
    public_status = order.get("status", "pending")
    if order.get("status") == "pending" and order.get("action") in (
        "cloud_resolver_plan_purchase", "cloud_resolver_code_generate"
    ):
        try:
            if pending_expires_at:
                expires_at = parse_iso_datetime(pending_expires_at)
            else:
                created_at = parse_iso_datetime(order.get("createdAt"))
                if not created_at.tzinfo:
                    created_at = created_at.replace(tzinfo=timezone.utc)
                minutes = int(read_system_settings().get("cloudResolverOrderExpiryMinutes", 30) or 30)
                expires_at = created_at + timedelta(minutes=max(1, min(10080, minutes)))
                pending_expires_at = expires_at.isoformat(timespec="seconds")
            if not expires_at.tzinfo:
                expires_at = expires_at.replace(tzinfo=timezone.utc)
            remaining_seconds = max(0, int((expires_at - datetime.now(timezone.utc)).total_seconds()))
            is_expired = remaining_seconds <= 0
            if is_expired:
                public_status = "expired"
        except (TypeError, ValueError, OverflowError):
            pass
    return {
        "id": order.get("id"),
        "status": public_status,
        "action": order.get("action", ""),
        "amount": order.get("amount", 0),
        "currency": order.get("currency", "CNY"),
        "userId": user_id,
        "username": username,
        "displayName": display_name,
        "detail": localized_order_detail(order),
        "request": order.get("request") or {},
        "paymentMethod": order.get("paymentMethod", ""),
        "paymentChannel": order.get("paymentChannel", ""),
        "paymentType": order.get("paymentType", ""),
        "paymentProvider": order.get("paymentProvider", ""),
        "paymentUrl": order.get("paymentUrl", ""),
        "agentLevelId": order.get("agentLevelId", ""),
        "agentLevelName": order.get("agentLevelName", ""),
        "unitPrice": order.get("unitPrice", 0),
        "paidAt": order.get("paidAt", ""),
        "externalTradeNo": order.get("externalTradeNo", ""),
        "fulfilledAt": order.get("fulfilledAt", ""),
        "fulfilledInviteCodes": order.get("fulfilledInviteCodes") or [],
        "createdAt": order.get("createdAt", ""),
        "updatedAt": order.get("updatedAt", ""),
        "orderType": order.get("orderType") or order.get("action", ""),
        "pendingExpiresAt": pending_expires_at,
        "expiredAt": order.get("expiredAt", ""),
        "remainingSeconds": max(0, remaining_seconds),
        "isExpired": is_expired,
    }


def localized_order_detail(order):
    request = order.get("request") or {}
    if order.get("action") == "create_invites" and request:
        return order_detail_for_invites(request)
    detail = str(order.get("detail") or "")
    if detail.startswith("Create ") and "invite code" in detail:
        try:
            count = detail.split("Create ", 1)[1].split(" invite", 1)[0]
            max_uses = detail.split("maxUses=", 1)[1].split(",", 1)[0]
            retention_days = detail.split("retentionDays=", 1)[1].split(",", 1)[0]
            return f"生成 {count} 个邀请码，可用次数 {max_uses}，使用后保留 {retention_days} 天"
        except Exception:
            return "生成邀请码"
    return detail


def localized_notice_title(title):
    mapping = {
        "Agent order pending": "订单待处理",
        "Agent invite order fulfilled": "邀请码订单已通过",
        "Agent invite created": "邀请码已生成",
    }
    return mapping.get(title, title)


def localized_notice_content(content):
    text = str(content or "")
    if text.startswith("Agent ") and " created order " in text:
        try:
            username = text.split("Agent ", 1)[1].split(" created order ", 1)[0]
            rest = text.split(" created order ", 1)[1]
            order_id = rest.split(":", 1)[0]
            amount = rest.split("Amount:", 1)[1].strip().rstrip(".")
            return f"用户 {username} 提交了订单 {order_id}，金额：{amount}。"
        except Exception:
            return "用户提交了新订单。"
    if text.startswith("Super admin ") and " approved order " in text:
        try:
            approver = text.split("Super admin ", 1)[1].split(" approved order ", 1)[0]
            rest = text.split(" approved order ", 1)[1]
            order_id = rest.split(" for agent ", 1)[0]
            agent = rest.split(" for agent ", 1)[1].split(";", 1)[0]
            created = rest.split("created ", 1)[1].split(" invite", 1)[0]
            amount = rest.split("Amount:", 1)[1].strip().rstrip(".")
            return f"总管理员 {approver} 已通过用户 {agent} 的订单 {order_id}，生成 {created} 个邀请码，金额：{amount}。"
        except Exception:
            return "总管理员已通过订单并生成邀请码。"
    if text.startswith("Agent ") and " invite code(s). Amount: " in text:
        try:
            username = text.split("Agent ", 1)[1].split(" created ", 1)[0]
            count = text.split(" created ", 1)[1].split(" invite", 1)[0]
            amount = text.split("Amount:", 1)[1].strip().rstrip(".")
            return f"用户 {username} 已生成 {count} 个邀请码，金额：{amount}。"
        except Exception:
            return "已生成邀请码。"
    return text


def public_notice(notice, user_id=""):
    created_by = notice.get("createdBy", "")
    created_by_name = notice.get("createdByName") or ("系统" if created_by == "system" else find_user_display_name(notice.get("createdById", ""), created_by))
    return {
        "id": notice.get("id"),
        "title": localized_notice_title(notice.get("title", "")),
        "content": localized_notice_content(notice.get("content", "")),
        "level": notice.get("level", "info"),
        "createdAt": notice.get("createdAt", ""),
        "createdBy": created_by_name,
        "createdByUsername": "" if created_by == "system" else created_by,
        "createdById": notice.get("createdById", ""),
        "read": user_id in set(notice.get("readBy") or []),
        "refType": notice.get("refType", ""),
        "refId": notice.get("refId", ""),
    }


def announcement_notice_rows(user_id, include_unavailable=False):
    """Expose published announcements through the notification bell."""
    store = read_admin_announcements()
    reads = read_admin_announcement_reads().get("reads", [])
    rows = []
    for item in store.get("announcements", []):
        if not include_unavailable and not announcement_is_available(item):
            continue
        public = public_admin_announcement(item, user_id, reads)
        rows.append({
            "id": f"announcement:{item.get('id')}",
            "title": item.get("title") or "更新公告",
            "content": item.get("summary") or item.get("content") or "",
            "level": "warning" if item.get("importance") in ("重要", "紧急") else "info",
            "createdAt": item.get("publish_time") or item.get("updated_time") or item.get("created_time") or "",
            "createdBy": item.get("author") or "系统",
            "createdByName": item.get("author") or "系统",
            "createdById": item.get("author") or "system",
            "read": bool(public.get("read")),
            "refType": "announcement",
            "refId": item.get("id") or "",
            "announcement": public,
        })
    return rows


def notice_visible_to_user(notice, user):
    if notice.get("targetRole") == "super" and not is_super(user):
        return False
    return notice.get("active", True) is not False


def add_system_notice(title, content, level="info", target_role="", ref_type="", ref_id=""):
    data = read_notices()
    notice = {
        "id": new_id("notice"),
        "title": title,
        "content": content,
        "level": level,
        "targetRole": target_role,
        "active": True,
        "createdAt": now_iso(),
        "createdBy": "system",
        "createdById": "system",
        "readBy": [],
        "refType": ref_type,
        "refId": ref_id,
    }
    data["notices"].insert(0, notice)
    write_notices(data)
    return notice


def resolve_order_pending_notice(order):
    order_id = str((order or {}).get("id") or "").strip()
    if not order_id:
        return
    data = read_notices()
    changed = False
    for notice in data.get("notices", []):
        if notice.get("active", True) is False:
            continue
        same_order = (
            notice.get("refType") == "order" and str(notice.get("refId") or "") == order_id
        ) or order_id in str(notice.get("content") or "")
        if same_order and notice.get("title") in ("订单待处理", "Agent order pending"):
            notice["active"] = False
            notice["resolvedAt"] = now_iso()
            changed = True
    if changed:
        write_notices(data)


def scoped_users(store, actor):
    users = store.get("users", [])
    if is_super(actor):
        return users
    if is_agent(actor):
        own = actor.get("id")
        return [u for u in users if u.get("id") == own or u.get("parentAgentId") == own]
    return [actor]


def assert_user_scope(actor, target_id):
    if is_super(actor):
        return
    target = find_user_by_id(target_id)
    if not target:
        raise ValueError("用户不存在。")
    if is_agent(actor) and target.get("parentAgentId") == actor.get("id"):
        return
    if target.get("id") == actor.get("id"):
        return
    raise PermissionError("没有权限管理这个用户。")


def cleanup_invites(store):
    try:
        keep = []
        now_ts = time.time()
        default_days = int((store.get("settings") or {}).get("inviteRetentionDays") or 7)
        for invite in store.get("inviteCodes", []):
            used = int(invite.get("usedCount") or 0)
            max_uses = int(invite.get("maxUses") or 1)
            days = int(invite.get("retentionDays") or default_days)
            if used > 0 and max_uses > 0 and used >= max_uses and days >= 0:
                used_at = ""
                if invite.get("usedBy"):
                    used_at = invite.get("usedBy", [{}])[-1].get("usedAt", "")
                try:
                    used_ts = time.mktime(time.strptime(used_at[:19], "%Y-%m-%dT%H:%M:%S"))
                except Exception:
                    used_ts = now_ts
                if now_ts - used_ts >= days * 86400:
                    continue
            keep.append(invite)
        store["inviteCodes"] = keep
    except Exception:
        return


def default_mail_settings():
    return {"host": "", "port": 465, "user": "", "password": "", "from": "", "secure": True}


def read_mail_settings():
    settings = read_json(MAIL_PATH, default_mail_settings())
    defaults = default_mail_settings()
    defaults.update(settings or {})
    return defaults


def public_mail_settings():
    settings = read_mail_settings()
    return {
        "host": settings.get("host", ""),
        "port": settings.get("port", 465),
        "user": settings.get("user", ""),
        "from": settings.get("from", ""),
        "secure": bool(settings.get("secure", True)),
        "hasPassword": bool(settings.get("password"))
    }


def write_mail_settings(body):
    current = read_mail_settings()
    current["host"] = (body.get("host") or "").strip()
    current["port"] = int(body.get("port") or 465)
    current["user"] = (body.get("user") or "").strip()
    current["from"] = (body.get("from") or current["user"]).strip()
    current["secure"] = bool(body.get("secure", True))
    if body.get("password"):
        current["password"] = body.get("password")
    elif body.get("clearPassword"):
        current["password"] = ""
    write_json(MAIL_PATH, current)
    return current


def public_user(user, store=None):
    if not user:
        return None
    data = {
        "id": user.get("id"),
        "username": user.get("username"),
        "email": user.get("email", ""),
        "displayName": user.get("displayName"),
        "role": user.get("role"),
        "roleLabel": role_label(user.get("role")),
        "active": user.get("active", True),
        "canViewJson": user.get("canViewJson", user.get("role") == "super"),
        "parentAgentId": user.get("parentAgentId", ""),
        "parentAgentName": find_user_display_name(user.get("parentAgentId", ""), "") if user.get("parentAgentId") else "",
        "balance": round(float(user.get("balance") or 0), 2) if user.get("role") == "agent" else 0,
        "agentLevelId": user.get("agentLevelId", "") if user.get("role") == "agent" else "",
        "agentLevelName": user.get("agentLevelName", "") if user.get("role") == "agent" else "",
        "apiKey": user.get("apiKey"),
        "createdAt": user.get("createdAt", ""),
        "lastLoginAt": user.get("lastLoginAt", ""),
        "lastLoginIp": (user.get("loginIpHistory") or [{}])[0],
        "loginIpHistory": (user.get("loginIpHistory") or [])[:3],
    }
    return data


def find_user_by_id(user_id):
    return next((u for u in read_users()["users"] if u.get("id") == user_id), None)


def find_user_by_username(username):
    return next((u for u in read_users()["users"] if u.get("username") == username), None)


def mark_user_login(user_id, handler=None):
    store = read_users()
    login_at = now_iso()
    for row in store["users"]:
        if row.get("id") == user_id:
            row["lastLoginAt"] = login_at
            if handler:
                ip = client_ip(handler)
                history = [x for x in row.get("loginIpHistory", []) if isinstance(x, dict)]
                history.insert(0, {"ip": ip, "address": locate_ip(ip), "time": login_at})
                row["loginIpHistory"] = history[:3]
            write_users(store)
            return row
    return find_user_by_id(user_id)


def find_user_by_email(email):
    email = (email or "").strip().lower()
    if not email:
        return None
    return next((u for u in read_users()["users"] if (u.get("email") or "").strip().lower() == email), None)


def find_user_by_api_key(key):
    if not key:
        return None
    signature = file_signature(USERS_PATH)
    with API_KEY_CACHE_LOCK:
        if API_KEY_CACHE["signature"] != signature:
            users = read_users()["users"]
            API_KEY_CACHE["users"] = {
                user.get("apiKey"): dict(user)
                for user in users
                if user.get("apiKey") and user.get("active", True) is not False
            }
            API_KEY_CACHE["signature"] = file_signature(USERS_PATH)
        user = API_KEY_CACHE["users"].get(key)
        return dict(user) if user else None


def normalize_role(role):
    return role if role in ("super", "agent", "user") else "user"


def create_user(username, password, display_name="", role="user", template_user=None, email="", parent_agent_id="", balance=0, agent_level_id=""):
    username = (username or "").strip()
    email = (email or "").strip().lower()
    password = password or ""
    display_name = (display_name or username).strip() or username
    role = normalize_role(role)
    settings = read_system_settings()
    level = resolve_agent_level(None, settings, agent_level_id, enabled_only=True) if role == "agent" else None
    if not username or not password:
        raise ValueError("用户名和密码不能为空。")
    if len(password) < 10:
        raise ValueError("密码至少 10 位。")
    if find_user_by_username(username):
        raise ValueError("用户名已存在。")
    if email and find_user_by_email(email):
        raise ValueError("邮箱已存在。")
    base = safe_id(username)
    user_id = base
    while find_user_by_id(user_id):
        user_id = f"{base}-{int(time.time() * 1000)}"
    user = {
        "id": user_id,
        "username": username,
        "email": email,
        "displayName": display_name,
        "role": role,
        "active": True,
        "canViewJson": role == "super",
        "passwordHash": stored_password(password),
        "apiKey": random_hex(20),
        "createdAt": now_iso(),
        "parentAgentId": parent_agent_id if role == "user" else "",
        "balance": round(float(balance or 0), 2) if role == "agent" else 0,
    }
    if role == "agent":
        user["agentLevelId"] = level.get("id")
        user["agentLevelName"] = level.get("name")
    store = read_users()
    store["users"].append(user)
    write_users(store)
    template_config = read_config(template_user["id"]) if template_user else read_user_template_config()
    write_config(template_config, user_id)
    return user


def smtp_ready():
    settings = read_mail_settings()
    return bool((settings.get("host") or os.environ.get("SMTP_HOST")) and
                (settings.get("user") or os.environ.get("SMTP_USER")) and
                (settings.get("password") or os.environ.get("SMTP_PASS")))


def send_reset_email(email, code):
    if not smtp_ready():
        return False
    msg = EmailMessage()
    settings = read_mail_settings()
    sender = settings.get("from") or settings.get("user") or os.environ.get("SMTP_FROM") or os.environ.get("SMTP_USER")
    msg["From"] = sender
    msg["To"] = email
    msg["Subject"] = "工具箱后台密码找回验证码"
    msg.set_content("你的密码找回验证码是：%s\n验证码 10 分钟内有效。" % code)
    host = settings.get("host") or os.environ.get("SMTP_HOST")
    port = int(settings.get("port") or os.environ.get("SMTP_PORT", "465"))
    user = settings.get("user") or os.environ.get("SMTP_USER")
    password = settings.get("password") or os.environ.get("SMTP_PASS")
    if settings.get("secure", True) or port == 465:
        with smtplib.SMTP_SSL(host, port, timeout=15) as smtp:
            smtp.login(user, password)
            smtp.send_message(msg)
    else:
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            smtp.starttls()
            smtp.login(user, password)
            smtp.send_message(msg)
    return True


def send_admin_event_email(subject, content):
    if not smtp_ready():
        return False
    store = read_users()
    recipients = [
        (u.get("email") or "").strip()
        for u in store.get("users", [])
        if is_super(u) and (u.get("email") or "").strip()
    ]
    if not recipients:
        return False
    settings = read_mail_settings()
    sender = settings.get("from") or settings.get("user") or os.environ.get("SMTP_FROM") or os.environ.get("SMTP_USER")
    host = settings.get("host") or os.environ.get("SMTP_HOST")
    port = int(settings.get("port") or os.environ.get("SMTP_PORT", "465"))
    user = settings.get("user") or os.environ.get("SMTP_USER")
    password = settings.get("password") or os.environ.get("SMTP_PASS")
    msg = EmailMessage()
    msg["From"] = sender
    msg["To"] = ", ".join(recipients)
    msg["Subject"] = subject
    msg.set_content(content)
    if settings.get("secure", True) or port == 465:
        with smtplib.SMTP_SSL(host, port, timeout=15) as smtp:
            smtp.login(user, password)
            smtp.send_message(msg)
    else:
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            smtp.starttls()
            smtp.login(user, password)
            smtp.send_message(msg)
    return True


def send_notice_mail_to_users(notice, users=None):
    if not smtp_ready():
        return False, "未配置邮箱服务器。"
    pool = users if users is not None else read_users().get("users", [])
    recipients = []
    for user in pool:
        email = (user.get("email") or "").strip()
        if email and email not in recipients:
            recipients.append(email)
    if not recipients:
        return False, "没有可接收邮箱的用户。"
    settings = read_mail_settings()
    sender = settings.get("from") or settings.get("user") or os.environ.get("SMTP_FROM") or os.environ.get("SMTP_USER")
    host = settings.get("host") or os.environ.get("SMTP_HOST")
    port = int(settings.get("port") or os.environ.get("SMTP_PORT", "465"))
    user = settings.get("user") or os.environ.get("SMTP_USER")
    password = settings.get("password") or os.environ.get("SMTP_PASS")
    msg = EmailMessage()
    msg["From"] = sender
    msg["To"] = ", ".join(recipients)
    msg["Subject"] = notice.get("title") or "通知"
    msg.set_content(notice.get("content") or "")
    if settings.get("secure", True) or port == 465:
        with smtplib.SMTP_SSL(host, port, timeout=15) as smtp:
            smtp.login(user, password)
            smtp.send_message(msg)
    else:
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            smtp.starttls()
            smtp.login(user, password)
            smtp.send_message(msg)
    return True, f"已推送到 {len(recipients)} 个邮箱。"


def smtp_failure_reason(exc):
    """Convert SMTP/network exceptions to safe, actionable Chinese messages."""
    if isinstance(exc, smtplib.SMTPAuthenticationError):
        return "邮箱服务器登录失败，请检查 SMTP 账号或授权码。"
    if isinstance(exc, smtplib.SMTPRecipientsRefused):
        return "收件人被邮箱服务器拒绝。"
    if isinstance(exc, smtplib.SMTPSenderRefused):
        return "发件人被邮箱服务器拒绝。"
    if isinstance(exc, smtplib.SMTPNotSupportedError):
        return "邮箱服务器不支持当前 TLS 加密方式。"
    if isinstance(exc, (TimeoutError, smtplib.SMTPServerDisconnected, smtplib.SMTPConnectError, ConnectionError, OSError)):
        return "连接邮箱服务器失败或请求超时。"
    if isinstance(exc, smtplib.SMTPException):
        return "邮箱服务器发送失败。"
    return "邮件发送失败，请检查 SMTP 配置。"


def send_announcement_mail_to_users(announcement, users):
    """Send one private message per recipient and return structured statistics."""
    selected = len(users)
    failures = []
    sendable = []
    for user in users:
        user_id = str(user.get("id") or "")
        email = str(user.get("email") or "").strip()
        if user.get("active", True) is False:
            failures.append({"userId": user_id, "reason": "账号已停用"})
        elif not email:
            failures.append({"userId": user_id, "reason": "未绑定邮箱"})
        elif not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
            failures.append({"userId": user_id, "reason": "邮箱地址无效"})
        else:
            sendable.append((user_id, email))

    settings = read_mail_settings()
    smtp_available = smtp_ready()
    sent = 0
    if not smtp_available:
        failures.extend({"userId": user_id, "reason": "SMTP 未配置完整"} for user_id, _ in sendable)
    else:
        sender = settings.get("from") or settings.get("user") or os.environ.get("SMTP_FROM") or os.environ.get("SMTP_USER")
        host = settings.get("host") or os.environ.get("SMTP_HOST")
        port = int(settings.get("port") or os.environ.get("SMTP_PORT", "465"))
        smtp_user = settings.get("user") or os.environ.get("SMTP_USER")
        password = settings.get("password") or os.environ.get("SMTP_PASS")
        subject = announcement.get("title") or "更新公告"
        publish_time = announcement.get("publish_time") or announcement.get("updated_time") or ""
        content = (
            f"公告标题：{announcement.get('title') or '更新公告'}\n"
            f"版本号：{announcement.get('version') or '无版本号'}\n"
            f"公告类型：{announcement.get('type') or '功能更新'}\n"
            f"摘要：{announcement.get('summary') or '无'}\n"
            f"更新内容：\n{announcement.get('content') or ''}\n"
            f"发布时间：{publish_time or '未设置'}"
        )
        for user_id, email in sendable:
            msg = EmailMessage()
            msg["From"] = sender
            msg["To"] = email
            msg["Subject"] = subject
            msg.set_content(content)
            try:
                if settings.get("secure", True) or port == 465:
                    with smtplib.SMTP_SSL(host, port, timeout=15) as smtp:
                        smtp.login(smtp_user, password)
                        smtp.send_message(msg)
                else:
                    with smtplib.SMTP(host, port, timeout=15) as smtp:
                        smtp.starttls()
                        smtp.login(smtp_user, password)
                        smtp.send_message(msg)
                sent += 1
            except Exception as exc:
                failures.append({"userId": user_id, "reason": smtp_failure_reason(exc)})
    failed = len(failures)
    return {
        "ok": sent > 0,
        "selected": selected,
        "sent": sent,
        "failed": failed,
        "message": f"成功发送 {sent} 封，失败 {failed} 封",
        "failures": failures,
    }


PAYMENT_CHANNEL_LABELS = {
    "easypay": "易支付一",
    "easypay2": "易支付二",
    "alipayOfficial": "支付宝官方",
    "wechatOfficial": "微信企业支付",
}


def configured_payment_channels(settings):
    pay = settings.get("pay") or {}
    channels = []
    for selected_key in (pay.get("wechatChannel"), pay.get("alipayChannel")):
        if not selected_key or selected_key == "disabled" or selected_key in channels:
            continue
        gateway = pay.get(selected_key) or {}
        if gateway.get("enabled") is not True:
            continue
        if selected_key in ("easypay", "easypay2"):
            ready = gateway.get("apiUrl") and gateway.get("pid") and gateway.get("key")
        elif selected_key == "alipayOfficial":
            ready = gateway.get("appId") and gateway.get("privateKey") and gateway.get("gateway")
        elif selected_key == "wechatOfficial":
            ready = gateway.get("mchId") and gateway.get("appId") and gateway.get("apiV3Key")
        else:
            ready = False
        if ready:
            channels.append(selected_key)
    return channels


def public_payment_channels(settings):
    pay = settings.get("pay") or {}
    rows = []
    for payment_type, title_key in (("wxpay", "wechatChannel"), ("alipay", "alipayChannel")):
        key = pay.get(title_key)
        if not key or key == "disabled":
            continue
        # 微信官方配置目前只保存商户资料，尚未实现 Native/JSAPI 下单和
        # API v3 回调验签，因此不能作为可支付通道暴露给用户。
        if key == "wechatOfficial":
            continue
        try:
            payment_route_config(settings, key, payment_type)
        except ValueError:
            continue
        label = PAYMENT_CHANNEL_LABELS.get(key, key)
        rows.append({"key": key, "label": f"{label} / {'微信支付' if payment_type == 'wxpay' else '支付宝'}", "paymentType": payment_type})
    return rows


def payment_route_config(settings, channel, payment_type="", require_enabled=True):
    pay = settings.get("pay") or {}
    channel = str(channel or "").strip()
    payment_type = str(payment_type or "").strip().lower()
    if payment_type and payment_type not in ("alipay", "wxpay"):
        raise ValueError("支付类型无效。")
    if not payment_type:
        payment_type = "alipay" if pay.get("alipayChannel") == channel else "wxpay"
    selected = pay.get("alipayChannel" if payment_type == "alipay" else "wechatChannel")
    if require_enabled and selected != channel:
        raise ValueError("支付通道未启用或支付类型不匹配。")
    gateway = pay.get(channel) or {}
    if channel in ("easypay", "easypay2"):
        if (require_enabled and gateway.get("enabled") is not True) or not (gateway.get("apiUrl") and gateway.get("pid") and gateway.get("key")):
            raise ValueError("易支付通道未配置完整。")
        return {"provider": channel, "type": payment_type, "apiUrl": str(gateway.get("apiUrl")), "pid": str(gateway.get("pid")), "key": str(gateway.get("key")), "pcScan": bool(gateway.get("pcScan")), "mapiUrl": str(gateway.get("mapiUrl") or ""), "notifyUrl": gateway.get("notifyUrl") or "", "returnUrl": gateway.get("returnUrl") or ""}
    if channel == "alipayOfficial" and payment_type == "alipay":
        if (require_enabled and gateway.get("enabled") is not True) or not (gateway.get("appId") and gateway.get("privateKey") and gateway.get("publicKey")):
            raise ValueError("支付宝官方通道未配置完整。")
        return {"provider": channel, "type": payment_type, "appId": str(gateway.get("appId")), "privateKey": str(gateway.get("privateKey")), "publicKey": str(gateway.get("publicKey")), "gateway": gateway.get("gateway") or "https://openapi.alipay.com/gateway.do", "notifyUrl": gateway.get("notifyUrl") or "", "returnUrl": gateway.get("returnUrl") or ""}
    raise ValueError("当前支付通道不支持该支付类型。")


def epay_sign_payload(params):
    values = {str(k): v for k, v in (params or {}).items() if str(k) not in ("sign", "sign_type", "action") and v not in (None, "")}
    return "&".join(f"{key}={values[key]}" for key in sorted(values))


def epay_sign(params, key):
    return hashlib.md5((epay_sign_payload(params) + str(key)).encode("utf-8")).hexdigest()


def _der_read(data, offset=0):
    if offset >= len(data):
        raise ValueError("无效的密钥数据。")
    tag = data[offset]
    length_byte = data[offset + 1]
    offset += 2
    if length_byte & 0x80:
        length_size = length_byte & 0x7f
        length = int.from_bytes(data[offset:offset + length_size], "big")
        offset += length_size
    else:
        length = length_byte
    end = offset + length
    return tag, data[offset:end], end


def _der_children(data):
    children = []
    offset = 0
    while offset < len(data):
        tag, value, offset = _der_read(data, offset)
        children.append((tag, value))
    return children


def _pem_der(value):
    text = str(value or "").strip()
    text = re.sub(r"-----BEGIN [^-]+-----|-----END [^-]+-----|\s+", "", text)
    return base64.b64decode(text, validate=True)


def _rsa_private_numbers(value):
    raw = _pem_der(value)
    tag, seq, _ = _der_read(raw)
    items = _der_children(seq)
    if len(items) >= 4 and items[0][0] == 2 and items[1][0] == 2:
        return int.from_bytes(items[1][1], "big"), int.from_bytes(items[3][1], "big")
    if len(items) >= 3 and items[2][0] == 4:
        _, inner_seq, _ = _der_read(items[2][1])
        inner = _der_children(inner_seq)
        return int.from_bytes(inner[1][1], "big"), int.from_bytes(inner[3][1], "big")
    raise ValueError("支付宝私钥格式无效。")


def _rsa_public_numbers(value):
    raw = _pem_der(value)
    _, seq, _ = _der_read(raw)
    items = _der_children(seq)
    if len(items) == 2 and items[0][0] == 2:
        return int.from_bytes(items[0][1], "big"), int.from_bytes(items[1][1], "big")
    bit_string = items[1][1][1:] if items[1][0] == 3 else b""
    inner = _der_children(_der_read(bit_string)[1]) if bit_string else []
    return int.from_bytes(inner[0][1], "big"), int.from_bytes(inner[1][1], "big")


def alipay_sign_payload(params, include_sign_type=True):
    excluded = {"sign"}
    if not include_sign_type:
        excluded.add("sign_type")
    values = {str(k): v for k, v in (params or {}).items() if str(k) not in excluded and v not in (None, "")}
    return "&".join(f"{key}={values[key]}" for key in sorted(values))


def alipay_sign(params, private_key):
    n, d = _rsa_private_numbers(private_key)
    digest = hashlib.sha256(alipay_sign_payload(params).encode("utf-8")).digest()
    digest_info = bytes.fromhex("3031300d060960864801650304020105000420") + digest
    size = (n.bit_length() + 7) // 8
    encoded = b"\x00\x01" + b"\xff" * (size - len(digest_info) - 3) + b"\x00" + digest_info
    return base64.b64encode(pow(int.from_bytes(encoded, "big"), d, n).to_bytes(size, "big")).decode("ascii")


def verify_alipay_signature(data, public_key):
    try:
        n, e = _rsa_public_numbers(public_key)
        signature = base64.b64decode(str(data.get("sign") or ""), validate=True)
        size = (n.bit_length() + 7) // 8
        decoded = pow(int.from_bytes(signature, "big"), e, n).to_bytes(size, "big")
        # Alipay's notify signature content excludes the transport-level sign_type.
        digest = hashlib.sha256(alipay_sign_payload(data, include_sign_type=False).encode("utf-8")).digest()
        digest_info = bytes.fromhex("3031300d060960864801650304020105000420") + digest
        expected = b"\x00\x01" + b"\xff" * (size - len(digest_info) - 3) + b"\x00" + digest_info
        return hmac.compare_digest(decoded, expected)
    except Exception:
        return False


def epay_endpoint(api_url, file_name):
    clean = str(api_url or "").strip().rstrip("?&")
    if not clean:
        return ""
    if clean.lower().endswith(".php"):
        return clean if clean.lower().endswith(file_name) else clean.rsplit("/", 1)[0] + "/" + file_name
    return clean.rstrip("/") + "/" + file_name


def build_payment_url(order, settings, base_url):
    channel = order.get("paymentChannel")
    payment_type = order.get("paymentType") or ""
    config = payment_route_config(settings, channel, payment_type)
    notify = config.get("notifyUrl") or f"{base_url.rstrip('/')}/api/payment/callback"
    return_url = config.get("returnUrl") or base_url.rstrip("/") + "/api/payment/return"
    # A return URL is a browser redirect endpoint. If it was entered in the
    # notification field by mistake, use the server-to-server callback route
    # so the provider receives the expected plain-text success response.
    notify_path = urlparse(str(notify)).path.rstrip("/")
    if str(notify).rstrip("/") == str(return_url).rstrip("/") or notify_path == "/api/payment/return":
        notify = f"{base_url.rstrip('/')}/api/payment/callback"
    amount = f"{float(order.get('amount') or 0):.2f}"
    if config["provider"] in ("easypay", "easypay2"):
        params = {"pid": config["pid"], "type": config["type"], "out_trade_no": order["id"], "notify_url": notify, "return_url": return_url, "name": order.get("detail") or "邀请码", "money": amount, "sitename": "工具箱"}
        params["sign"] = epay_sign(params, config["key"])
        params["sign_type"] = "MD5"
        endpoint = (config.get("mapiUrl") or "").strip() if config.get("pcScan") else ""
        endpoint = endpoint or epay_endpoint(config["apiUrl"], "mapi.php" if config.get("pcScan") else "submit.php")
        return endpoint + ("&" if "?" in endpoint else "?") + urlencode(params)
    params = {"app_id": config["appId"], "method": "alipay.trade.page.pay", "format": "JSON", "charset": "utf-8", "sign_type": "RSA2", "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "version": "1.0", "notify_url": notify, "return_url": return_url, "biz_content": json.dumps({"out_trade_no": order["id"], "product_code": "FAST_INSTANT_TRADE_PAY", "total_amount": amount, "subject": order.get("detail") or "邀请码"}, ensure_ascii=False, separators=(",", ":"))}
    params["sign"] = alipay_sign(params, config["privateKey"])
    return str(config.get("gateway") or "https://openapi.alipay.com/gateway.do").rstrip("?") + "?" + urlencode(params)


def recent_pending_order(user_id, action, cooldown_minutes, data=None):
    if cooldown_minutes <= 0:
        return None
    try:
        cutoff = time.time() - cooldown_minutes * 60
        data = data or read_orders()
        for order in data.get("orders", []):
            order_user_id = order.get("userId") or order.get("agentId")
            if order_user_id != user_id or order.get("action") != action or order.get("status") != "pending":
                continue
            try:
                created = time.mktime(time.strptime((order.get("createdAt") or "")[:19], "%Y-%m-%dT%H:%M:%S"))
            except Exception:
                created = time.time()
            if created >= cutoff:
                return order
    except Exception:
        return None
    return None


def create_admin_order(user, action, amount, currency, detail, request=None, payment_method="", payment_channel="", reuse_existing=True):
    data = read_orders()
    existing = recent_pending_order(user.get("id"), action, 0, data) if reuse_existing else None
    if existing:
        existing["amount"] = round(float(amount or 0), 2)
        existing["currency"] = currency or "CNY"
        existing["detail"] = detail
        existing["request"] = request or {}
        existing["paymentMethod"] = payment_method
        existing["paymentChannel"] = payment_channel
        existing["displayName"] = user_display_name(user)
        existing["updatedAt"] = now_iso()
        write_orders(data)
        return existing, False
    order = {
        "id": new_id("order"),
        "status": "pending",
        "action": action,
        "amount": round(float(amount or 0), 2),
        "currency": currency or "CNY",
        "userId": user.get("id"),
        "username": user.get("username"),
        "displayName": user_display_name(user),
        "detail": detail,
        "request": request or {},
        "paymentMethod": payment_method,
        "paymentChannel": payment_channel,
        "createdAt": now_iso(),
    }
    data["orders"].insert(0, order)
    write_orders(data)
    title = "订单待处理"
    content = f"用户 {user_display_name(user)} 提交了订单 {order['id']}：{detail}。金额：{order['amount']} {order['currency']}。"
    add_system_notice(title, content, "warn", "super", "order", order["id"])
    try:
        send_admin_event_email(title, content)
    except Exception:
        pass
    return order, True


def update_user_account(user_id, body, super_edit=False, actor=None):
    store = read_users()
    user = next((u for u in store["users"] if u.get("id") == user_id), None)
    if not user:
        raise ValueError("用户不存在。")
    username = (body.get("username") or user.get("username") or "").strip()
    email = (body.get("email") or user.get("email") or "").strip().lower()
    if not username:
        raise ValueError("用户名不能为空。")
    for other in store["users"]:
        if other.get("id") == user_id:
            continue
        if other.get("username") == username:
            raise ValueError("用户名已存在。")
        if email and (other.get("email") or "").strip().lower() == email:
            raise ValueError("邮箱已存在。")
    sensitive_change = bool(body.get("password")) or email != (user.get("email") or "").strip().lower()
    if sensitive_change:
        security_backup(f"account-{user_id}", [USERS_PATH, SESSIONS_PATH, user_config_path(user_id)])
    user["username"] = username
    user["email"] = email
    if "displayName" in body:
        user["displayName"] = (body.get("displayName") or username).strip() or username
    old_role = user.get("role")
    if super_edit and "role" in body:
        requested_role = normalize_role(body.get("role"))
        if requested_role == "super" and old_role != "super":
            raise ValueError("不能把用户设置为总管理员。")
        if old_role == "super" and requested_role != "super":
            raise ValueError("总管理员账号不能修改角色。")
        user["role"] = requested_role
        if user["role"] == "agent":
            user.setdefault("balance", 0)
            user["parentAgentId"] = ""
            level = resolve_agent_level(user, read_system_settings(), body.get("agentLevelId"), enabled_only=True)
            user["agentLevelId"] = level.get("id")
            user["agentLevelName"] = level.get("name")
        elif user["role"] != "user":
            user.pop("balance", None)
            user["parentAgentId"] = ""
            user.pop("agentLevelId", None)
            user.pop("agentLevelName", None)
        elif user.get("role") == "user":
            user.pop("balance", None)
            user.pop("agentLevelId", None)
            user.pop("agentLevelName", None)
    elif super_edit and user.get("role") == "agent" and "agentLevelId" in body:
        level = resolve_agent_level(user, read_system_settings(), body.get("agentLevelId"), enabled_only=True)
        user["agentLevelId"] = level.get("id")
        user["agentLevelName"] = level.get("name")
    if super_edit and "active" in body:
        user["active"] = bool(body.get("active"))
    if super_edit and "canViewJson" in body:
        user["canViewJson"] = bool(body.get("canViewJson")) or user.get("role") == "super"
    if body.get("password"):
        user["passwordHash"] = stored_password(body.get("password"))
    if super_edit and "balance" in body and user.get("role") == "agent":
        try:
            balance = round(float(body.get("balance") or 0), 2)
        except (TypeError, ValueError):
            raise ValueError("代理余额必须是数字。")
        if balance < 0:
            raise ValueError("代理余额不能小于 0。")
        user["balance"] = balance
    if super_edit and body.get("resetApiKey"):
        user["apiKey"] = random_hex(20)
    write_users(store)
    if sensitive_change:
        revoke_user_sessions(user_id)
    return user


def scoped_invites(store, actor):
    invites = store.get("inviteCodes", [])
    if is_super(actor):
        return invites
    if is_agent(actor):
        actor_id = actor.get("id")
        return [item for item in invites
                if item.get("ownerAgentId") == actor_id or
                (item.get("createdById") == actor_id and not item.get("ownerAgentId"))]
    return []


def invite_is_used(invite):
    return int(invite.get("usedCount") or 0) > 0


def public_invite(invite, actor):
    item = dict(invite)
    agent_generated = bool(item.get("ownerAgentId") or item.get("isAgentInvite"))
    used = invite_is_used(item)
    super_disabled = bool(item.get("superDisabled"))
    item["isAgentInvite"] = agent_generated
    item["superDisabled"] = super_disabled
    item["canDelete"] = is_super(actor)
    item["canToggle"] = not used and (is_super(actor) or not super_disabled)
    return item


def update_agent_status(user_id, action, body=None):
    body = body or {}
    store = read_users()
    user = next((item for item in store.get("users", []) if item.get("id") == user_id), None)
    if not user:
        raise ValueError("用户不存在。")
    if user.get("id") == "admin":
        raise ValueError("默认总管理员不能设置为代理。")
    if action == "promote":
        user["role"] = "agent"
        user["parentAgentId"] = ""
        level = resolve_agent_level(user, read_system_settings(), body.get("agentLevelId"), enabled_only=True)
        user["agentLevelId"] = level.get("id")
        user["agentLevelName"] = level.get("name")
        if body.get("useDefaultBalance"):
            try:
                user["balance"] = max(0.0, round(float(body.get("defaultBalance") or 0), 2))
            except (TypeError, ValueError):
                user["balance"] = 0.0
        else:
            try:
                user["balance"] = max(0.0, round(float(user.get("balance") or 0), 2))
            except (TypeError, ValueError):
                user["balance"] = 0.0
    elif action == "cancel":
        if user.get("role") != "agent":
            raise ValueError("该用户不是代理。")
        user["role"] = "user"
        user.pop("balance", None)
        user.pop("agentLevelId", None)
        user.pop("agentLevelName", None)
        user["parentAgentId"] = ""
        for child in store.get("users", []):
            if child.get("parentAgentId") == user_id:
                child["parentAgentId"] = ""
    elif action == "balance":
        if user.get("role") != "agent":
            raise ValueError("只有代理账号可以设置余额。")
        try:
            balance = round(float(body.get("balance")), 2)
        except (TypeError, ValueError):
            raise ValueError("代理余额必须是数字。")
        if balance < 0:
            raise ValueError("代理余额不能小于 0。")
        user["balance"] = balance
    else:
        raise ValueError("不支持的代理操作。")
    write_users(store)
    return user


def get_auth(handler):
    auth = handler.headers.get("Authorization", "")
    token = ""
    if auth.startswith("Bearer "):
        token = auth[7:]
    else:
        token = handler.query.get("token", [""])[0]
    session = SESSIONS.get(token)
    if session:
        try:
            last_seen = parse_iso_datetime(session.get("lastSeenAt") or session.get("createdAt") or "")
            if last_seen.tzinfo is None:
                last_seen = last_seen.replace(tzinfo=timezone.utc)
            expired = (datetime.now(timezone.utc) - last_seen).total_seconds() > SESSION_TTL_SECONDS
        except (TypeError, ValueError):
            expired = True
        if expired:
            SESSIONS.pop(token, None)
            save_sessions()
            return None
        user = find_user_by_id(session["userId"])
        if user and user.get("active", True) is not False:
            session["lastSeenAt"] = now_iso()
            return {"token": token, "user": user}
    return None


def target_user_id(auth, handler):
    target = handler.headers.get("X-Target-User") or handler.query.get("targetUserId", [""])[0]
    if auth["user"].get("role") == "super" and target:
        user = find_user_by_id(target)
        if not user:
            raise ValueError("目标用户不存在。")
        return user["id"]
    return auth["user"]["id"]


def invite_request_from_body(store, body):
    return {
        "prefix": clean_invite_prefix(body.get("prefix") or body.get("code") or "YQ"),
        "count": max(1, min(200, int(body.get("count") or 1))),
        "maxUses": max(1, int(body.get("maxUses") or 1)),
        "retentionDays": max(0, int(body.get("retentionDays") or (store.get("settings") or {}).get("inviteRetentionDays") or 7)),
    }


def invite_quote_for_actor(store, actor, body):
    settings = read_system_settings()
    agent_settings = settings.get("agent") or {}
    level = resolve_agent_level(actor, settings, enabled_only=is_agent(actor))
    price = round(float(level.get("price") or 0), 2)
    request = normalize_invite_request_for_actor(store, actor, invite_request_from_body(store, body))
    total = round(request["count"] * price, 2)
    try:
        balance = round(float(actor.get("balance") or 0), 2) if is_agent(actor) else 0.0
    except (TypeError, ValueError):
        balance = 0.0
    return {
        "request": request,
        "price": price,
        "agentLevelId": level.get("id") if is_agent(actor) else "",
        "agentLevelName": level.get("name") if is_agent(actor) else "",
        "total": total,
        "currency": agent_settings.get("currency") or "CNY",
        "balance": balance,
        "balanceEnough": balance > 0 and balance >= total,
        "allowNegativeBalance": False,
        "channels": public_payment_channels(settings) if is_agent(actor) else [],
    }


def balance_quote_for_actor(actor, body):
    if not is_agent(actor):
        raise ValueError("只有代理账号可以充值余额。")
    try:
        amount = round(float(body.get("amount") or 0), 2)
    except (TypeError, ValueError):
        raise ValueError("充值金额必须是数字。")
    if not math.isfinite(amount):
        raise ValueError("充值金额必须是有效数字。")
    if amount < 0.01:
        raise ValueError("充值金额不能少于 0.01。")
    if amount > 1000000:
        raise ValueError("单次充值金额不能超过 1000000。")
    settings = read_system_settings()
    agent_settings = settings.get("agent") or {}
    try:
        balance = round(float(actor.get("balance") or 0), 2)
    except (TypeError, ValueError):
        balance = 0.0
    return {
        "amount": amount,
        "currency": agent_settings.get("currency") or "CNY",
        "balance": balance,
        "channels": public_payment_channels(settings),
    }


def create_balance_recharge_order(actor, body, base_url=""):
    quote = balance_quote_for_actor(actor, body)
    payment_channel = str(body.get("paymentChannel") or "").strip()
    payment_type = str(body.get("paymentType") or "").strip().lower()
    settings = read_system_settings()
    valid_channels = public_payment_channels(settings)
    selected = next((row for row in valid_channels
                     if row.get("key") == payment_channel and row.get("paymentType") == payment_type), None)
    if not selected:
        matches = [row for row in valid_channels if row.get("key") == payment_channel]
        if len(matches) == 1:
            selected = matches[0]
            payment_type = selected.get("paymentType") or "alipay"
    if not selected:
        raise ValueError("支付通道未配置或未启用。")
    detail = f"代理余额充值 {quote['amount']:.2f} {quote['currency']}"
    order, _ = create_admin_order(actor, "recharge_balance", quote["amount"], quote["currency"], detail,
                                  request={"amount": quote["amount"]}, payment_method="interface",
                                  payment_channel=payment_channel)
    order["paymentType"] = payment_type or selected.get("paymentType") or "alipay"
    order["paymentProvider"] = payment_channel
    order["paymentUrl"] = build_payment_url(order, settings, base_url)
    order["updatedAt"] = now_iso()
    data = read_orders()
    for current in data.get("orders", []):
        if current.get("id") == order.get("id"):
            current.update({"paymentType": order.get("paymentType"),
                            "paymentProvider": order.get("paymentProvider"),
                            "paymentUrl": order.get("paymentUrl"),
                            "updatedAt": order.get("updatedAt")})
    write_orders(data)
    return {"order": public_order(order), "paymentUrl": order["paymentUrl"],
            "message": "充值订单已创建，正在跳转支付。"}


def normalize_invite_request_for_actor(store, actor, request):
    normalized = dict(request or {})
    normalized["registerRole"] = "user"
    return normalized


def generate_invites_for_actor(store, actor, body, price=0, charged_amount=0):
    request = normalize_invite_request_for_actor(store, actor, invite_request_from_body(store, body))
    prefix = request["prefix"]
    count = request["count"]
    max_uses = request["maxUses"]
    retention_days = request["retentionDays"]
    existing = {x.get("code") for x in store["inviteCodes"]}
    created = []
    for _ in range(count):
        code = make_invite_code(prefix, existing)
        existing.add(code)
        invite = {"code": code, "active": True, "maxUses": max_uses,
                  "usedCount": 0, "usedBy": [], "retentionDays": retention_days,
                  "createdAt": now_iso(), "createdBy": actor.get("username"),
                  "createdById": actor.get("id"), "registerRole": "user",
                  "ownerAgentId": actor.get("id") if is_agent(actor) else "",
                  "price": round(float(price or 0), 2) if is_agent(actor) else 0,
                  "chargedAmount": round(float(charged_amount or 0), 2) if is_agent(actor) else 0,
                  "agentLevelId": actor.get("agentLevelId", "") if is_agent(actor) else "",
                  "agentLevelName": actor.get("agentLevelName", "") if is_agent(actor) else ""}
        created.append(invite)
    store["inviteCodes"][0:0] = created
    return created


def order_detail_for_invites(request):
    return f"生成 {request.get('count')} 个邀请码，可用次数 {request.get('maxUses')}，使用后保留 {request.get('retentionDays')} 天"


def create_invites_for_actor(store, actor, body, base_url=""):
    # 继续使用本次请求已经读取的 store。重新 read_users() 会让余额扣减
    # 写回到另一份快照，随后 handle_super() 用旧快照写盘时会把扣减覆盖掉。
    actor = next((item for item in store.get("users", []) if item.get("id") == actor.get("id")), actor)
    quote = invite_quote_for_actor(store, actor, body)
    request = quote["request"]
    price = float(quote["price"] or 0)
    total = float(quote["total"] or 0)
    if not is_agent(actor):
        created = generate_invites_for_actor(store, actor, request, price, 0)
        return {"invites": created, "created": True, "balance": actor.get("balance", 0)}
    payment_method = str(body.get("paymentMethod") or "").strip()
    payment_channel = str(body.get("paymentChannel") or "").strip()
    if payment_method == "balance":
        with PAYMENT_LOCK:
            # 余额支付必须基于锁内最新快照，避免两个并发请求同时消费同一笔余额。
            latest = read_users()
            store.clear()
            store.update(latest)
            actor = next((item for item in store.get("users", []) if item.get("id") == actor.get("id")), None)
            if not actor or not is_agent(actor):
                raise ValueError("代理账号不存在或已失效。")
            quote = invite_quote_for_actor(store, actor, body)
            request = quote["request"]
            price = float(quote["price"] or 0)
            total = float(quote["total"] or 0)
            if float(quote["balance"] or 0) <= 0 or float(quote["balance"] or 0) < total:
                raise ValueError("代理余额不足，只能使用已配置的支付宝或微信支付。")
            actor["balance"] = round(float(quote["balance"]) - total, 2)
            created = generate_invites_for_actor(store, actor, request, price, total)
            return {"invites": created, "created": True, "balance": actor["balance"], "paymentMethod": "balance"}
    if payment_method != "interface":
        raise ValueError("余额不足时只能使用已配置的支付宝或微信支付。")
    settings = read_system_settings()
    valid_channels = public_payment_channels(settings)
    payment_type = str(body.get("paymentType") or "").strip().lower()
    selected = next((row for row in valid_channels if row.get("key") == payment_channel and row.get("paymentType") == payment_type), None)
    if not selected:
        # 兼容旧前端：只有一个相同 key 的支付类型时允许省略 paymentType。
        matches = [row for row in valid_channels if row.get("key") == payment_channel]
        if len(matches) == 1:
            selected = matches[0]
            payment_type = selected.get("paymentType") or "alipay"
    if not selected:
        raise ValueError("支付通道未配置或未启用。")
    order, _ = create_admin_order(actor, "create_invites", total, quote["currency"], order_detail_for_invites(request), request=request, payment_method="interface", payment_channel=payment_channel)
    order["agentLevelId"] = quote.get("agentLevelId", "")
    order["agentLevelName"] = quote.get("agentLevelName", "")
    order["unitPrice"] = price
    order["paymentType"] = payment_type or selected.get("paymentType") or "alipay"
    order["paymentProvider"] = payment_channel
    order["paymentUrl"] = build_payment_url(order, settings, base_url)
    order["updatedAt"] = now_iso()
    data = read_orders()
    for current in data.get("orders", []):
        if current.get("id") == order.get("id"):
            current.update({"paymentType": order.get("paymentType"), "paymentProvider": order.get("paymentProvider"), "paymentUrl": order.get("paymentUrl"), "agentLevelId": order.get("agentLevelId"), "agentLevelName": order.get("agentLevelName"), "unitPrice": order.get("unitPrice"), "updatedAt": order.get("updatedAt")})
    write_orders(data)
    return {"order": public_order(order), "created": False, "paymentUrl": order["paymentUrl"], "message": "订单已创建，正在跳转支付。"}


def fulfill_invite_order(order, approver=None, paid=False, external_trade_no=""):
    if order.get("action") != "create_invites" or order.get("fulfilledAt"):
        return order.get("fulfilledInviteCodes") or []
    store = read_users()
    agent = next((u for u in store.get("users", []) if u.get("id") == (order.get("userId") or order.get("agentId"))), None)
    if not agent or not is_agent(agent):
        raise ValueError("订单对应的代理不存在。")
    request = order.get("request") or {}
    amount = round(float(order.get("amount") or 0), 2)
    if order.get("paymentMethod") == "balance":
        balance = round(float(agent.get("balance") or 0), 2)
        if balance < amount:
            raise ValueError("代理余额不足，不能使用余额支付。")
        agent["balance"] = round(balance - amount, 2)
    if "unitPrice" in order:
        unit_price = round(float(order.get("unitPrice") or 0), 2)
    else:
        level = resolve_agent_level(agent, read_system_settings(), order.get("agentLevelId"))
        unit_price = round(float(level.get("price") or 0), 2)
        agent["agentLevelId"] = level.get("id")
        agent["agentLevelName"] = level.get("name")
    created = generate_invites_for_actor(store, agent, request, unit_price, amount)
    write_users(store)
    order["status"] = "paid" if paid or order.get("paymentMethod") == "interface" else order.get("status", "done")
    order["fulfilledAt"] = now_iso()
    order["paidAt"] = order.get("paidAt") or now_iso()
    order["externalTradeNo"] = external_trade_no or order.get("externalTradeNo", "")
    order["fulfilledBy"] = user_display_name(approver) if approver else "payment_callback"
    order["fulfilledInviteCodes"] = [item.get("code") for item in created]
    # Payment completion must also clear the super-admin's pending-order alert.
    resolve_order_pending_notice(order)
    return order["fulfilledInviteCodes"]


def fulfill_balance_recharge_order(order, paid=False, external_trade_no=""):
    if order.get("action") != "recharge_balance":
        return False
    if order.get("fulfilledAt"):
        return True
    store = read_users()
    agent = next((u for u in store.get("users", [])
                  if u.get("id") == (order.get("userId") or order.get("agentId"))), None)
    if not agent or not is_agent(agent):
        raise ValueError("充值订单对应的代理不存在。")
    amount = round(float(order.get("amount") or 0), 2)
    if not math.isfinite(amount) or amount < 0.01:
        raise ValueError("充值订单金额无效。")
    agent["balance"] = round(float(agent.get("balance") or 0) + amount, 2)
    write_users(store)
    order["status"] = "paid" if paid else order.get("status", "done")
    order["fulfilledAt"] = now_iso()
    order["paidAt"] = order.get("paidAt") or now_iso()
    order["externalTradeNo"] = external_trade_no or order.get("externalTradeNo", "")
    order["fulfilledBy"] = "payment_callback"
    order["balanceAfter"] = agent["balance"]
    resolve_order_pending_notice(order)
    return True

def get_target(button):
    action = button.get("action", "link")
    if action == "download":
        return button.get("download_url") or button.get("url") or button.get("target") or ""
    if action == "cmd":
        return button.get("command") or button.get("target") or ""
    if action == "script":
        return normalize_script_target(button.get("script_id") or button.get("target") or "")
    if action == "winget":
        return button.get("package_id") or button.get("target") or ""
    return button.get("url") or button.get("target") or ""


def get_backup_url(button, page=False):
    if not isinstance(button, dict):
        return ""
    keys = ("backup_page_url", "backup_webpage", "fallback_page_url", "backupPageUrl") if page else ("backup_url", "backup_download_url", "fallback_url", "backupUrl")
    for key in keys:
        value = str(button.get(key) or "").strip()
        if value:
            return value
    return ""


def normalize_download_files(value):
    files = []
    if not isinstance(value, list):
        return files
    for raw in value[:50]:
        if not isinstance(raw, dict):
            continue
        url = str(raw.get("url") or raw.get("download_url") or "").strip()
        name = Path(str(raw.get("name") or raw.get("filename") or "").strip()).name
        if url:
            item = {"name": name, "url": url, "primary": raw.get("primary") is True}
            if get_backup_url(raw): item["backup_url"] = get_backup_url(raw)
            if get_backup_url(raw, True): item["backup_page_url"] = get_backup_url(raw, True)
            files.append(item)
    if files and not any(item["primary"] for item in files):
        files[0]["primary"] = True
    primary_seen = False
    for item in files:
        if item["primary"] and not primary_seen:
            primary_seen = True
        elif item["primary"]:
            item["primary"] = False
    return files


def new_button(body):
    action = body.get("action", "link")
    target = body.get("target") or body.get("url") or ""
    if action == "script":
        target = normalize_script_target(target)
    item = {"name": body.get("name", "未命名"), "icon": body.get("icon", ""), "action": action}
    item["id"] = body.get("id") or new_id("btn")
    item["enabled"] = body.get("enabled", True) is not False
    guard_input = body.get("guard") if isinstance(body.get("guard"), dict) else {}
    guard_password = str(guard_input.get("password") or body.get("guard_password") or "").strip()
    guard_hash = str(guard_input.get("passwordHash") or guard_input.get("password_hash") or "").strip()
    require_password = bool(guard_input.get("requirePassword", guard_input.get("password_enabled", False)))
    require_confirm = bool(guard_input.get("requireConfirm", guard_input.get("confirm_enabled", False)))
    confirm_message = str(guard_input.get("confirmMessage") or "确定要继续执行此操作吗？").strip()[:300]
    if guard_password:
        guard_hash = stored_password(guard_password)
    if require_password and not guard_hash:
        raise ValueError("启用按钮密码验证时必须设置密码。")
    if require_password or require_confirm or guard_hash or confirm_message != "确定要继续执行此操作吗？":
        item["guard"] = {"requirePassword": require_password, "passwordHash": guard_hash if require_password else "", "password_plain": guard_password or guard_input.get("password_plain") or "", "requireConfirm": require_confirm, "confirmMessage": confirm_message}
    try:
        item["sort"] = int(body.get("sort") if body.get("sort") not in (None, "") else 0)
    except Exception:
        item["sort"] = 0
    if body.get("description") or body.get("intro") or body.get("remark"):
        item["description"] = body.get("description") or body.get("intro") or body.get("remark")
    if action == "download":
        item["download_url"] = target
        if get_backup_url(body): item["backup_url"] = get_backup_url(body)
        backup_urls = body.get("backup_urls") if isinstance(body.get("backup_urls"), list) else []
        normalized_backups = list(dict.fromkeys(str(value or "").strip() for value in backup_urls if str(value or "").strip()))
        if normalized_backups:
            item["backup_urls"] = normalized_backups
            item["backup_url"] = normalized_backups[0]
        if get_backup_url(body, True): item["backup_page_url"] = get_backup_url(body, True)
        download_directory = str(body.get("download_directory") or body.get("download_path") or "").strip()[:1000]
        if download_directory:
            item["download_directory"] = download_directory
            item["download_delete_on_exit"] = body.get("download_delete_on_exit") is True
        files = normalize_download_files(body.get("files"))
        if (body.get("download_mode") == "multiple" or len(files) > 1) and files:
            item["download_mode"] = "multiple"
            item["package_name"] = str(body.get("package_name") or body.get("name") or "").strip()
            item["files"] = files
            item["download_url"] = files[0]["url"]
    elif action == "cmd":
        item["command"] = target
    elif action == "script":
        item["script_id"] = target
        if target not in SCRIPT_LABELS:
            item["custom_script"] = target
    elif action == "winget":
        item["package_id"] = target
    else:
        item["url"] = target
    return item


def button_sort_value(button):
    try:
        return int((button or {}).get("sort") or 0)
    except Exception:
        return 0


def button_rows(config):
    rows = []
    changed = False
    for page_id, page in (config.get("pages") or {}).items():
        for si, section in enumerate(page.get("sections") or []):
            buttons = section.get("buttons") or []
            kept = [button for button in buttons if not is_empty_button(button)]
            if len(kept) != len(buttons):
                section["buttons"] = kept
                changed = True
            for bi, button in enumerate(section.get("buttons") or []):
                if not button.get("id"):
                    button["id"] = new_id("btn")
                    changed = True
                rows.append({"scope": "page", "pageId": page_id, "tabIndex": None, "sectionIndex": si, "buttonIndex": bi,
                             "id": button.get("id"),
                             "area": page.get("title") or page.get("name") or page_id, "section": section.get("title", ""),
                             "name": button.get("name", ""), "icon": button.get("icon", ""), "action": button.get("action", "link"),
                             "enabled": button.get("enabled", True) is not False,
                             "sort": button_sort_value(button), "target": get_target(button), "raw": button})
    for ti, tab in enumerate(config.get("toolbox_tabs") or []):
        for si, section in enumerate(tab.get("sections") or []):
            buttons = section.get("buttons") or []
            kept = [button for button in buttons if not is_empty_button(button)]
            if len(kept) != len(buttons):
                section["buttons"] = kept
                changed = True
            for bi, button in enumerate(section.get("buttons") or []):
                if not button.get("id"):
                    button["id"] = new_id("btn")
                    changed = True
                rows.append({"scope": "toolbox", "pageId": None, "tabIndex": ti, "sectionIndex": si, "buttonIndex": bi,
                             "id": button.get("id"),
                             "area": tab.get("name", ""), "section": section.get("title", ""),
                             "name": button.get("name", ""), "icon": button.get("icon", ""), "action": button.get("action", "link"),
                             "enabled": button.get("enabled", True) is not False,
                             "sort": button_sort_value(button), "target": get_target(button), "raw": button})
    rows.sort(key=lambda row: (row.get("area") or "", row.get("section") or "", int(row.get("sort") or 0), int(row.get("buttonIndex") or 0)))
    return rows, changed


def is_empty_button(button):
    if not isinstance(button, dict):
        return True
    name = str(button.get("name") or "").strip()
    if name and name != "未命名":
        return False
    if str(button.get("icon") or "").strip():
        return False
    if str(button.get("description") or button.get("intro") or button.get("remark") or "").strip():
        return False
    return not get_target(button).strip()


def get_container(config, body):
    if body.get("scope") == "toolbox":
        return config["toolbox_tabs"][int(body.get("tabIndex", 0))]
    return config["pages"][body.get("pageId")]


def find_button_slot(config, body):
    button_id = body.get("id")
    if button_id:
        for page_id, page in (config.get("pages") or {}).items():
            for si, section in enumerate(page.get("sections") or []):
                for bi, button in enumerate(section.get("buttons") or []):
                    if button.get("id") == button_id:
                        return section, bi
        for ti, tab in enumerate(config.get("toolbox_tabs") or []):
            for si, section in enumerate(tab.get("sections") or []):
                for bi, button in enumerate(section.get("buttons") or []):
                    if button.get("id") == button_id:
                        return section, bi
    container = get_container(config, body)
    section = container["sections"][int(body["sectionIndex"])]
    return section, int(body["buttonIndex"])


def target_button_section(config, body):
    target_scope = body.get("targetScope") or body.get("scope")
    if target_scope == "toolbox":
        tab_index = body.get("targetTabIndex")
        if tab_index in (None, ""):
            tab_index = body.get("tabIndex", 0)
        container = config["toolbox_tabs"][int(tab_index)]
    else:
        page_id = body.get("targetPageId") or body.get("pageId")
        container = config["pages"][page_id]

    section_index = body.get("targetSectionIndex")
    if section_index in (None, ""):
        section_index = body.get("sectionIndex", 0)
    section_index = max(0, int(section_index))
    sections = container.setdefault("sections", [])
    while len(sections) <= section_index:
        sections.append({"title": "默认分组", "buttons": []})
    return sections[section_index]


def update_button(config, body):
    source_section, button_index = find_button_slot(config, body)
    source_buttons = source_section.setdefault("buttons", [])
    old_button = source_buttons[button_index]
    old_id = old_button.get("id") or body.get("id")
    payload = dict(body.get("button") or body)
    if old_id:
        payload["id"] = old_id
    updated_button = new_button(payload)
    target_section = target_button_section(config, body)

    if target_section is source_section:
        source_buttons[button_index] = updated_button
    else:
        del source_buttons[button_index]
        target_section.setdefault("buttons", []).append(updated_button)
    return updated_button


def clean_invite_prefix(value):
    text = "".join(ch for ch in str(value or "YQ").upper() if ch.isalnum() or ch in "-_").strip("-_")
    return (text or "YQ")[:18]


def make_invite_code(prefix, existing):
    for _ in range(1000):
        code = f"{prefix}-{random_hex(4).upper()}"
        if code not in existing:
            return code
    raise ValueError("邀请码生成失败，请重试。")


def csharp_literal(value):
    return '"' + str(value).replace("\\", "\\\\").replace('"', '\\"').replace("\r", "\\r").replace("\n", "\\n").replace("\t", "\\t") + '"'


def assembly_version(value):
    text = str(value or "1.0.0.0").strip().lstrip("vV")
    parts = []
    for raw in text.replace("_", ".").replace("-", ".").split("."):
        if raw.isdigit():
            parts.append(str(max(0, min(65535, int(raw)))))
        if len(parts) == 4:
            break
    while len(parts) < 4:
        parts.append("0")
    return ".".join(parts)


def make_ico_from_png(png_bytes):
    size = len(png_bytes)
    header = b"\x00\x00\x01\x00\x01\x00"
    entry = bytes([0, 0, 0, 0]) + (1).to_bytes(2, "little") + (32).to_bytes(2, "little") + size.to_bytes(4, "little") + (22).to_bytes(4, "little")
    return header + entry + png_bytes


def custom_client_icon(app, target_dir):
    url = (app.get("exe_icon") or app.get("exe_icon_url") or "").strip()
    if not url:
        return CLIENT_ICON
    if url.lower().startswith(("http://", "https://")):
        cache_key = hashlib.sha256(url.encode("utf-8")).hexdigest()
        cached_icon = ICON_CACHE / f"{cache_key}.ico"
        if cached_icon.exists():
            return cached_icon
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "ToolboxAdminApi"})
        with urllib.request.urlopen(request, timeout=3) as response:
            data = response.read(2 * 1024 * 1024)
            content_type = response.headers.get("Content-Type", "").lower()
        icon_path = Path(target_dir) / "client-icon.ico"
        lower = url.lower().split("?", 1)[0]
        if lower.endswith(".ico") or "image/x-icon" in content_type or "image/vnd.microsoft.icon" in content_type:
            icon_path.write_bytes(data)
            if url.lower().startswith(("http://", "https://")):
                ICON_CACHE.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(icon_path, ICON_CACHE / f"{hashlib.sha256(url.encode('utf-8')).hexdigest()}.ico")
            return icon_path
        if lower.endswith(".png") or "image/png" in content_type or data.startswith(b"\x89PNG\r\n\x1a\n"):
            icon_path.write_bytes(make_ico_from_png(data))
            if url.lower().startswith(("http://", "https://")):
                ICON_CACHE.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(icon_path, ICON_CACHE / f"{hashlib.sha256(url.encode('utf-8')).hexdigest()}.ico")
            return icon_path
    except Exception:
        if url.lower().startswith(("http://", "https://")):
            cached_icon = ICON_CACHE / f"{hashlib.sha256(url.encode('utf-8')).hexdigest()}.ico"
            if cached_icon.exists():
                return cached_icon
        return CLIENT_ICON
    return CLIENT_ICON


def client_cache_key(user, base_url, app_config, source, build_id, build_stamp, integrity_seed, variant=DEFAULT_CLIENT_VARIANT):
    icon_ref = (app_config.get("exe_icon") or app_config.get("exe_icon_url") or "").strip()
    payload = {
        "variant": normalize_client_variant(variant),
        "userId": user.get("id"),
        "username": user.get("username"),
        "displayName": user_display_name(user),
        "apiKey": user.get("apiKey"),
        "baseUrl": base_url.rstrip("/"),
        "app": app_config,
        "templateSha256": hashlib.sha256(source.encode("utf-8")).hexdigest(),
        "buildId": build_id,
        "buildStamp": build_stamp,
        "integritySeed": integrity_seed,
        "defaultIconMtime": int(CLIENT_ICON.stat().st_mtime) if CLIENT_ICON.exists() else 0,
        "iconRef": icon_ref,
    }
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def read_client_cache(cache_key):
    exe_path = CLIENT_CACHE / f"{cache_key}.exe"
    meta_path = CLIENT_CACHE / f"{cache_key}.json"
    if not exe_path.exists() or not meta_path.exists():
        return None
    try:
        meta = read_json(meta_path, {})
        data = exe_path.read_bytes()
        if not is_windows_exe(data):
            exe_path.unlink(missing_ok=True)
            meta_path.unlink(missing_ok=True)
            return None
        return meta.get("name") or "toolbox.exe", data
    except Exception:
        return None


def write_client_cache(cache_key, name, data):
    if not is_windows_exe(data):
        raise RuntimeError("EXE 生成结果无效，已拒绝写入缓存。")
    CLIENT_CACHE.mkdir(parents=True, exist_ok=True)
    exe_path = CLIENT_CACHE / f"{cache_key}.exe"
    meta_path = CLIENT_CACHE / f"{cache_key}.json"
    exe_path.write_bytes(data)
    write_json(meta_path, {"name": name, "createdAt": now_iso(), "bytes": len(data)})
    cleanup_client_build_artifacts()


def cleanup_client_build_artifacts():
    settings = client_build_cleanup_settings()
    now_ts = time.time()
    cache_cutoff = now_ts - settings["cacheSeconds"]
    job_cutoff = now_ts - settings["jobSeconds"]
    try:
        CLIENT_CACHE.mkdir(parents=True, exist_ok=True)
        entries = sorted(CLIENT_CACHE.glob("*.exe"), key=lambda p: p.stat().st_mtime, reverse=True)
        for old in entries[settings["maxEntries"]:]:
            old.unlink(missing_ok=True)
            old.with_suffix(".json").unlink(missing_ok=True)
        for exe_path in CLIENT_CACHE.glob("*.exe"):
            try:
                if exe_path.stat().st_mtime < cache_cutoff:
                    exe_path.unlink(missing_ok=True)
                    exe_path.with_suffix(".json").unlink(missing_ok=True)
            except Exception:
                pass
        for meta_path in CLIENT_CACHE.glob("*.json"):
            try:
                if not meta_path.with_suffix(".exe").exists():
                    meta_path.unlink(missing_ok=True)
            except Exception:
                pass
    except Exception:
        pass
    try:
        CLIENT_JOBS.mkdir(parents=True, exist_ok=True)
        for exe_path in CLIENT_JOBS.glob("*.exe"):
            try:
                if exe_path.stat().st_mtime < job_cutoff:
                    exe_path.unlink(missing_ok=True)
            except Exception:
                pass
        with CLIENT_BUILD_LOCK:
            stale_job_ids = []
            for job_id, job in CLIENT_BUILD_JOBS.items():
                status = job.get("status")
                updated_at = float(job.get("updatedAt") or job.get("createdAt") or 0)
                if status in ("done", "error", "missing") and updated_at < job_cutoff:
                    stale_job_ids.append(job_id)
            for job_id in stale_job_ids:
                CLIENT_BUILD_JOBS.pop(job_id, None)
    except Exception:
        pass


def run_client_build_cleanup_loop():
    while True:
        try:
            cleanup_client_build_artifacts()
        except Exception:
            pass
        time.sleep(client_build_cleanup_settings()["intervalSeconds"])


def public_client_build_job(job_id):
    cleanup_client_build_artifacts()
    with CLIENT_BUILD_LOCK:
        job = dict(CLIENT_BUILD_JOBS.get(job_id) or {})
    if not job:
        return None
    return {
        "id": job_id,
        "status": job.get("status", "missing"),
        "message": job.get("message", ""),
        "fileName": job.get("fileName", ""),
        "variant": job.get("variant", DEFAULT_CLIENT_VARIANT),
        "variantLabel": job.get("variantLabel", client_variant_info(job.get("variant", DEFAULT_CLIENT_VARIANT)).get("label")),
        "createdAt": job.get("createdAt", 0),
        "updatedAt": job.get("updatedAt", 0),
    }


def integrity_settings():
    settings = read_system_settings().get("integrity") or {}
    secret = str(settings.get("secret") or "").strip()
    if len(secret) < 32:
        secret = random_hex(24)
        settings["secret"] = secret
        system = read_system_settings()
        system["integrity"] = settings
        write_json(SYSTEM_PATH, system)
    try:
        ttl_minutes = max(5, min(43200, int(settings.get("tokenTtlMinutes") or 10080)))
    except Exception:
        ttl_minutes = 10080
    return {
        "enabled": settings.get("enabled", True) is not False,
        "secret": secret,
        "tokenTtlSeconds": ttl_minutes * 60,
        "lockBuildAfterFirstIssue": settings.get("lockBuildAfterFirstIssue", False) is not False,
    }


def client_signature_payload(user_id, api_key, build_id, build_stamp, integrity_seed, base_url, exe_sha256=""):
    return "|".join([
        str(user_id or ""),
        str(api_key or ""),
        str(build_id or ""),
        str(build_stamp or ""),
        str(integrity_seed or ""),
        str(base_url or "").rstrip("/"),
        str(exe_sha256 or ""),
    ])


def sign_client_build(user_id, api_key, build_id, build_stamp, integrity_seed, base_url, exe_sha256=""):
    settings = integrity_settings()
    payload = client_signature_payload(user_id, api_key, build_id, build_stamp, integrity_seed, base_url, exe_sha256)
    return hmac_sha256_hex(settings["secret"], payload)


def register_client_build(user, api_key, base_url, build_id, build_stamp, integrity_seed, exe_sha256, source_sha256):
    data = read_client_integrity()
    builds = data.setdefault("builds", {})
    build_signature = sign_client_build(user.get("id"), api_key, build_id, build_stamp, integrity_seed, base_url, exe_sha256)
    builds[build_id] = {
        "id": build_id,
        "userId": user.get("id"),
        "username": user.get("username"),
        "apiKeyHash": sha256_hex(api_key),
        "baseUrl": base_url.rstrip("/"),
        "buildStamp": str(build_stamp),
        "integritySeedHash": sha256_hex(integrity_seed),
        "exeSha256": exe_sha256,
        "sourceSha256": source_sha256,
        "signature": build_signature,
        "createdAt": now_iso(),
        "firstVerifiedAt": "",
        "lastVerifiedAt": "",
        "verifyCount": 0,
        "revoked": False,
    }
    try:
        entries = sorted(builds.values(), key=lambda row: row.get("createdAt", ""), reverse=True)
        keep_ids = {row.get("id") for row in entries[:1000]}
        data["builds"] = {key: value for key, value in builds.items() if key in keep_ids}
    except Exception:
        pass
    write_client_integrity(data)
    return build_signature


def issue_build_runtime_token(build_id, user_id, api_key, expires_in, data=None):
    token = random_hex(32)
    own_data = data is None
    data = data or read_client_integrity()
    cleanup_runtime_tokens(data)
    data.setdefault("tokens", {})[token] = {
        "userId": user_id,
        "apiKeyHash": sha256_hex(api_key),
        "buildId": build_id,
        "issuedAt": time.time(),
        "expiresAt": time.time() + max(60, int(expires_in or 0)),
    }
    if own_data:
        write_client_integrity(data)
    return token


def cleanup_runtime_tokens(data):
    now_ts = time.time()
    tokens = data.setdefault("tokens", {})
    expired = []
    for token, row in tokens.items():
        try:
            if float(row.get("expiresAt", 0)) <= now_ts:
                expired.append(token)
        except Exception:
            expired.append(token)
    for token in expired:
        tokens.pop(token, None)


def verify_runtime_token(handler, user):
    settings = integrity_settings()
    if not settings["enabled"]:
        return True
    token = (handler.headers.get("X-Client-Integrity") or handler.query.get("runtimeToken", [""])[0] or "").strip()
    if not token:
        return verify_build_headers(handler, user)
    data = read_client_integrity()
    cleanup_runtime_tokens(data)
    row = data.get("tokens", {}).get(token)
    if not row:
        write_client_integrity(data)
        return verify_build_headers(handler, user)
    if row.get("userId") != user.get("id"):
        return False
    if row.get("apiKeyHash") != sha256_hex(user.get("apiKey") or ""):
        return False
    if float(row.get("expiresAt", 0) or 0) <= time.time():
        data.get("tokens", {}).pop(token, None)
        write_client_integrity(data)
        return verify_build_headers(handler, user)
    return True

def verify_any_runtime_token(handler):
    settings = integrity_settings()
    if not settings["enabled"]:
        return True
    token = (handler.headers.get("X-Client-Integrity") or handler.query.get("runtimeToken", [""])[0] or "").strip()
    if not token:
        return verify_build_headers(handler)
    data = read_client_integrity()
    cleanup_runtime_tokens(data)
    row = data.get("tokens", {}).get(token)
    if not row:
        write_client_integrity(data)
        return verify_build_headers(handler)
    if float(row.get("expiresAt", 0) or 0) <= time.time():
        data.get("tokens", {}).pop(token, None)
        write_client_integrity(data)
        return verify_build_headers(handler)
    return True

def verify_build_headers(handler, user=None):
    settings = integrity_settings()
    if not settings["enabled"]:
        return True
    api_key = (handler.query.get("key", [""])[0] or handler.headers.get("X-Client-Api-Key") or "").strip()
    if user is None and api_key:
        user = find_user_by_api_key(api_key)
    if not user:
        return False
    if not api_key:
        api_key = user.get("apiKey") or ""
    build_id = (handler.headers.get("X-Client-Build-Id") or "").strip()
    build_stamp = (handler.headers.get("X-Client-Build-Stamp") or "").strip()
    integrity_seed = (handler.headers.get("X-Client-Integrity-Seed") or "").strip()
    build_signature = (handler.headers.get("X-Client-Build-Signature") or "").strip()
    exe_sha256 = (handler.headers.get("X-Client-Exe-Sha256") or "").strip().lower()
    if not build_id or not build_stamp or not integrity_seed or not build_signature or not exe_sha256:
        return False
    data = read_client_integrity()
    cleanup_runtime_tokens(data)
    build = data.get("builds", {}).get(build_id)
    if build:
        if build.get("revoked"):
            return False
        if build.get("userId") != user.get("id") or build.get("apiKeyHash") != sha256_hex(api_key):
            return False
        if build.get("buildStamp") != build_stamp or build.get("integritySeedHash") != sha256_hex(integrity_seed):
            return False
        if build.get("exeSha256") and build.get("exeSha256") != exe_sha256:
            return False
        return True
    expected_signature = sign_client_build(user.get("id"), api_key, build_id, build_stamp, integrity_seed, normalize_public_base_url(handler.base_url()), "")
    if not constant_time_equals(build_signature, expected_signature):
        return False
    data.setdefault("builds", {})[build_id] = {
        "id": build_id,
        "userId": user.get("id"),
        "username": user.get("username"),
        "apiKeyHash": sha256_hex(api_key),
        "baseUrl": normalize_public_base_url(handler.base_url()).rstrip("/"),
        "buildStamp": build_stamp,
        "integritySeedHash": sha256_hex(integrity_seed),
        "exeSha256": exe_sha256,
        "sourceSha256": "",
        "signature": build_signature,
        "createdAt": now_iso(),
        "firstVerifiedAt": "",
        "lastVerifiedAt": "",
        "verifyCount": 0,
        "revoked": False,
    }
    write_client_integrity(data)
    return True


def verify_client_build_request(handler):
    body = handler.read_body()
    api_key = (body.get("apiKey") or handler.query.get("key", [""])[0] or "").strip()
    user = find_user_by_api_key(api_key)
    if not user:
        return False, {"error": "工具箱对接密钥无效或账号已停用。"}, 403
    settings = integrity_settings()
    if not settings["enabled"]:
        token = issue_build_runtime_token("integrity-disabled", user.get("id"), api_key, settings["tokenTtlSeconds"])
        return True, {"ok": True, "runtimeToken": token, "expiresIn": settings["tokenTtlSeconds"]}, 200
    build_id = str(body.get("buildId") or "").strip()
    build_stamp = str(body.get("buildStamp") or "").strip()
    integrity_seed = str(body.get("integritySeed") or "").strip()
    build_signature = str(body.get("buildSignature") or "").strip()
    exe_sha256 = str(body.get("exeSha256") or "").strip().lower()
    if not build_id or not build_stamp or not integrity_seed or not exe_sha256:
        return False, {"error": "工具箱编译校验参数不完整，请从后台重新下载。"}, 400
    data = read_client_integrity()
    cleanup_runtime_tokens(data)
    build = data.get("builds", {}).get(build_id)
    if not build:
        expected_signature = sign_client_build(user.get("id"), api_key, build_id, build_stamp, integrity_seed, normalize_public_base_url(handler.base_url()), "")
        if not build_signature or not constant_time_equals(build_signature, expected_signature):
            write_client_integrity(data)
            return False, {"error": "工具箱编译记录不存在，请从后台重新下载。"}, 403
        build = {
            "id": build_id,
            "userId": user.get("id"),
            "username": user.get("username"),
            "apiKeyHash": sha256_hex(api_key),
            "baseUrl": normalize_public_base_url(handler.base_url()).rstrip("/"),
            "buildStamp": build_stamp,
            "integritySeedHash": sha256_hex(integrity_seed),
            "exeSha256": exe_sha256,
            "sourceSha256": "",
            "signature": build_signature,
            "createdAt": now_iso(),
            "firstVerifiedAt": "",
            "lastVerifiedAt": "",
            "verifyCount": 0,
            "revoked": False,
        }
        data.setdefault("builds", {})[build_id] = build
    if build.get("revoked"):
        return False, {"error": "该工具箱版本已被管理员停用，请重新下载最新版。"}, 403
    if build.get("userId") != user.get("id") or build.get("apiKeyHash") != sha256_hex(api_key):
        return False, {"error": "工具箱用户校验失败，请使用当前账号重新下载。"}, 403
    if build.get("buildStamp") != build_stamp or build.get("integritySeedHash") != sha256_hex(integrity_seed):
        return False, {"error": "工具箱编译信息校验失败，请重新下载。"}, 403
    if build.get("exeSha256") and build.get("exeSha256") != exe_sha256:
        return False, {"error": "工具箱文件已被修改，请从后台重新下载最新版。"}, 403
    token = issue_build_runtime_token(build_id, user.get("id"), api_key, settings["tokenTtlSeconds"], data)
    build["lastVerifiedAt"] = now_iso()
    build["verifyCount"] = int(build.get("verifyCount") or 0) + 1
    if not build.get("firstVerifiedAt"):
        build["firstVerifiedAt"] = build["lastVerifiedAt"]
    write_client_integrity(data)
    return True, {"ok": True, "runtimeToken": token, "expiresIn": settings["tokenTtlSeconds"]}, 200

def start_client_build_job(user, base_url, variant=DEFAULT_CLIENT_VARIANT):
    cleanup_client_build_artifacts()
    CLIENT_JOBS.mkdir(parents=True, exist_ok=True)
    job_id = random_hex(12)
    now = time.time()
    variant = normalize_client_variant(variant)
    variant_label = client_variant_info(variant).get("label") or "工具箱"
    with CLIENT_BUILD_LOCK:
        CLIENT_BUILD_JOBS[job_id] = {
            "status": "queued",
            "message": "已加入生成队列",
            "userId": user.get("id"),
            "variant": variant,
            "variantLabel": variant_label,
            "createdAt": now,
            "updatedAt": now,
        }

    def run():
        try:
            with CLIENT_BUILD_LOCK:
                CLIENT_BUILD_JOBS[job_id]["status"] = "building"
                CLIENT_BUILD_JOBS[job_id]["message"] = f"服务器正在编译 {variant_label}"
                CLIENT_BUILD_JOBS[job_id]["updatedAt"] = time.time()
            name, data = make_client_exe(user, base_url, variant)
            if not is_windows_exe(data):
                raise RuntimeError("EXE 生成结果无效，请检查服务器编译器和缓存目录。")
            exe_path = CLIENT_JOBS / f"{job_id}.exe"
            exe_path.write_bytes(data)
            with CLIENT_BUILD_LOCK:
                CLIENT_BUILD_JOBS[job_id].update({
                    "status": "done",
                    "message": "工具箱 EXE 已生成",
                    "fileName": name,
                    "variant": variant,
                    "variantLabel": variant_label,
                    "path": str(exe_path),
                    "bytes": len(data),
                    "updatedAt": time.time(),
                })
        except Exception as exc:
            with CLIENT_BUILD_LOCK:
                CLIENT_BUILD_JOBS[job_id].update({
                    "status": "error",
                    "message": str(exc),
                    "updatedAt": time.time(),
                })

    threading.Thread(target=run, daemon=True).start()
    return public_client_build_job(job_id)


def make_client_exe(user, base_url, variant=DEFAULT_CLIENT_VARIANT):
    variant = normalize_client_variant(variant)
    if not CLIENT_TEMPLATE.exists():
        raise RuntimeError("客户端模板缺失，无法生成 EXE。")
    compiler = find_csharp_compiler()
    if not compiler:
        raise RuntimeError("服务器未安装 Mono/C# 编译器，无法在线生成 EXE。后台可正常使用；如需下载 EXE，请安装 mono-devel 后重启 toolbox-admin。")
    if not CLIENT_ICON.exists():
        raise RuntimeError("工具箱默认图标缺失，请上传 assets/toolbox-default.ico 后再生成 EXE。")
    base_url = normalize_public_base_url(base_url)
    api_key = user.get("apiKey") or random_hex(20)
    user["apiKey"] = api_key
    config_url = f"{base_url.rstrip('/')}/api/toolbox/config?key={quote(api_key)}"
    source = CLIENT_TEMPLATE.read_text(encoding="utf-8")
    app_config = read_config(user.get("id")).get("app", {})
    build_id = random_hex(12)
    build_stamp = str(int(time.time()))
    integrity_seed = random_hex(16)
    exe_title = app_config.get("exe_title") or app_config.get("title") or "Toolbox"
    exe_description = app_config.get("exe_description") or app_config.get("subtitle") or exe_title
    exe_product = app_config.get("exe_product") or app_config.get("title") or exe_title
    exe_company = app_config.get("exe_company") or ""
    exe_copyright = app_config.get("exe_copyright") or ""
    exe_version = assembly_version(app_config.get("exe_version") or app_config.get("version") or "1.0.0.0")
    variant_label = client_variant_info(variant).get("label") or "工具箱"
    file_name = client_exe_filename(user, variant=variant)
    cache_key = client_cache_key(user, base_url, app_config, source, build_id, build_stamp, integrity_seed, variant)
    cached = read_client_cache(cache_key)
    if cached:
        return cached
    source = source.replace('"__CONFIG_URL__"', csharp_literal(config_url))
    embedded_config_json = json.dumps(public_toolbox_config(user.get("id"), base_url), ensure_ascii=False, separators=(",", ":"))
    source = source.replace('"__EMBEDDED_CONFIG_JSON__"', csharp_literal(embedded_config_json))
    source = source.replace('"__CLIENT_VARIANT__"', csharp_literal(variant))
    source = source.replace('"__CLIENT_VARIANT_LABEL__"', csharp_literal(variant_label))
    update_variants = app_config.get("update_variants") if isinstance(app_config.get("update_variants"), dict) else {}
    variant_update = update_variants.get(variant) if isinstance(update_variants.get(variant), dict) else {}
    client_app_version = variant_update.get("version") or app_config.get("version") or "1.0"
    source = source.replace('"__CLIENT_APP_VERSION__"', csharp_literal(client_app_version))
    source = source.replace('"__BUILD_ID__"', csharp_literal(build_id))
    source = source.replace('"__BUILD_STAMP__"', csharp_literal(build_stamp))
    build_signature = sign_client_build(user.get("id"), api_key, build_id, build_stamp, integrity_seed, base_url, "")
    source = source.replace('"__INTEGRITY_SEED__"', csharp_literal(integrity_seed))
    source = source.replace('"__BUILD_SIGNATURE__"', csharp_literal(build_signature))
    source = source.replace('"__EXE_TITLE__"', csharp_literal(exe_title))
    source = source.replace('"__EXE_DESCRIPTION__"', csharp_literal(exe_description))
    source = source.replace('"__EXE_COMPANY__"', csharp_literal(exe_company))
    source = source.replace('"__EXE_PRODUCT__"', csharp_literal(exe_product))
    source = source.replace('"__EXE_COPYRIGHT__"', csharp_literal(exe_copyright))
    source = source.replace('"__EXE_VERSION__"', csharp_literal(exe_version))
    source = source.replace('"__EXE_FILE_VERSION__"', csharp_literal(exe_version))
    with tempfile.TemporaryDirectory() as td:
        icon_file = custom_client_icon(app_config, td)
        embedded_brand_icon = base64.b64encode(
            icon_file.read_bytes()
        ).decode("ascii")
        source = source.replace(
            '"__EMBEDDED_BRAND_ICON_BASE64__"',
            csharp_literal(embedded_brand_icon)
        )
        src = Path(td) / "ToolboxClient.cs"
        exe = Path(td) / file_name
        src.write_text(source, encoding="utf-8-sig")
        compile_args = ["-codepage:65001", "-target:winexe", "-optimize+", f"-out:{exe}", f"-win32icon:{icon_file}",
                        "-r:System.dll", "-r:System.Core.dll", "-r:System.Windows.Forms.dll",
                        "-r:System.Drawing.dll", "-r:System.Web.Extensions.dll", str(src)]
        args = csharp_compile_command(compiler, compile_args)
        result = subprocess.run(args, universal_newlines=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
        if result.returncode != 0 or not exe.exists():
            raise RuntimeError("EXE 编译失败：" + (result.stderr or result.stdout))
        data = exe.read_bytes()
        if not is_windows_exe(data):
            raise RuntimeError(
                "EXE 编译完成但输出不是 Windows EXE。"
                f"检测到的编译器：{compiler}；文件头：{binary_header_preview(data)}。"
                "请安装 mono-devel 后重启 toolbox-admin，再清理旧编译缓存重试。"
            )
        exe_sha256 = hashlib.sha256(data).hexdigest()
        source_sha256 = hashlib.sha256(source.encode("utf-8")).hexdigest()
        register_client_build(user, api_key, base_url, build_id, build_stamp, integrity_seed, exe_sha256, source_sha256)
        write_client_cache(cache_key, file_name, data)
        return file_name, data


def admin_desktop_exe_filename(timestamp=None):
    return f"toolbox-admin-desktop-{int(timestamp or time.time())}.exe"


def make_admin_desktop_exe(base_url):
    if not ADMIN_DESKTOP_TEMPLATE.exists():
        raise RuntimeError("后台 EXE 模板缺失，无法生成。")
    compiler = find_csharp_compiler()
    if not compiler:
        raise RuntimeError("服务器未安装 Mono/C# 编译器，无法在线生成后台 EXE。请安装 mono-devel 后重启 toolbox-admin。")
    if not CLIENT_ICON.exists():
        raise RuntimeError("后台默认图标缺失，请上传 assets/toolbox-default.ico 后再生成 EXE。")
    base_url = normalize_public_base_url(base_url)
    source = ADMIN_DESKTOP_TEMPLATE.read_text(encoding="utf-8")
    if any(marker not in source for marker in ("Register(", "SendResetCode(", "ResetPassword(")):
        raise RuntimeError("后台 EXE 模板不完整/已过期：缺少 Register/SendResetCode/ResetPassword。")
    app_config = read_config("").get("app", {})
    exe_title = app_config.get("admin_desktop_title") or app_config.get("admin_title") or DEFAULT_ADMIN_TITLE
    exe_description = app_config.get("admin_desktop_description") or "工具箱后台桌面登录器"
    exe_product = app_config.get("admin_desktop_product") or exe_title
    exe_company = app_config.get("exe_company") or ""
    exe_copyright = app_config.get("exe_copyright") or ""
    exe_version = assembly_version(app_config.get("admin_desktop_version") or app_config.get("exe_version") or app_config.get("version") or "1.0.0.0")
    file_name = admin_desktop_exe_filename()
    source = source.replace('"__ADMIN_URL__"', csharp_literal(base_url))
    source = source.replace('"__ADMIN_TOKEN__"', csharp_literal(ADMIN_TOKEN))
    source = source.replace('"__APP_TITLE__"', csharp_literal(exe_title))
    source = source.replace('"__LOGIN_HINT__"', csharp_literal(app_config.get("login_hint") or DEFAULT_LOGIN_HINT))
    source = source.replace('"__EXE_TITLE__"', csharp_literal(exe_title))
    source = source.replace('"__EXE_DESCRIPTION__"', csharp_literal(exe_description))
    source = source.replace('"__EXE_COMPANY__"', csharp_literal(exe_company))
    source = source.replace('"__EXE_PRODUCT__"', csharp_literal(exe_product))
    source = source.replace('"__EXE_COPYRIGHT__"', csharp_literal(exe_copyright))
    source = source.replace('"__EXE_VERSION__"', csharp_literal(exe_version))
    source = source.replace('"__EXE_FILE_VERSION__"', csharp_literal(exe_version))
    with tempfile.TemporaryDirectory() as td:
        icon_file = custom_client_icon(app_config, td)
        src = Path(td) / "ToolboxAdminDesktop.cs"
        exe = Path(td) / file_name
        src.write_text(source, encoding="utf-8-sig")
        compile_args = [
            "-codepage:65001",
            "-target:winexe",
            "-optimize+",
            f"-out:{exe}",
            f"-win32icon:{icon_file}",
            "-r:System.dll",
            "-r:System.Core.dll",
            "-r:System.Windows.Forms.dll",
            "-r:System.Drawing.dll",
            "-r:System.Web.Extensions.dll",
            "-r:System.Security.dll",
            str(src),
        ]
        args = csharp_compile_command(compiler, compile_args)
        result = subprocess.run(args, universal_newlines=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
        if result.returncode != 0 or not exe.exists():
            raise RuntimeError("后台 EXE 编译失败：" + (result.stderr or result.stdout))
        data = exe.read_bytes()
        if not is_windows_exe(data):
            raise RuntimeError(
                "后台 EXE 编译完成但输出不是 Windows EXE。"
                f"检测到的编译器：{compiler}；文件头：{binary_header_preview(data)}。"
                "请安装 mono-devel 后重启 toolbox-admin，再重试。"
            )
        return file_name, data


class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    request_queue_size = 128

    def __init__(self, *args, **kwargs):
        max_threads = max(8, int(os.environ.get("TOOLBOX_MAX_REQUEST_THREADS", "64")))
        self.request_slots = threading.BoundedSemaphore(max_threads)
        super().__init__(*args, **kwargs)

    def process_request(self, request, client_address):
        self.request_slots.acquire()
        try:
            super().process_request(request, client_address)
        except Exception:
            self.request_slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.request_slots.release()


class Handler(BaseHTTPRequestHandler):
    server_version = "ToolboxAdminApiPython/1.0"

    def read_body(self):
        length = int(self.headers.get("Content-Length", "0") or "0")
        if not length:
            return {}
        if length > 2 * 1024 * 1024:
            raise ValueError("请求内容过大。")
        body = json.loads(self.rfile.read(length).decode("utf-8") or "{}")
        route = str(getattr(self, "route", "") or "")
        if route.startswith(("/api/cloud-resolver/", "/api/admin/cloud-resolver/", "/api/agent/cloud-resolver/")):
            cloud_resolver_diagnostic_log("api_request", {
                "method": self.command.upper(), "path": route, "query": getattr(self, "query", {}),
                "body": body, "clientIp": client_ip(self),
            })
        return body

    def read_payment_body(self):
        length = int(self.headers.get("Content-Length", "0") or "0")
        if length > 512 * 1024:
            raise ValueError("支付回调内容过大。")
        raw = self.rfile.read(length).decode("utf-8", errors="replace") if length else ""
        content_type = self.headers.get("Content-Type", "").lower()
        if "application/json" in content_type:
            value = json.loads(raw or "{}")
            return value if isinstance(value, dict) else {}
        return {key: values[-1] for key, values in parse_qs(raw, keep_blank_values=True).items()}

    def send_payment_text(self, text):
        data = str(text).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.send_security_headers()
        self.end_headers()
        if self.command.upper() != "HEAD":
            self.wfile.write(data)

    def payment_callback_data(self):
        data = {key: values[-1] for key, values in (self.query or {}).items()}
        if self.command.upper() in ("POST", "PUT"):
            data.update(self.read_payment_body())
        return data

    def process_payment_callback(self):
        data = self.payment_callback_data()
        order_id = str(data.get("out_trade_no") or data.get("order_id") or "").strip()
        if not order_id:
            return False, ""
        orders = read_orders()
        order = next((item for item in orders.get("orders", []) if item.get("id") == order_id), None)
        if not order or order.get("paymentMethod") != "interface":
            return False, order_id
        settings = read_system_settings()
        provider = str(order.get("paymentProvider") or order.get("paymentChannel") or "")
        payment_type = str(order.get("paymentType") or "").lower()
        config = payment_route_config(settings, provider, payment_type, require_enabled=False)
        if provider in ("easypay", "easypay2"):
            signature = str(data.get("sign") or "").lower()
            if not signature or not hmac.compare_digest(signature, epay_sign(data, config["key"]).lower()):
                return False, order_id
            amount = float(data.get("money") or data.get("amount") or -1)
            status = str(data.get("trade_status") or data.get("status") or "").upper()
            if not math.isfinite(amount) or abs(float(order.get("amount") or 0) - amount) > 0.00001 or status not in ("TRADE_SUCCESS", "TRADE_FINISHED", "SUCCESS", "PAID"):
                return False, order_id
        else:
            if str(data.get("app_id") or "") != config.get("appId") or not verify_alipay_signature(data, config.get("publicKey")):
                return False, order_id
            amount = float(data.get("total_amount") or data.get("buyer_pay_amount") or -1)
            status = str(data.get("trade_status") or "").upper()
            if not math.isfinite(amount) or abs(float(order.get("amount") or 0) - amount) > 0.00001 or status not in ("TRADE_SUCCESS", "TRADE_FINISHED"):
                return False, order_id
        if not order.get("fulfilledAt"):
            order["paidAt"] = order.get("paidAt") or now_iso()
            external_trade_no = str(data.get("trade_no") or data.get("transaction_id") or "")
            if order.get("action") == "recharge_balance":
                fulfill_balance_recharge_order(order, paid=True, external_trade_no=external_trade_no)
            elif order.get("action") == "cloud_resolver_plan_purchase" and cloud_resolver:
                cloud_resolver.fulfill_order(_app_context(), order, external_trade_no=external_trade_no)
            elif order.get("action") == "cloud_resolver_code_generate" and cloud_resolver:
                cloud_resolver.fulfill_agent_code_order(_app_context(), order, external_trade_no=external_trade_no)
            else:
                fulfill_invite_order(order, paid=True, external_trade_no=external_trade_no)
            order["status"] = "paid"
            order["updatedAt"] = now_iso()
            write_orders(orders)
        return True, order_id

    def handle_payment_callback(self):
        PAYMENT_LOCK.acquire()
        try:
            success, _ = self.process_payment_callback()
            return self.send_payment_text("success" if success else "fail")
        except Exception:
            return self.send_payment_text("fail")
        finally:
            PAYMENT_LOCK.release()

    def send_payment_redirect(self, success, order_id=""):
        target = f"{self.base_url().rstrip('/')}/?payment={'success' if success else 'failed'}"
        if order_id:
            target += "&order=" + quote(order_id)
        self.send_response(303)
        self.send_header("Location", target)
        self.send_header("Cache-Control", "no-store")
        self.send_security_headers()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def handle_payment_return(self):
        PAYMENT_LOCK.acquire()
        try:
            try:
                success, order_id = self.process_payment_callback()
            except Exception:
                success, order_id = False, ""
            return self.send_payment_redirect(success, order_id)
        finally:
            PAYMENT_LOCK.release()

    def send_security_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'")

    def send_json(self, value, status=200):
        route = str(getattr(self, "route", "") or "")
        is_resolver_api = route.startswith(("/api/cloud-resolver/", "/api/admin/cloud-resolver/", "/api/agent/cloud-resolver/"))
        is_diagnostic_management_api = route.startswith("/api/super/cloud-resolver-diagnostics")
        if is_resolver_api and not is_diagnostic_management_api:
            cloud_resolver_diagnostic_log("api_response", {
                "method": self.command.upper(), "path": route, "status": int(status), "body": value,
            })
        data = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.send_security_headers()
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        if self.command.upper() != "HEAD":
            self.wfile.write(data)

    def send_cached_json(self, data, compressed, etag):
        if self.headers.get("If-None-Match", "").strip() == etag:
            self.send_response(304)
            self.send_header("ETag", etag)
            self.send_header("Cache-Control", "private, no-cache, must-revalidate")
            self.send_header("Vary", "Accept-Encoding")
            self.send_security_headers()
            self.end_headers()
            return
        use_gzip = "gzip" in self.headers.get("Accept-Encoding", "").lower()
        body = compressed if use_gzip else data
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "private, no-cache, must-revalidate")
        self.send_header("ETag", etag)
        self.send_header("Vary", "Accept-Encoding")
        if use_gzip:
            self.send_header("Content-Encoding", "gzip")
        self.send_security_headers()
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if self.command.upper() != "HEAD":
            self.wfile.write(body)

    def send_bytes(self, data, content_type, status=200, filename=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.send_security_headers()
        if filename:
            fallback = ascii_download_fallback(filename)
            encoded = quote(str(filename), safe="")
            self.send_header("Content-Disposition", f'attachment; filename="{fallback}"; filename*=UTF-8\'\'{encoded}')
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def do_GET(self):
        self.dispatch()

    def do_HEAD(self):
        self.dispatch()

    def do_POST(self):
        self.dispatch()

    def do_PUT(self):
        self.dispatch()

    def do_PATCH(self):
        self.dispatch()

    def do_DELETE(self):
        self.dispatch()

    def dispatch(self):
        try:
            parsed = urlparse(self.path)
            self.route = unquote(parsed.path)
            self.query = parse_qs(parsed.query)
            method = self.command.upper()
            path = self.route
            if path == "/api/payment/callback" and method in ("GET", "POST", "PUT"):
                return self.handle_payment_callback()
            if path == "/api/payment/return" and method in ("GET", "POST", "PUT"):
                return self.handle_payment_return()
            if path == "/api/health":
                return self.send_json({"ok": True, "app": "ToolboxAdminApi", "time": now_iso()})
            if path == "/api/public/brand" and method == "GET":
                return self.send_json(public_brand_config())
            if path == "/api/public/config-share" and method == "GET":
                token = self.query.get("token", [""])[0]
                return self.send_json(public_config_share(read_config_share(token), self.base_url(), include_config=True))
            if path == "/api/toolbox/verify-build" and method == "POST":
                ok, payload, status = verify_client_build_request(self)
                return self.send_json(payload, status)
            if path == "/api/toolbox/popup-config" and method == "GET":
                user = find_user_by_api_key(self.query.get("key", [""])[0] or self.headers.get("X-Client-Api-Key", ""))
                if not user:
                    return self.send_json({"error": "工具箱对接密钥无效或账号已停用。"}, 403)
                return self.send_json(public_popup_config(user["id"], self.base_url()))
            if path == "/api/toolbox/builtin-download" and method in ("GET", "HEAD"):
                return proxy_builtin_download(self)
            if path == "/api/cloud-resolver/download-file" and method in ("GET", "HEAD"):
                return proxy_cloud_download(self)
            if is_login_api_path(path) and method == "POST":
                return handle_desktop_login(self)
            if path == "/api/register" and method == "POST":
                body = self.read_body()
                code = (body.get("inviteCode") or "").strip()
                store = read_users()
                invite = next((x for x in store["inviteCodes"] if x.get("code") == code), None)
                if not invite or invite.get("active") is False:
                    raise ValueError("邀请码无效。")
                used = int(invite.get("usedCount") or 0)
                max_uses = int(invite.get("maxUses") or 1)
                if max_uses > 0 and used >= max_uses:
                    raise ValueError("邀请码已被使用。")
                user = create_user(body.get("username"), body.get("password"), body.get("displayName"), "user", None, body.get("email"))
                store = read_users()
                invite = next((x for x in store["inviteCodes"] if x.get("code") == code), None)
                invite.setdefault("usedBy", []).append({"userId": user["id"], "username": user["username"], "usedAt": now_iso()})
                invite["usedCount"] = used + 1
                if max_uses > 0 and invite["usedCount"] >= max_uses:
                    invite["active"] = False
                write_users(store)
                token = random_hex(32)
                user = mark_user_login(user["id"], self)
                SESSIONS[token] = {"userId": user["id"], "createdAt": now_iso()}
                save_sessions()
                audit_event("register_success", actor=user, target=user.get("id"), handler=self, details={"title": "注册后台账号", "method": "POST", "path": "/api/register"})
                return self.send_json({"token": token, "user": public_user(user)})
            if path == "/api/password/forgot" and method == "POST":
                body = self.read_body()
                email = (body.get("email") or "").strip().lower()
                if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
                    return self.send_json({"error": "请输入正确的邮箱地址。"}, 400)
                now = time.time()
                retry_after = max(0, int(RESET_CODE_REQUESTS.get(email, 0) + RESET_CODE_COOLDOWN_SECONDS - now + 0.999))
                if retry_after > 0:
                    return self.send_json({"error": f"请在 {retry_after} 秒后重新发送验证码。", "retryAfter": retry_after}, 429)
                RESET_CODE_REQUESTS[email] = now
                user = find_user_by_email(email)
                if not user or user.get("active", True) is False:
                    return self.send_json({"ok": True, "message": "如果邮箱存在，验证码会发送到邮箱。"})
                code = str(secrets.randbelow(900000) + 100000)
                RESET_CODES[email] = {"code": code, "userId": user["id"], "expires": time.time() + 600}
                sent = send_reset_email(email, code)
                if not sent:
                    RESET_CODES.pop(email, None)
                    audit_event("password_reset_mail_unavailable", target=user.get("id"), handler=self, success=False)
                    return self.send_json({"error": "密码找回邮件服务暂不可用，请联系管理员。"}, 503)
                audit_event("password_reset_requested", target=user.get("id"), handler=self)
                return self.send_json({"ok": True, "message": "验证码已发送，请查看邮箱。"})
            if path == "/api/password/reset" and method == "POST":
                body = self.read_body()
                email = (body.get("email") or "").strip().lower()
                code = (body.get("code") or "").strip()
                password = body.get("password") or ""
                verify_key = f"{client_ip(self)}:{email}"
                now = time.time()
                attempts = [stamp for stamp in RESET_VERIFY_ATTEMPTS.get(verify_key, []) if now - stamp < LOGIN_WINDOW_SECONDS]
                if len(attempts) >= LOGIN_MAX_FAILURES:
                    audit_event("password_reset_blocked", target=email, handler=self, success=False)
                    return self.send_json({"error": "验证尝试过多，请 15 分钟后重试。"}, 429)
                record = RESET_CODES.get(email)
                if not record or record.get("code") != code or record.get("expires", 0) < time.time():
                    attempts.append(now)
                    RESET_VERIFY_ATTEMPTS[verify_key] = attempts
                    return self.send_json({"error": "验证码无效或已过期。"}, 400)
                if len(password) < 10:
                    return self.send_json({"error": "密码至少 10 位。"}, 400)
                update_user_account(record["userId"], {"password": password})
                RESET_CODES.pop(email, None)
                RESET_VERIFY_ATTEMPTS.pop(verify_key, None)
                audit_event("password_reset_completed", target=record["userId"], handler=self)
                return self.send_json({"ok": True})
            if path in ("/api/toolbox/config", "/api/config"):
                user = find_user_by_api_key(self.query.get("key", [""])[0])
                if not user:
                    return self.send_json({"error": "工具箱对接密钥无效或账号已停用。"}, 403)
                data, compressed, etag = public_toolbox_config_payload(user["id"], self.base_url())
                return self.send_cached_json(data, compressed, etag)
            if path in ("/api/client/software-catalog/home", "/api/client/software-catalog/search", "/api/client/software-catalog/resolve"):
                api_key = (self.query.get("key", [""])[0] or self.headers.get("X-Client-Api-Key", "")).strip()
                if not find_user_by_api_key(api_key): return self.send_json({"error": "工具箱对接密钥无效或账号已停用。"}, 403)
                if path.endswith("/home") and method == "GET":
                    rows, source = software_catalog_home(); software_catalog_register(rows); software_catalog_attach_cached_urls(rows)
                    return self.send_json({"items": rows, "source": source, "offline": source != "online"})
                if path.endswith("/search") and method == "GET":
                    rows, source = software_catalog_search(self.query.get("q", [""])[0]); software_catalog_register(rows); software_catalog_attach_cached_urls(rows)
                    return self.send_json({"items": rows, "source": source, "offline": source != "online"})
                if path.endswith("/resolve") and method == "POST":
                    item_id = str(self.read_body().get("id") or "").strip()
                    if not re.fullmatch(r"[A-Za-z0-9_.:-]{1,120}", item_id): return self.send_json({"error": "条目 ID 无效。"}, 400)
                    url = software_catalog_resolve(item_id)
                    return self.send_json({"downloadUrl": url}) if url else self.send_json({"error": "下载地址暂不可用。"}, 404)
                return self.send_json({"error": "请求方法不支持。"}, 405)

            if path.startswith("/api/"):
                auth = get_auth(self)
                if not auth:
                    return self.send_json({"error": "请先登录。"}, 401)
                cloud_resolver_path = (
                    path.startswith("/api/cloud-resolver/") or
                    path.startswith("/api/admin/cloud-resolver/") or
                    path.startswith("/api/agent/cloud-resolver/") or
                    path.startswith("/api/admin/users/") and "/cloud-entitlement" in path
                )
                if cloud_resolver_path and not cloud_resolver:
                    return self.send_json({"error": "服务端网盘解析模块未部署或加载失败，请重新同步程序文件并重启后台。"}, 503)
                if cloud_resolver and (path.startswith("/api/cloud-resolver/") or
                                       path.startswith("/api/admin/users/") and "/cloud-entitlement" in path or
                                       path.startswith("/api/admin/cloud-resolver/") or
                                       path.startswith("/api/agent/cloud-resolver/")):
                    try:
                        return cloud_resolver.route(self, _app_context(), path, method, auth)
                    except PermissionError as exc:
                        return self.send_json({"error": str(exc)}, 403)
                    except ValueError as exc:
                        return self.send_json({"error": str(exc)}, 400)
                if should_write_generic_audit(path, method):
                    audit_event("backend_" + method.lower(), auth["user"], path, self,
                                {"title": "后台操作", "method": method, "path": path})
                if path.startswith("/api/super"):
                    return self.handle_super(path, method, auth)
                if path.startswith("/api/admin"):
                    return self.handle_admin(path, method, auth)
                return self.send_json({"error": "接口不存在。"}, 404)
            return self.serve_static(path)
        except Exception as exc:
            return self.send_json({"error": str(exc)}, 500)

    def handle_super(self, path, method, auth):
        if not can_manage_users(auth["user"]):
            return self.send_json({"error": "无权限访问用户管理。"}, 403)
        store = read_users()
        if path == "/api/super/audit" and method == "GET":
            if not is_super(auth["user"]):
                return self.send_json({"error": "无权查看操作日志。"}, 403)
            return self.send_json(read_audit_events())
        if path in ("/api/super/cloud-resolver-diagnostics", "/api/super/cloud-resolver-diagnostics/export"):
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以查看网盘解析诊断日志。"}, 403)
            if method == "GET" and path.endswith("/export"):
                content = CLOUD_RESOLVER_DIAGNOSTIC_LOG_PATH.read_bytes() if CLOUD_RESOLVER_DIAGNOSTIC_LOG_PATH.exists() else b""
                return self.send_bytes(content, "application/x-ndjson; charset=utf-8", filename="网盘解析诊断日志.jsonl")
            if method == "GET":
                result = read_cloud_resolver_diagnostics()
                result["enabled"] = cloud_resolver_diagnostic_enabled()
                return self.send_json(result)
            if method == "PATCH":
                body = self.read_body()
                enabled = body.get("enabled") is True
                was_enabled = cloud_resolver_diagnostic_enabled()
                if was_enabled and not enabled:
                    cloud_resolver_diagnostic_log("diagnostics_disabled", {"actor": auth["user"].get("username", "")})
                settings = write_system_settings({"cloudResolverDiagnosticsEnabled": enabled})
                if enabled:
                    cloud_resolver_diagnostic_log("diagnostics_enabled", {"actor": auth["user"].get("username", "")})
                return self.send_json({"enabled": settings.get("cloudResolverDiagnosticsEnabled") is True})
            if method == "DELETE":
                body = self.read_body()
                if not check_password(str(body.get("currentPassword") or ""), auth["user"].get("passwordHash", "")):
                    return self.send_json({"error": "当前管理员密码错误，未清空日志。"}, 403)
                clear_cloud_resolver_diagnostics()
                audit_event("cloud_resolver_diagnostics_cleared", actor=auth["user"], handler=self)
                return self.send_json({"ok": True})
            return self.send_json({"error": "请求方法不支持。"}, 405)
        if path == "/api/super/audit" and method == "DELETE":
            if not is_super(auth["user"]):
                return self.send_json({"error": "无权清空操作日志。"}, 403)
            body = self.read_body()
            if not check_password(str(body.get("currentPassword") or ""), auth["user"].get("passwordHash", "")):
                audit_event("audit_log_clear_failed", auth["user"], handler=self, success=False)
                return self.send_json({"error": "当前管理员密码错误。"}, 403)
            event_keys = {str(value) for value in body.get("eventKeys", []) if str(value)}
            filtered = body.get("filtered") is True
            if filtered and not event_keys:
                return self.send_json({"error": "筛选结果为空，未清理任何日志。"}, 400)
            with SECURITY_LOCK:
                AUDIT_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
                lines = AUDIT_LOG_PATH.read_text(encoding="utf-8").splitlines() if AUDIT_LOG_PATH.exists() else []
                if event_keys:
                    kept = [line for line in lines if hashlib.sha256(line.encode("utf-8")).hexdigest() not in event_keys]
                else:
                    kept = []
                AUDIT_LOG_PATH.write_text(("\n".join(kept) + "\n") if kept else "", encoding="utf-8")
            cleared = len(lines) - len(kept)
            action = "audit_log_filtered_cleared" if filtered else "audit_log_cleared"
            audit_event(action, auth["user"], handler=self, details={"cleared": cleared})
            return self.send_json({"ok": True, "cleared": cleared, "filtered": filtered})
        if path == "/api/super/ip-location/test" and method == "POST":
            if not is_super(auth["user"]):
                return self.send_json({"error": "无权测试定位接口。"}, 403)
            ip = str(self.read_body().get("ip") or client_ip(self)).strip()
            address = locate_ip(ip, True)
            audit_event("ip_location_test", auth["user"], ip, self, {"address": address})
            return self.send_json({"ip": ip, "address": address})
        if path.startswith("/api/super/template"):
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以操作新用户模板。"}, 403)
            if path == "/api/super/template":
                if method == "GET":
                    return self.send_json(read_user_template_config())
                if method == "PUT":
                    write_user_template_config(self.read_body())
                    return self.send_json(read_user_template_config())
                if method == "POST":
                    body = self.read_body()
                    action = (body.get("action") or "").strip()
                    if action == "copy_current":
                        source_user_id = (body.get("userId") or auth["user"].get("id") or "").strip()
                        return self.send_json(copy_user_config_to_template(source_user_id))
                    if action == "reset":
                        return self.send_json(reset_user_template_config())
                    raise ValueError("不支持的模板操作。")
            if path == "/api/super/template/app" and method == "PATCH":
                cfg = read_user_template_config()
                before = json_clone(cfg)
                patch = self.read_body()
                apply_basic_settings_patch(cfg, patch)
                write_user_template_config(cfg)
                details = basic_settings_audit_details(before, cfg, patch, path)
                if details["changes"]:
                    audit_event("config_basic_update", auth["user"], "user-template", self, details)
                return self.send_json(read_user_template_config())
            if path == "/api/super/template/popup" and method == "PATCH":
                cfg = read_user_template_config()
                before_popup = json_clone(cfg.get("popup") or {})
                merged = dict(cfg.get("popup") or {})
                merged.update(self.read_body())
                cfg["popup"] = normalize_popup_settings(merged)
                write_user_template_config(cfg)
                details = popup_settings_audit_details(before_popup, cfg["popup"], path)
                if details["changes"]:
                    audit_event("contact_settings_update", auth["user"], "user-template", self, details)
                return self.send_json(read_user_template_config())
            if path == "/api/super/template/buttons":
                cfg = read_user_template_config()
                if method == "GET":
                    rows, changed = button_rows(cfg)
                    if changed:
                        write_user_template_config(cfg)
                    return self.send_json(rows)
                body = self.read_body()
                before_row = find_button_audit_row(cfg, body)
                operation = "update"
                if method == "POST":
                    container = get_container(cfg, body)
                    sections = container.setdefault("sections", [])
                    while len(sections) <= int(body.get("sectionIndex", 0)):
                        sections.append({"title": "默认分组", "buttons": []})
                    payload = dict(body.get("button") or body)
                    created = new_button(payload)
                    sections[int(body.get("sectionIndex", 0))].setdefault("buttons", []).append(created)
                    body["id"] = created.get("id")
                    operation = "create"
                elif method == "PATCH":
                    updated = update_button(cfg, body)
                    body["id"] = updated.get("id")
                elif method == "DELETE":
                    section, button_index = find_button_slot(cfg, body)
                    if (section["buttons"][button_index] or {}).get("action") == "script":
                        return self.send_json({"error": "内置功能不能删除，请改为停用。"}, 400)
                    del section["buttons"][button_index]
                    operation = "delete"
                else:
                    return self.send_json({"error": "接口不存在"}, 404)
                write_user_template_config(cfg)
                rows, changed = button_rows(cfg)
                if changed:
                    write_user_template_config(cfg)
                after_row = None if operation == "delete" else find_button_audit_row(cfg, body)
                details = button_audit_details(operation, before_row, after_row, path)
                if details["changes"]:
                    audit_event("button_" + operation, auth["user"], "user-template", self, details)
                return self.send_json(rows)
            return self.send_json({"error": "接口不存在"}, 404)
        if path == "/api/super/users/batch" and method == "POST":
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以批量管理账号。"}, 403)
            b = self.read_body()
            ids = set(b.get("ids") or [])
            action = b.get("action")
            if action == "delete" and not check_password(str(b.get("currentPassword") or ""), auth["user"].get("passwordHash", "")):
                audit_event("users_batch_delete_reauth_failed", auth["user"], ",".join(sorted(ids)), self, success=False)
                return self.send_json({"error": "删除用户前必须验证当前管理员密码。"}, 403)
            if "admin" in ids and action in ("delete", "disable"):
                raise ValueError("默认总管理员不能删除或停用。")
            changed = 0
            if action == "delete":
                security_backup("users-batch-delete", [USERS_PATH, SESSIONS_PATH])
                before = len(store["users"])
                store["users"] = [u for u in store["users"] if u.get("id") not in ids]
                changed = before - len(store["users"])
            elif action in ("enable", "disable"):
                for user in store["users"]:
                    if user.get("id") in ids:
                        user["active"] = action == "enable"
                        changed += 1
            elif action in ("allow_json", "deny_json"):
                for user in store["users"]:
                    if user.get("id") in ids:
                        user["canViewJson"] = action == "allow_json" or user.get("role") == "super"
                        changed += 1
            else:
                raise ValueError("不支持的批量操作。")
            write_users(store)
            if action in ("delete", "disable"):
                for user_id in ids:
                    revoke_user_sessions(user_id)
            audit_event(f"users_batch_{action}", auth["user"], ",".join(sorted(ids)), self,
                        {"changed": changed})
            return self.send_json({"ok": True, "changed": changed})
        if path == "/api/super/users":
            if method == "GET":
                return self.send_json({"users": [public_user(u, store) for u in scoped_users(store, auth["user"])]})
            if method == "POST":
                if not is_super(auth["user"]):
                    return self.send_json({"error": "只有总管理员可以创建账号。"}, 403)
                b = self.read_body()
                if str(b.get("role") or "user").strip() == "super":
                    return self.send_json({"error": "不能新增总管理员账号。"}, 400)
                return self.send_json(public_user(create_user(b.get("username"), b.get("password"), b.get("displayName"), b.get("role"), auth["user"], b.get("email"), balance=b.get("balance", 0), agent_level_id=b.get("agentLevelId", ""))))
            if method == "PATCH":
                b = self.read_body()
                if not is_super(auth["user"]):
                    assert_user_scope(auth["user"], b.get("id"))
                    allowed = {"id": b.get("id")}
                    if "active" in b:
                        allowed["active"] = bool(b.get("active"))
                    b = allowed
                target = next((u for u in store["users"] if u.get("id") == b.get("id")), None)
                sensitive = bool(b.get("password") or b.get("resetApiKey"))
                sensitive = sensitive or (target and "email" in b and (b.get("email") or "").strip().lower() != (target.get("email") or "").strip().lower())
                if sensitive and not check_password(str(b.get("currentPassword") or ""), auth["user"].get("passwordHash", "")):
                    audit_event("account_admin_reauth_failed", auth["user"], b.get("id"), self, success=False)
                    return self.send_json({"error": "修改敏感账号资料前必须验证当前管理员密码。"}, 403)
                user = update_user_account(b.get("id"), b, True, auth["user"])
                audit_event("account_admin_update", auth["user"], user.get("id"), self,
                            {"fields": sorted(k for k in b if k not in ("password", "currentPassword"))})
                return self.send_json(public_user(user))
            if method == "DELETE":
                if not is_super(auth["user"]):
                    return self.send_json({"error": "只有总管理员可以删除账号。"}, 403)
                b = self.read_body()
                if b.get("id") == "admin":
                    raise ValueError("不能删除默认总管理员。")
                if not check_password(str(b.get("currentPassword") or ""), auth["user"].get("passwordHash", "")):
                    audit_event("user_delete_reauth_failed", auth["user"], b.get("id"), self, success=False)
                    return self.send_json({"error": "删除用户前必须验证当前管理员密码。"}, 403)
                security_backup(f"user-delete-{b.get('id')}", [USERS_PATH, SESSIONS_PATH, user_config_path(b.get("id"))])
                store["users"] = [u for u in store["users"] if u.get("id") != b.get("id")]
                write_users(store)
                revoke_user_sessions(b.get("id"))
                audit_event("user_delete", auth["user"], b.get("id"), self)
                return self.send_json({"ok": True})
        if path == "/api/super/users/agent" and method == "POST":
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以管理代理身份和余额。"}, 403)
            body = self.read_body()
            user = update_agent_status(body.get("id"), body.get("action"), body)
            audit_event("agent_account_update", auth["user"], user.get("id"), self, {"action": body.get("action")})
            return self.send_json({"ok": True, "user": public_user(user, store)})
        if path == "/api/super/invites/quote" and method == "POST":
            return self.send_json(invite_quote_for_actor(store, auth["user"], self.read_body()))
        if path == "/api/super/balance/quote" and method == "POST":
            return self.send_json(balance_quote_for_actor(auth["user"], self.read_body()))
        if path == "/api/super/balance/recharge" and method == "POST":
            if not is_agent(auth["user"]):
                return self.send_json({"error": "只有代理账号可以充值余额。"}, 403)
            return self.send_json(create_balance_recharge_order(auth["user"], self.read_body(), self.base_url()))
        if path.startswith("/api/super/orders/") and method == "GET":
            order_id = unquote(path.rsplit("/", 1)[-1]).strip()
            if not order_id:
                return self.send_json({"error": "订单不存在。"}, 404)
            order = next((item for item in read_orders().get("orders", [])
                          if item.get("id") == order_id), None)
            if not order:
                return self.send_json({"error": "订单不存在。"}, 404)
            owner_id = order.get("userId") or order.get("agentId")
            if not is_super(auth["user"]) and owner_id != auth["user"].get("id"):
                return self.send_json({"error": "无权查看这个订单。"}, 403)
            return self.send_json(public_order(order))
        if path == "/api/super/invites":
            if method == "GET":
                return self.send_json({"invites": [public_invite(item, auth["user"])
                                                    for item in scoped_invites(store, auth["user"])]})
            if method == "POST":
                b = self.read_body()
                result = create_invites_for_actor(store, auth["user"], b, self.base_url())
                if result.get("created"):
                    write_users(store)
                return self.send_json(result)
            if method == "PATCH":
                b = self.read_body()
                code = str(b.get("code") or "").strip()
                with INVITE_LOCK:
                    store = read_users()
                    invite = next((x for x in scoped_invites(store, auth["user"])
                                   if x.get("code") == code), None)
                    if not invite:
                        return self.send_json({"error": "邀请码不存在或无权操作。"}, 404)
                    if not is_super(auth["user"]) and any(key not in ("code", "active") for key in b):
                        return self.send_json({"error": "代理只能启用或停用自己的未使用邀请码。"}, 403)
                    if "active" in b:
                        if invite_is_used(invite):
                            return self.send_json({"error": "邀请码使用后不能再启用或停用。"}, 400)
                        requested_active = bool(b.get("active"))
                        if not is_super(auth["user"]) and invite.get("superDisabled"):
                            return self.send_json({"error": "该邀请码已被总管理员停用，只能由总管理员启用。"}, 403)
                        invite["active"] = requested_active
                        if requested_active:
                            invite["superDisabled"] = False
                            invite.pop("disabledByRole", None)
                            invite.pop("disabledById", None)
                        else:
                            invite["superDisabled"] = is_super(auth["user"])
                            invite["disabledByRole"] = "super" if is_super(auth["user"]) else "agent"
                            invite["disabledById"] = auth["user"].get("id", "")
                    if "maxUses" in b:
                        invite["maxUses"] = max(1, int(b.get("maxUses") or 1))
                    if "retentionDays" in b:
                        invite["retentionDays"] = max(0, int(b.get("retentionDays") or 0))
                    write_users(store)
                    return self.send_json(public_invite(invite, auth["user"]))
            if method == "DELETE":
                if not is_super(auth["user"]):
                    return self.send_json({"error": "代理生成的邀请码不能删除，请由总管理员操作。"}, 403)
                b = self.read_body()
                codes = set(b.get("codes") or [])
                if not codes and b.get("code"):
                    codes.add(b.get("code"))
                if not codes:
                    return self.send_json({"error": "请选择要删除的邀请码。"}, 400)
                with INVITE_LOCK:
                    store = read_users()
                    found = {str(x.get("code")) for x in store.get("inviteCodes", []) if x.get("code") in codes}
                    if not found:
                        return self.send_json({"error": "邀请码不存在。"}, 404)
                    store["inviteCodes"] = [x for x in store["inviteCodes"] if x.get("code") not in found]
                    write_users(store)
                return self.send_json({"ok": True, "deleted": len(found)})
        if path == "/api/super/mail":
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以操作。"}, 403)
            if method == "GET":
                return self.send_json(public_mail_settings())
            if method == "PATCH":
                write_mail_settings(self.read_body())
                return self.send_json(public_mail_settings())
        if path == "/api/super/mail/test" and method == "POST":
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以操作。"}, 403)
            body = self.read_body()
            email = (body.get("email") or "").strip()
            if not email:
                raise ValueError("请输入测试收件邮箱。")
            code = str(secrets.randbelow(900000) + 100000)
            if not send_reset_email(email, code):
                raise ValueError("SMTP 未配置完整或发送失败。")
            return self.send_json({"ok": True})
        if path == "/api/super/system":
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以操作。"}, 403)
            if method == "GET":
                return self.send_json(public_system_settings())
            if method == "PATCH":
                return self.send_json(write_system_settings(self.read_body()))
        if path == "/api/super/system/variant-cover" and method == "POST":
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有超级管理员可以上传工具箱封面。"}, 403)
            body = self.read_body()
            variant_id = str(body.get("variantId") or "").strip()
            if variant_id not in CLIENT_VARIANTS:
                return self.send_json({"error": "工具箱版本不存在。"}, 400)
            match = re.fullmatch(r"data:image/(png|jpeg|webp|gif|x-icon|vnd\.microsoft\.icon);base64,([A-Za-z0-9+/=\r\n]+)", str(body.get("dataUrl") or ""), re.I)
            if not match:
                return self.send_json({"error": "仅支持 PNG、JPG、WEBP、GIF 或 ICO 图片。"}, 400)
            try:
                image_data = base64.b64decode(match.group(2), validate=True)
            except Exception:
                return self.send_json({"error": "封面图片数据无效。"}, 400)
            if not image_data or len(image_data) > 5 * 1024 * 1024:
                return self.send_json({"error": "封面图片不能超过 5MB。"}, 400)
            extension = {"jpeg": "jpg", "x-icon": "ico", "vnd.microsoft.icon": "ico"}.get(match.group(1).lower(), match.group(1).lower())
            signatures = {
                "png": image_data.startswith(b"\x89PNG\r\n\x1a\n"),
                "jpg": image_data.startswith(b"\xff\xd8\xff"),
                "webp": image_data.startswith(b"RIFF") and image_data[8:12] == b"WEBP",
                "gif": image_data.startswith((b"GIF87a", b"GIF89a")),
                "ico": image_data.startswith(b"\x00\x00\x01\x00"),
            }
            if not signatures.get(extension, False):
                return self.send_json({"error": "图片内容与文件格式不匹配。"}, 400)
            VARIANT_COVER_DIR.mkdir(parents=True, exist_ok=True)
            file_name = f"{variant_id}-{int(time.time())}-{random_hex(4)}.{extension}"
            (VARIANT_COVER_DIR / file_name).write_bytes(image_data)
            return self.send_json({"url": f"/uploads/variant-covers/{file_name}"})
        if path in ("/api/super/system/menu-icon", "/api/admin/menu-icon/upload") and method == "POST":
            if path.startswith("/api/super/") and not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以上传全局菜单图标。"}, 403)
            body = self.read_body()
            match = re.fullmatch(r"data:image/(png|jpeg|webp|gif|x-icon|vnd\.microsoft\.icon);base64,([A-Za-z0-9+/=\r\n]+)", str(body.get("dataUrl") or ""), re.I)
            if not match:
                return self.send_json({"error": "仅支持 PNG、JPG、WEBP、GIF 或 ICO 图片。"}, 400)
            try:
                image_data = base64.b64decode(match.group(2), validate=True)
            except Exception:
                return self.send_json({"error": "图标图片数据无效。"}, 400)
            if not image_data or len(image_data) > 2 * 1024 * 1024:
                return self.send_json({"error": "图标图片不能超过 2MB。"}, 400)
            extension = {"jpeg": "jpg", "x-icon": "ico", "vnd.microsoft.icon": "ico"}.get(match.group(1).lower(), match.group(1).lower())
            signatures = {
                "png": image_data.startswith(b"\x89PNG\r\n\x1a\n"),
                "jpg": image_data.startswith(b"\xff\xd8\xff"),
                "webp": image_data.startswith(b"RIFF") and image_data[8:12] == b"WEBP",
                "gif": image_data.startswith((b"GIF87a", b"GIF89a")),
                "ico": image_data.startswith(b"\x00\x00\x01\x00"),
            }
            if not signatures.get(extension, False):
                return self.send_json({"error": "图片内容与文件格式不匹配。"}, 400)
            settings = read_system_settings()
            folder_id = re.sub(r"[^a-zA-Z0-9_-]", "", str(body.get("folderId") or "default")) or "default"
            folder = next((item for item in settings.get("menuIconFolders", []) if str(item.get("id")) == folder_id), None)
            folder_name = str((folder or {}).get("name") or "默认").strip() or "默认"
            # Keep the user-facing folder name in the URL while removing path traversal characters.
            folder_name = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "", folder_name).strip(" .") or "默认"
            relative_parts = []
            raw_relative = str(body.get("relativePath") or "").replace("\\", "/")
            for part in raw_relative.split("/")[:-1]:
                clean_part = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "", part).strip(" .")
                if clean_part and clean_part not in (".", ".."): relative_parts.append(clean_part[:80])
            target_dir = MENU_ICON_DIR / folder_name
            for part in relative_parts[:8]:
                target_dir /= part
            target_dir.mkdir(parents=True, exist_ok=True)
            owner = "global" if path.startswith("/api/super/") else re.sub(r"[^a-zA-Z0-9_-]", "", str(user_id))
            file_name = f"{owner}-{int(time.time())}-{random_hex(4)}.{extension}"
            (target_dir / file_name).write_bytes(image_data)
            audit_event("menu_icon_upload", auth["user"], owner, self, {"fileName": file_name, "scope": "global" if path.startswith("/api/super/") else "user"})
            url_parts = [folder_name] + relative_parts[:8]
            return self.send_json({"url": "/uploads/menu-icons/" + "/".join(quote(part) for part in url_parts) + f"/{file_name}"})
        if path == "/api/super/system/popup/upload" and method == "POST":
            return self.send_json({"error": "联系方式图片只支持图床或外链图片地址，不能本地上传。"}, 400)
        if path == "/api/super/orders":
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以操作。"}, 403)
            data = read_orders()
            if method == "GET":
                rows = data.get("orders", [])
                if (getattr(self, "query", {}) or {}).get("scope", [""])[-1] == "cloud_resolver":
                    rows = [order for order in rows if order.get("action") in (
                        "cloud_resolver_plan_purchase", "cloud_resolver_code_generate"
                    )]
                return self.send_json({"orders": [public_order(order) for order in rows[:200]]})
            if method == "PATCH":
                body = self.read_body()
                order = next((x for x in data.get("orders", []) if x.get("id") == body.get("id")), None)
                if not order:
                    raise ValueError("订单不存在。")
                status = body.get("status") or "pending"
                if status not in ("pending", "paid", "done", "cancelled"):
                    raise ValueError("不支持的订单状态。")
                if order.get("action") == "cloud_resolver_code_generate":
                    current_status = order.get("status") or "pending"
                    if status in ("paid", "done") and not order.get("fulfilledAt"):
                        return self.send_json({"error": "代理卡密订单必须完成付款并自动发卡后，才能标记为已支付或已完成。"}, 400)
                    if status == "pending" and current_status in ("cancelled", "expired"):
                        return self.send_json({"error": "已取消或已失效的卡密订单不能重新开启，请重新下单。"}, 400)
                order["status"] = status
                order["updatedAt"] = now_iso()
                write_orders(data)
                if status in ("paid", "done", "cancelled"):
                    resolve_order_pending_notice(order)
                return self.send_json(public_order(order))
            if method == "DELETE":
                body = self.read_body()
                cloud_filter = str(body.get("cloudResolverFilter") or "").strip()
                if cloud_filter:
                    allowed_filters = {"all", "completed", "expired", "selected"}
                    if cloud_filter not in allowed_filters:
                        raise ValueError("不支持的网盘订单删除范围。")
                    selected_ids = {str(x).strip() for x in (body.get("ids") or []) if str(x).strip()}
                    removed = []
                    kept = []
                    for order in data.get("orders", []):
                        if order.get("action") not in ("cloud_resolver_plan_purchase", "cloud_resolver_code_generate"):
                            kept.append(order)
                            continue
                        public = public_order(order)
                        matches = (
                            cloud_filter == "all"
                            or (cloud_filter == "completed" and order.get("status") in ("paid", "done"))
                            or (cloud_filter == "expired" and public.get("status") == "expired")
                            or (cloud_filter == "selected" and order.get("id") in selected_ids)
                        )
                        (removed if matches else kept).append(order)
                    data["orders"] = kept
                    if removed:
                        write_orders(data)
                    return self.send_json({"ok": True, "deleted": len(removed)})
                ids = {str(x).strip() for x in (body.get("ids") or []) if str(x).strip()}
                order_id = str(body.get("id") or "").strip()
                if order_id:
                    ids.add(order_id)
                if not ids:
                    raise ValueError("请选择要删除的订单。")
                before = len(data.get("orders", []))
                data["orders"] = [x for x in data.get("orders", []) if x.get("id") not in ids]
                deleted = before - len(data.get("orders", []))
                if deleted <= 0:
                    raise ValueError("订单不存在。")
                write_orders(data)
                return self.send_json({"ok": True, "deleted": deleted})
        return self.send_json({"error": "接口不存在"}, 404)

    def handle_admin(self, path, method, auth):
        user_id = target_user_id(auth, self)
        if path.startswith("/api/admin/announcements"):
            return self.handle_admin_announcements(path, method, auth)
        if path == "/api/admin/me" and method == "GET":
            return self.send_json({"user": public_user(auth["user"]), "targetUser": public_user(find_user_by_id(user_id))})
        if path == "/api/admin/notices":
            data = read_notices()
            if method == "GET":
                notices = [n for n in data.get("notices", []) if notice_visible_to_user(n, auth["user"])]
                projected = [public_notice(n, auth["user"]["id"]) for n in notices[:80]]
                projected.extend(announcement_notice_rows(auth["user"].get("id")))
                projected.sort(key=lambda item: item.get("createdAt") or "", reverse=True)
                return self.send_json({"notices": projected[:100]})
            if method == "POST":
                if not is_super(auth["user"]):
                    return self.send_json({"error": "只有总管理员可以发送通知。"}, 403)
                body = self.read_body()
                title = (body.get("title") or "").strip()
                content = (body.get("content") or "").strip()
                if not title and not content:
                    raise ValueError("通知内容不能为空。")
                notice = {
                    "id": new_id("notice"),
                    "title": title or "通知",
                    "content": content,
                    "level": body.get("level") or "info",
                    "active": True,
                    "createdAt": now_iso(),
                    "createdBy": auth["user"].get("username"),
                    "createdByName": user_display_name(auth["user"]),
                    "createdById": auth["user"].get("id"),
                    "readBy": [],
                }
                data["notices"].insert(0, notice)
                write_notices(data)
                response = public_notice(notice, auth["user"]["id"])
                if body.get("mailPush"):
                    store = read_users()
                    recipients = [u for u in store.get("users", []) if (u.get("email") or "").strip() and notice_visible_to_user(notice, u)]
                    ok, message = send_notice_mail_to_users(notice, recipients)
                    if not ok:
                        return self.send_json({"error": f"通知已保存，但邮件发送失败：{message}"}, 400)
                    response["mailMessage"] = f"通知已发送，{message}"
                return self.send_json(response)
            if method == "PATCH":
                body = self.read_body()
                notice = next((n for n in data.get("notices", []) if n.get("id") == body.get("id")), None)
                if not notice and str(body.get("id") or "").startswith("announcement:"):
                    announcement_id = str(body.get("id"))[len("announcement:"):]
                    if body.get("read"):
                        item = next((x for x in read_admin_announcements().get("announcements", []) if x.get("id") == announcement_id), None)
                        if item and announcement_is_available(item):
                            revision = int(item.get("notification_revision") or 1)
                            mark_admin_announcement_read(announcement_id, auth["user"], revision)
                            audit_event("announcement_read", auth["user"], announcement_id, self, {"title": item.get("title"), "revision": revision})
                            return self.send_json(next((x for x in announcement_notice_rows(auth["user"].get("id")) if x.get("refId") == announcement_id), {"ok": True}))
                if not notice:
                    raise ValueError("通知不存在。")
                if body.get("read"):
                    notice.setdefault("readBy", [])
                    if auth["user"]["id"] not in notice["readBy"]:
                        notice["readBy"].append(auth["user"]["id"])
                        audit_event("notice_read", auth["user"], notice.get("id"), self, {"title": notice.get("title")})
                if body.get("hide") and (is_super(auth["user"]) or notice.get("createdById") == auth["user"].get("id")):
                    notice["active"] = False
                write_notices(data)
                return self.send_json(public_notice(notice, auth["user"]["id"]))
            if method == "DELETE":
                if not is_super(auth["user"]):
                    return self.send_json({"error": "只有总管理员可以删除所有通知。"}, 403)
                body = self.read_body()
                notice_id = (body.get("id") or "").strip()
                if notice_id:
                    before = len(data.get("notices", []))
                    data["notices"] = [n for n in data.get("notices", []) if n.get("id") != notice_id]
                    write_notices(data)
                    return self.send_json({"ok": True, "deleted": before - len(data.get("notices", []))})
                write_notices({"notices": [], "reads": {}})
                return self.send_json({"ok": True, "deleted": True})
        if path == "/api/admin/notices/mail" and method == "POST":
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以邮箱推送通知。"}, 403)
            body = self.read_body()
            notice_id = (body.get("id") or "").strip()
            if notice_id.startswith("announcement:"):
                return self.send_json({"error": "该条目是更新公告，请前往更新公告页面推送。"}, 400)
            data = read_notices()
            notice = next((n for n in data.get("notices", []) if n.get("id") == notice_id and n.get("active", True) is not False), None)
            if not notice:
                raise ValueError("通知不存在。")
            store = read_users()
            recipients = [u for u in store.get("users", []) if (u.get("email") or "").strip() and notice_visible_to_user(notice, u)]
            ok, message = send_notice_mail_to_users(notice, recipients)
            if not ok:
                return self.send_json({"error": f"邮件发送失败：{message}"}, 400)
            return self.send_json({"ok": True, "message": message})
        if path == "/api/admin/account" and method == "PATCH":
            b = self.read_body()
            old_email = (auth["user"].get("email") or "").strip().lower()
            new_email = (b.get("email") or old_email).strip().lower()
            if (b.get("password") or new_email != old_email) and not check_password(str(b.get("currentPassword") or ""), auth["user"].get("passwordHash", "")):
                return self.send_json({"error": "当前密码不正确。"}, 400)
            user = update_user_account(auth["user"]["id"], b, False)
            audit_event("account_self_update", auth["user"], auth["user"]["id"], self,
                        {"emailChanged": new_email != old_email, "passwordChanged": bool(b.get("password"))})
            return self.send_json({"user": public_user(user)})
        if path == "/api/admin/desktop/download" and method == "GET":
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以下载后台 EXE。"}, 403)
            name, data = make_admin_desktop_exe(self.base_url())
            if not is_windows_exe(data):
                return self.send_json({"error": "后台 EXE 生成结果无效，请检查服务器编译环境。"}, 500)
            return self.send_bytes(data, "application/vnd.microsoft.portable-executable", filename=name)
        if path == "/api/admin/client/variants" and method == "GET":
            return self.send_json(public_client_variants())
        if path == "/api/admin/menu-icons" and method == "GET":
            settings = read_system_settings()
            icons = list(settings.get("menuIcons") or [])
            folders = list(settings.get("menuIconFolders") or [{"id": "default", "name": "默认", "sort": 0}])
            return self.send_json({"icons": icons, "folders": folders, "libraryError": ""})
        if path == "/api/admin/client/download" and method == "GET":
            variant = request_client_variant(self)
            name, data = make_client_exe(find_user_by_id(user_id), self.base_url(), variant)
            if not is_windows_exe(data):
                return self.send_json({"error": "EXE 生成结果无效，请清理缓存后重试。"}, 500)
            if not is_super(auth["user"]):
                record_client_download(variant)
            return self.send_bytes(data, "application/vnd.microsoft.portable-executable", filename=name)
        if path == "/api/admin/client/build" and method == "POST":
            body = self.read_body()
            user = find_user_by_id(user_id)
            if not user:
                return self.send_json({"error": "目标用户不存在。"}, 404)
            variant = request_client_variant(self, body); result = start_client_build_job(user, self.base_url(), variant)
            audit_event("client_build_start", auth["user"], user_id, self, {"variant": variant, "variantLabel": client_variant_info(variant).get("label")})
            return self.send_json(result)
        if path == "/api/admin/client/build/status" and method == "GET":
            job_id = self.query.get("id", [""])[0]
            job = public_client_build_job(job_id)
            if not job:
                return self.send_json({"error": "生成任务不存在。"}, 404)
            return self.send_json(job)
        if path == "/api/admin/client/build/file" and method == "GET":
            cleanup_client_build_artifacts()
            job_id = self.query.get("id", [""])[0]
            with CLIENT_BUILD_LOCK:
                job = dict(CLIENT_BUILD_JOBS.get(job_id) or {})
            if not job:
                return self.send_json({"error": "生成任务不存在。"}, 404)
            if job.get("status") != "done":
                return self.send_json({"error": "生成任务还未完成。"}, 409)
            file_path = Path(job.get("path") or "")
            if not file_path.exists():
                return self.send_json({"error": "生成文件不存在。"}, 404)
            data = file_path.read_bytes()
            if not is_windows_exe(data):
                return self.send_json({"error": "生成文件不是有效 EXE，请重新生成。"}, 500)
            record_client_build_download(job_id, auth["user"])
            audit_event("client_build_download", auth["user"], user_id, self, {"jobId": job_id, "variant": job.get("variant"), "variantLabel": job.get("variantLabel"), "fileName": job.get("fileName")})
            return self.send_bytes(data, "application/vnd.microsoft.portable-executable", filename=job.get("fileName") or "toolbox.exe")
        if path == "/api/admin/config/export" and method == "GET":
            user = find_user_by_id(user_id) or auth["user"]
            package = config_export_package(read_config(user_id), user, self.base_url())
            data = json.dumps(package, ensure_ascii=False, indent=2).encode("utf-8")
            filename = f"toolbox-config-{ascii_file_name_part(user_display_name(user) or user_id, 'user')}-{int(time.time())}.json"
            return self.send_bytes(data, "application/json; charset=utf-8", filename=filename)
        if path == "/api/admin/config/share" and method == "POST":
            if is_super(auth["user"]) and user_id != auth["user"].get("id"):
                target = find_user_by_id(user_id)
                if not target:
                    return self.send_json({"error": "目标用户不存在。"}, 404)
            share = create_config_share(read_config(user_id), find_user_by_id(user_id) or auth["user"], self.base_url())
            return self.send_json(share)
        if path == "/api/admin/config/import" and method == "POST":
            body = self.read_body()
            source = (body.get("source") or "").strip().lower()
            if source == "url":
                payload = fetch_remote_config_payload(body.get("url") or body.get("shareUrl") or "")
            else:
                payload = body.get("payload") if "payload" in body else body
            cfg = normalize_import_config(payload)
            write_config_for_actor(cfg, user_id, auth["user"])
            return self.send_json({"ok": True, "summary": config_summary(cfg), "config": read_config(user_id)})
        if path == "/api/admin/config":
            if method == "GET":
                return self.send_json(read_config(user_id))
            if method == "PUT":
                write_config_for_actor(self.read_body(), user_id, auth["user"])
                return self.send_json(read_config(user_id))
        if path == "/api/admin/app" and method == "PATCH":
            patch = self.read_body()
            if auth["user"].get("role") != "super":
                for key in ("admin_title", "login_hint"):
                    patch.pop(key, None)
            cfg = read_config(user_id)
            before = json_clone(cfg)
            public_patch = apply_basic_settings_patch(cfg, patch)
            write_config_for_actor(cfg, user_id, auth["user"])
            if auth["user"].get("role") == "super" and should_sync_default_config(auth["user"], user_id):
                sync_public_brand_config(public_patch)
            details = basic_settings_audit_details(before, cfg, patch, path)
            if details["changes"]:
                audit_event("config_basic_update", auth["user"], user_id, self, details)
            return self.send_json(cfg)
        if path == "/api/admin/popup" and method == "PATCH":
            cfg = read_config(user_id)
            before_popup = json_clone(cfg.get("popup") or {})
            merged = dict(cfg.get("popup") or {})
            merged.update(self.read_body())
            cfg["popup"] = normalize_popup_settings(merged)
            write_config_for_actor(cfg, user_id, auth["user"])
            details = popup_settings_audit_details(before_popup, cfg["popup"], path)
            if details["changes"]:
                audit_event("contact_settings_update", auth["user"], user_id, self, details)
            return self.send_json(cfg)
        if path == "/api/admin/buttons":
            cfg = read_config(user_id)
            if method == "GET":
                rows, changed = button_rows(cfg)
                if changed:
                    write_config_for_actor(cfg, user_id, auth["user"])
                return self.send_json(rows)
            body = self.read_body()
            before_row = find_button_audit_row(cfg, body)
            operation = "update"
            if method == "POST":
                container = get_container(cfg, body)
                sections = container.setdefault("sections", [])
                while len(sections) <= int(body.get("sectionIndex", 0)):
                    sections.append({"title": "默认分组", "buttons": []})
                payload = dict(body.get("button") or body)
                created = new_button(payload)
                sections[int(body.get("sectionIndex", 0))].setdefault("buttons", []).append(created)
                body["id"] = created.get("id")
                operation = "create"
            elif method == "PATCH":
                updated = update_button(cfg, body)
                body["id"] = updated.get("id")
            elif method == "DELETE":
                section, button_index = find_button_slot(cfg, body)
                if (section["buttons"][button_index] or {}).get("action") == "script":
                    return self.send_json({"error": "内置功能不能删除，请改为停用。"}, 400)
                del section["buttons"][button_index]
                operation = "delete"
            write_config_for_actor(cfg, user_id, auth["user"])
            rows, changed = button_rows(cfg)
            if changed:
                write_config_for_actor(cfg, user_id, auth["user"])
            after_row = None if operation == "delete" else find_button_audit_row(cfg, body)
            details = button_audit_details(operation, before_row, after_row, path)
            if details["changes"]:
                audit_event("button_" + operation, auth["user"], user_id, self, details)
            return self.send_json(rows)
        if path == "/api/admin/builtin-functions" and method == "GET":
            return self.send_json({"functions": builtin_function_rows(is_super(auth["user"]))})
        return self.send_json({"error": "接口不存在"}, 404)

    def handle_admin_announcements(self, path, method, auth):
        user = auth["user"]
        user_id = user.get("id")
        mail_match = re.fullmatch(r"/api/admin/announcements/([^/]+)/mail", path)
        if mail_match and method == "POST":
            if not is_super(user):
                return self.send_json({"error": "只有超级管理员可以推送更新公告邮件。"}, 403)
            announcement_id = mail_match.group(1)
            store = read_admin_announcements()
            item = next((entry for entry in store.get("announcements", []) if str(entry.get("id")) == announcement_id), None)
            if not item:
                return self.send_json({"error": "公告不存在。"}, 404)
            if not announcement_is_available(item):
                return self.send_json({"error": "只有已发布且当前有效的公告允许推送。"}, 400)
            body = self.read_body()
            raw_ids = body.get("userIds") if isinstance(body, dict) else None
            if not isinstance(raw_ids, list) or not raw_ids:
                return self.send_json({"error": "userIds 必须是非空数组。"}, 400)
            user_ids = list(dict.fromkeys(str(value).strip() for value in raw_ids if str(value).strip()))
            if not user_ids:
                return self.send_json({"error": "userIds 必须包含有效用户 ID。"}, 400)
            users = read_users().get("users", [])
            by_id = {str(entry.get("id")): entry for entry in users}
            unknown = [value for value in user_ids if value not in by_id]
            if unknown:
                return self.send_json({"error": "包含不存在的用户 ID。", "unknownUserIds": unknown}, 400)
            result = send_announcement_mail_to_users(item, [by_id[value] for value in user_ids])
            audit_event("announcement_mail", user, announcement_id, self, {
                "announcementId": announcement_id,
                "title": item.get("title") or "",
                "selected": result["selected"],
                "sent": result["sent"],
                "failed": result["failed"],
            }, success=result["failed"] == 0)
            return self.send_json(result)
        match = re.fullmatch(r"/api/admin/announcements/([^/]+)(?:/(publish|withdraw|read))?", path)
        with ADMIN_ANNOUNCEMENT_LOCK:
            store = read_admin_announcements()
            reads_store = read_admin_announcement_reads()
            rows = store["announcements"]
            reads = reads_store["reads"]

            if path in ("/api/admin/announcements", "/api/admin/announcements/unread") and method == "GET":
                visible = rows if is_super(user) else [item for item in rows if announcement_is_available(item)]
                public_rows = [public_admin_announcement(item, user_id, reads, is_super(user)) for item in visible]
                public_rows.sort(key=lambda item: item.get("publish_time") or item.get("updated_time") or "", reverse=True)
                if path.endswith("/unread"):
                    public_rows = [item for item in public_rows if announcement_is_available(item) and not item.get("read")]
                return self.send_json({
                    "announcements": public_rows,
                    "unreadCount": sum(1 for item in public_rows if not item.get("read") and announcement_is_available(item)),
                    "isSuper": is_super(user),
                })

            if path == "/api/admin/announcements" and method == "POST":
                if not is_super(user):
                    return self.send_json({"error": "只有总管理员可以新建公告。"}, 403)
                body = self.read_body()
                item = normalize_announcement_payload(body)
                if not item["title"] or not item["content"]:
                    return self.send_json({"error": "公告标题和更新内容不能为空。"}, 400)
                timestamp = now_iso()
                item.update({
                    "id": new_id("announcement"), "status": "draft", "publish_time": "",
                    "created_time": timestamp, "updated_time": timestamp,
                    "author": user.get("username"), "notification_revision": 1,
                })
                rows.insert(0, item)
                write_json(ADMIN_ANNOUNCEMENTS_PATH, store)
                return self.send_json(public_admin_announcement(item, user_id, reads), 201)

            if path == "/api/admin/announcements/read-batch" and method == "POST":
                body = self.read_body()
                references = body.get("announcements") if isinstance(body, dict) else []
                if not isinstance(references, list):
                    return self.send_json({"error": "公告已读参数格式错误。"}, 400)
                marked = mark_admin_announcement_batch_read(rows, reads, user, references)
                if marked:
                    write_json(ADMIN_ANNOUNCEMENT_READS_PATH, reads_store)
                return self.send_json({"ok": True, "marked": marked})

            if path == "/api/admin/announcements/read-all" and method == "POST":
                for item in rows:
                    if announcement_is_available(item):
                        revision = int(item.get("notification_revision") or 1)
                        if not announcement_read_record(reads, item.get("id"), user_id, revision):
                            reads.append({"announcement_id": item.get("id"), "user_id": user_id, "username": user.get("username"), "read_time": now_iso(), "notification_revision": revision})
                write_json(ADMIN_ANNOUNCEMENT_READS_PATH, reads_store)
                return self.send_json({"ok": True})

            if not match:
                return self.send_json({"error": "公告接口不存在。"}, 404)
            announcement_id, action = match.groups()
            item = next((entry for entry in rows if entry.get("id") == announcement_id), None)
            if not item:
                return self.send_json({"error": "公告不存在。"}, 404)

            if method == "GET" and not action:
                if not is_super(user) and not announcement_is_available(item):
                    return self.send_json({"error": "公告不存在。"}, 404)
                return self.send_json(public_admin_announcement(item, user_id, reads))

            if method == "POST" and action == "read":
                if not is_super(user) and not announcement_is_available(item):
                    return self.send_json({"error": "公告不存在。"}, 404)
                revision = int(item.get("notification_revision") or 1)
                if not announcement_read_record(reads, announcement_id, user_id, revision):
                    reads.append({"announcement_id": announcement_id, "user_id": user_id, "username": user.get("username"), "read_time": now_iso(), "notification_revision": revision})
                    write_json(ADMIN_ANNOUNCEMENT_READS_PATH, reads_store)
                    audit_event("announcement_read", user, announcement_id, self, {"title": item.get("title"), "revision": revision})
                return self.send_json({"ok": True})

            if not is_super(user):
                return self.send_json({"error": "只有总管理员可以修改公告。"}, 403)

            if method == "PUT" and not action:
                body = self.read_body()
                was_published = item.get("status") == "published"
                updated = normalize_announcement_payload(body, item)
                if not updated["title"] or not updated["content"]:
                    return self.send_json({"error": "公告标题和更新内容不能为空。"}, 400)
                if was_published and body.get("renotify"):
                    updated["notification_revision"] = int(item.get("notification_revision") or 1) + 1
                updated["updated_time"] = now_iso()
                item.clear()
                item.update(updated)
                write_json(ADMIN_ANNOUNCEMENTS_PATH, store)
                return self.send_json(public_admin_announcement(item, user_id, reads))

            if method == "DELETE" and not action:
                store["announcements"] = [entry for entry in rows if entry.get("id") != announcement_id]
                write_json(ADMIN_ANNOUNCEMENTS_PATH, store)
                reads_store["reads"] = [entry for entry in reads if entry.get("announcement_id") != announcement_id]
                write_json(ADMIN_ANNOUNCEMENT_READS_PATH, reads_store)
                return self.send_json({"ok": True})

            if method == "POST" and action == "publish":
                if not item.get("title") or not item.get("content"):
                    return self.send_json({"error": "公告标题和更新内容不能为空。"}, 400)
                body = self.read_body()
                item["status"] = "published"
                item["enabled"] = True
                item["publish_time"] = clean_announcement_text(body.get("publish_time"), 50) or now_iso()
                item["updated_time"] = now_iso()
                if body.get("renotify"):
                    item["notification_revision"] = int(item.get("notification_revision") or 1) + 1
                write_json(ADMIN_ANNOUNCEMENTS_PATH, store)
                return self.send_json(public_admin_announcement(item, user_id, reads))

            if method == "POST" and action == "withdraw":
                item["status"] = "withdrawn"
                item["updated_time"] = now_iso()
                write_json(ADMIN_ANNOUNCEMENTS_PATH, store)
                return self.send_json(public_admin_announcement(item, user_id, reads))

        return self.send_json({"error": "不支持的公告操作。"}, 405)

    def base_url(self):
        configured = os.environ.get("TOOLBOX_PUBLIC_URL", "").strip()
        if configured:
            return normalize_public_base_url(configured)
        proto = self.headers.get("X-Forwarded-Proto") or self.headers.get("X-Forwarded-Scheme") or "http"
        if "," in proto:
            proto = proto.split(",", 1)[0].strip()
        host = self.headers.get("X-Forwarded-Host") or self.headers.get("Host") or "localhost:5088"
        if "," in host:
            host = host.split(",", 1)[0].strip()
        return normalize_public_base_url(f"{proto}://{host}")

    def serve_static(self, path):
        rel = path.strip("/") or "index.html"
        file_path = (WWW / rel).resolve()
        if not str(file_path).startswith(str(WWW.resolve())) or not file_path.exists() or not file_path.is_file():
            return self.send_json({"error": "接口不存在"}, 404)
        ctype = "image/x-icon" if file_path.suffix.lower() == ".ico" else (mimetypes.guess_type(str(file_path))[0] or "application/octet-stream")
        if ctype.startswith("text/") or file_path.suffix in (".js", ".json"):
            ctype += "; charset=utf-8"
        return self.send_bytes(file_path.read_bytes(), ctype)


if __name__ == "__main__":
    if not cloud_resolver:
        print(f"WARNING: cloud resolver module unavailable: {CLOUD_RESOLVER_IMPORT_ERROR or 'cloud_resolver.py not found'}", flush=True)
    ensure_admin_announcement_files()
    read_users()
    threading.Thread(target=run_client_build_cleanup_loop, daemon=True).start()
    host = os.environ.get("TOOLBOX_HOST", "127.0.0.1")
    port = int(os.environ.get("TOOLBOX_PORT", "5088"))
    print(f"Toolbox admin API started: http://{host}:{port}/", flush=True)
    ThreadingHTTPServer((host, port), Handler).serve_forever()
