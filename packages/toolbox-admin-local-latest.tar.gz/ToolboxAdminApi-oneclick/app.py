#!/usr/bin/env python3
import hashlib
import hmac
import base64
import gzip
import ipaddress
import json
import mimetypes
import os
import re
import secrets
import shutil
import smtplib
import subprocess
import tempfile
import threading
import time
import urllib.request
import urllib.error
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from email.message import EmailMessage
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urljoin, urlparse

ROOT = Path(__file__).resolve().parent
WWW = ROOT / "wwwroot"
DATA = ROOT / "data"
USERS_PATH = DATA / "users.json"
MAIL_PATH = DATA / "mail.json"
SYSTEM_PATH = DATA / "system.json"
NOTICES_PATH = DATA / "notices.json"
ADMIN_ANNOUNCEMENTS_PATH = DATA / "admin-announcements.json"
ADMIN_ANNOUNCEMENT_READS_PATH = DATA / "admin-announcement-reads.json"
ORDERS_PATH = DATA / "orders.json"
SESSIONS_PATH = DATA / "sessions.json"
USER_TEMPLATE_PATH = DATA / "user-template.json"
USER_DATA = DATA / "users"
CONFIG_SHARES_PATH = DATA / "config-shares.json"
CLIENT_TEMPLATE = ROOT / "client-template" / "ToolboxClient.cs"
ADMIN_DESKTOP_TEMPLATE = ROOT / "admin-desktop-template" / "ToolboxAdminDesktop.cs"
CLIENT_ICON = ROOT / "assets" / "toolbox-default.ico"
CLIENT_CACHE = DATA / "client-cache"
CLIENT_JOBS = DATA / "client-jobs"
CLIENT_INTEGRITY_PATH = DATA / "client-integrity.json"
CLIENT_DOWNLOAD_STATS_PATH = DATA / "client-download-stats.json"
AUDIT_LOG_PATH = DATA / "security-audit.jsonl"
AUDIT_LOG_MAX_BYTES = 8 * 1024 * 1024
AUDIT_LOG_KEEP_EVENTS = 5000
IP_CACHE_PATH = DATA / "ip-location-cache.json"
BACKUP_DIR = DATA / "security-backups"
VARIANT_COVER_DIR = WWW / "uploads" / "variant-covers"
MENU_ICON_DIR = WWW / "uploads" / "menu-icons"
MENU_ICON_LIBRARY_DIR = WWW / "uploads" / "menu-icon-library"
MENU_ICON_LIBRARY_TOKEN_CACHE = {}
MENU_ICON_LIBRARY_LOGIN_LOCK = threading.Lock()
ICON_CACHE = DATA / "icon-cache"
DEFAULT_APP_ICON = "/assets/toolbox-default-icon.png"
DEFAULT_ADMIN_TITLE = "工具箱后台登录"
DEFAULT_LOGIN_HINT = ""
STUDIO_OVERVIEW_PAGE_ID = "system_overview"


def default_studio_overview_page():
    return {
        "title": "\u7cfb\u7edf\u6982\u89c8",
        "name": "\u7cfb\u7edf\u6982\u89c8",
        "sections": [{
            "title": "\u53f3\u4e0b\u89d2\u5feb\u6377\u56fe\u6807",
            "buttons": [
                {"id": "overview_browser", "name": "\u6d4f\u89c8\u5668", "sort": 10, "icon": "", "action": "link", "url": "https://www.microsoft.com/edge", "target": "https://www.microsoft.com/edge", "enabled": True},
                {"id": "overview_wechat", "name": "\u5fae\u4fe1", "sort": 20, "icon": "", "action": "link", "url": "", "target": "", "enabled": True},
                {"id": "overview_yy", "name": "YY\u8bed\u97f3", "sort": 30, "icon": "", "action": "link", "url": "", "target": "", "enabled": True},
                {"id": "overview_studio_one", "name": "Studio one", "sort": 40, "icon": "", "action": "link", "url": "", "target": "", "enabled": True},
                {"id": "overview_karaoke", "name": "\u5168\u6c11K\u6b4c", "sort": 50, "icon": "", "action": "link", "url": "", "target": "", "enabled": True},
                {"id": "overview_live", "name": "\u76f4\u64ad\u4f34\u4fa3", "sort": 60, "icon": "", "action": "link", "url": "", "target": "", "enabled": True},
            ]
        }]
    }


def ensure_studio_overview_page(config):
    if not isinstance(config, dict):
        return False
    pages = config.setdefault("pages", {})
    if not isinstance(pages, dict):
        config["pages"] = {}
        pages = config["pages"]
    if STUDIO_OVERVIEW_PAGE_ID not in pages or not isinstance(pages.get(STUDIO_OVERVIEW_PAGE_ID), dict):
        pages[STUDIO_OVERVIEW_PAGE_ID] = default_studio_overview_page()
        return True
    page = pages[STUDIO_OVERVIEW_PAGE_ID]
    changed = False
    if not page.get("title"):
        page["title"] = "\u7cfb\u7edf\u6982\u89c8"
        changed = True
    sections = page.setdefault("sections", [])
    if not isinstance(sections, list) or not sections:
        page["sections"] = default_studio_overview_page()["sections"]
        changed = True
    else:
        first = sections[0] if isinstance(sections[0], dict) else {}
        if not isinstance(sections[0], dict):
            sections[0] = first
            changed = True
        first.setdefault("title", "\u53f3\u4e0b\u89d2\u5feb\u6377\u56fe\u6807")
        if not isinstance(first.get("buttons"), list):
            first["buttons"] = []
            changed = True
    return changed
ADMIN_TOKEN = os.environ.get("TOOLBOX_ADMIN_TOKEN", "").strip()
SESSIONS = {}
SECURITY_LOCK = threading.RLock()
LOGIN_ATTEMPTS = {}
SESSION_TTL_SECONDS = max(900, int(os.environ.get("TOOLBOX_SESSION_TTL_SECONDS", "43200")))
LOGIN_WINDOW_SECONDS = 15 * 60
LOGIN_MAX_FAILURES = 8
CLIENT_BUILD_JOBS = {}
CLIENT_BUILD_LOCK = threading.Lock()
ADMIN_ANNOUNCEMENT_LOCK = threading.RLock()
PUBLIC_CONFIG_CACHE_LOCK = threading.RLock()
PUBLIC_CONFIG_CACHE = {}
API_KEY_CACHE_LOCK = threading.RLock()
API_KEY_CACHE = {"signature": None, "users": {}}
JSON_WRITE_LOCK = threading.RLock()
CLIENT_RUNTIME_TOKEN_TTL = 7 * 24 * 60 * 60
RESET_CODES = {}
RESET_CODE_REQUESTS = {}
RESET_VERIFY_ATTEMPTS = {}
RESET_CODE_COOLDOWN_SECONDS = 60
DEFAULT_CLIENT_VARIANT = "original"
CLIENT_VARIANTS = {
    "original": {
        "id": "original",
        "label": "原版工具箱",
        "file": "original",
        "description": "保留最开始的工具箱界面，继续跟随后台配置的主题、标题和按钮布局。",
    },
    "studio": {
        "id": "studio",
        "label": "调音师经典版",
        "file": "studio",
        "description": "左侧导航、分组面板和紧凑按钮布局，适合系统工具与音频维护场景。",
    },
    "tuner": {
        "id": "tuner",
        "label": "调音师工具箱简约版",
        "file": "tuner",
        "description": "按本地调音师工具箱的白色标题栏、左侧导航、折叠分组和底部状态栏复刻，继续使用当前后台配置和内置下载模块。",
    },
    "audio": {
        "id": "audio",
        "label": "音频工具箱火山版",
        "file": "audio",
        "description": "按火山源码新增的音频工具箱界面。",
    },
    "portal": {
        "id": "portal",
        "label": "导航首页版",
        "file": "portal",
        "description": "首页横幅、导航侧栏和资源卡片布局，适合软件中心与资源入口场景。",
    },
}

SCRIPT_LABELS = {
    "preset_new_machine": "新机一键优化",
    "preset_audio_workstation": "音频工站优化",
    "preset_privacy_lockdown": "隐私加固",
    "preset_pure_activate": "纯净激活套装",
    "sys_control_panel": "控制面板",
    "sys_sound_settings": "声音设置",
    "open_network_connections": "网络连接",
    "sys_apps_features": "程序和功能",
    "sys_device_manager": "设备管理器",
    "sys_disk_manager": "磁盘管理",
    "sys_computer_manager": "计算机管理",
    "sys_services": "服务",
    "sys_task_manager": "任务管理器",
    "sys_system_info": "系统信息",
    "sys_env_vars": "环境变量",
    "sys_event_viewer": "事件查看器",
    "sys_registry": "注册表",
    "sys_group_policy": "组策略",
    "sys_cmd_prompt": "命令提示符",
    "sys_security_policy": "安全策略",
    "disable_firewall": "关闭防火墙",
    "disable_update": "禁用系统更新",
    "sys_power_options": "电源管理",
    "sys_classic_context_menu": "Win 传统右键",
    "add_hosts_block": "编辑 Hosts",
    "sys_system_clean": "系统清理",
    "disable_uac": "禁用 UAC",
    "activate_windows": "一键激活系统",
}
SCRIPT_ID_BY_LABEL = {label: key for key, label in SCRIPT_LABELS.items()}


def normalize_script_target(value):
    text = str(value or "").strip()
    return text if text in SCRIPT_LABELS else SCRIPT_ID_BY_LABEL.get(text, text)


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def parse_iso_datetime(value):
    text = str(value or "").strip()
    if not text:
        raise ValueError("empty datetime")
    native_parser = getattr(datetime, "fromisoformat", None)
    if native_parser:
        return native_parser(text.replace("Z", "+00:00"))
    normalized = text.replace("Z", "+0000")
    if re.search(r"[+-]\d\d:\d\d$", normalized):
        normalized = normalized[:-3] + normalized[-2:]
    for pattern in ("%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z"):
        try:
            return datetime.strptime(normalized, pattern)
        except ValueError:
            pass
    raise ValueError("invalid datetime")


def random_hex(n=24):
    return secrets.token_hex(n)


def new_id(prefix="id"):
    return f"{prefix}_{int(time.time() * 1000):x}_{random_hex(4)}"


def normalize_public_base_url(base_url):
    parsed = urlparse(str(base_url or "").strip())
    if not parsed.netloc:
        return str(base_url or "").rstrip("/")
    scheme = parsed.scheme or "http"
    return f"{scheme}://{parsed.netloc}"


def sha256_hex(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def stored_password(password):
    salt = secrets.token_bytes(16)
    rounds = 310000
    digest = hashlib.pbkdf2_hmac("sha256", str(password).encode("utf-8"), salt, rounds)
    return f"pbkdf2_sha256${rounds}${salt.hex()}${digest.hex()}"


def check_password(password, stored):
    if str(stored or "").startswith("pbkdf2_sha256$"):
        try:
            _, rounds, salt, digest = stored.split("$", 3)
            actual = hashlib.pbkdf2_hmac("sha256", str(password).encode("utf-8"), bytes.fromhex(salt), int(rounds))
            return hmac.compare_digest(actual, bytes.fromhex(digest))
        except (TypeError, ValueError):
            return False
    try:
        kind, salt, digest = stored.split("$", 2)
    except ValueError:
        return False
    return kind == "sha256" and sha256_hex(salt + password) == digest


def client_ip(handler):
    peer = str(handler.client_address[0] or "").strip()
    try:
        trusted_proxy = ipaddress.ip_address(peer).is_private or ipaddress.ip_address(peer).is_loopback
    except ValueError:
        trusted_proxy = False
    if trusted_proxy or os.environ.get("TOOLBOX_TRUST_PROXY", "").lower() in ("1", "true", "yes"):
        forwarded = (handler.headers.get("X-Forwarded-For") or "").split(",", 1)[0].strip()
        real_ip = (handler.headers.get("X-Real-IP") or "").strip()
        for candidate in (forwarded, real_ip):
            try:
                ipaddress.ip_address(candidate)
                return candidate[:64]
            except ValueError:
                continue
    return peer[:64]


def fetch_json_url(url):
    req = urllib.request.Request(url, headers={"User-Agent": "ToolboxAdmin/1.0"})
    with urllib.request.urlopen(req, timeout=4) as response:
        charset = response.headers.get_content_charset() or ("gbk" if "pconline" in url else "utf-8")
        return json.loads(response.read().decode(charset, "replace"))


IP_LOCATION_REGIONS = (
    ("beijing", ("\\u5317\\u4eac", "beijing")), ("shanghai", ("\\u4e0a\\u6d77", "shanghai")),
    ("tianjin", ("\\u5929\\u6d25", "tianjin")), ("chongqing", ("\\u91cd\\u5e86", "chongqing")),
    ("inner-mongolia", ("\\u5185\\u8499\\u53e4", "inner mongolia")),
    ("guangxi", ("\\u5e7f\\u897f", "guangxi")), ("tibet", ("\\u897f\\u85cf", "tibet", "xizang")),
    ("ningxia", ("\\u5b81\\u590f", "ningxia")), ("xinjiang", ("\\u65b0\\u7586", "xinjiang")),
    ("hebei", ("\\u6cb3\\u5317", "hebei")), ("shanxi", ("\\u5c71\\u897f", "shanxi")),
    ("liaoning", ("\\u8fbd\\u5b81", "liaoning")), ("jilin", ("\\u5409\\u6797", "jilin")),
    ("heilongjiang", ("\\u9ed1\\u9f99\\u6c5f", "heilongjiang")),
    ("jiangsu", ("\\u6c5f\\u82cf", "jiangsu")), ("zhejiang", ("\\u6d59\\u6c5f", "zhejiang")),
    ("anhui", ("\\u5b89\\u5fbd", "anhui")), ("fujian", ("\\u798f\\u5efa", "fujian")),
    ("jiangxi", ("\\u6c5f\\u897f", "jiangxi")), ("shandong", ("\\u5c71\\u4e1c", "shandong")),
    ("henan", ("\\u6cb3\\u5357", "henan")), ("hubei", ("\\u6e56\\u5317", "hubei")),
    ("hunan", ("\\u6e56\\u5357", "hunan")), ("guangdong", ("\\u5e7f\\u4e1c", "guangdong")),
    ("hainan", ("\\u6d77\\u5357", "hainan")), ("sichuan", ("\\u56db\\u5ddd", "sichuan")),
    ("guizhou", ("\\u8d35\\u5dde", "guizhou")), ("yunnan", ("\\u4e91\\u5357", "yunnan")),
    ("shaanxi", ("\\u9655\\u897f", "shaanxi")), ("gansu", ("\\u7518\\u8083", "gansu")),
    ("qinghai", ("\\u9752\\u6d77", "qinghai")), ("taiwan", ("\\u53f0\\u6e7e", "taiwan")),
    ("hong-kong", ("\\u9999\\u6e2f", "hong kong")), ("macao", ("\\u6fb3\\u95e8", "macao", "macau")),
)
IP_PROVIDER_PRIORITY = {"amap": 0, "tencent": 1, "baidu": 2, "pconline": 3, "system": 4, "ip-api": 5, "ipapi-co": 6, "ip-sb": 7}


def ip_location_region_key(address):
    value = str(address or "").strip().lower()
    for key, aliases in IP_LOCATION_REGIONS:
        decoded_aliases = [alias.encode("ascii").decode("unicode_escape") if "\\u" in alias else alias for alias in aliases]
        if any(alias.lower() in value for alias in decoded_aliases):
            return key
    return re.sub(r"[^a-z0-9\u3400-\u9fff]+", "", value)


def select_ip_location(results, cfg):
    if not results:
        return "未知位置"
    if cfg.get("mode") == "first":
        return results[0]["address"]
    buckets = {}
    for result in results:
        key = ip_location_region_key(result.get("address"))
        if key:
            buckets.setdefault(key, []).append(result)
    if not buckets:
        return results[0]["address"]
    threshold = max(1, int(cfg.get("threshold") or 2))
    qualified = [items for items in buckets.values() if len(items) >= threshold]
    candidates = qualified or list(buckets.values())
    winning = max(candidates, key=lambda items: (
        len(items),
        -min(IP_PROVIDER_PRIORITY.get(item.get("provider"), 99) for item in items),
    ))
    return min(winning, key=lambda item: (
        IP_PROVIDER_PRIORITY.get(item.get("provider"), 99),
        0 if re.search(r"[\u3400-\u9fff]", str(item.get("address") or "")) else 1,
    ))["address"]


def locate_ip(ip, bypass_cache=False):
    if not ip or ip in ("127.0.0.1", "::1"):
        return "本机/内网"
    cache = read_json(IP_CACHE_PATH, {})
    cfg = read_system_settings().get("ipLocation") or {}
    cached = cache.get(ip) if isinstance(cache.get(ip), dict) else {}
    if not bypass_cache and time.time() - cached.get("time", 0) < 86400 * 30:
        cached_address = str(cached.get("address") or "")
        if not cfg.get("unifiedChinese", True) or re.search(r"[\u3400-\u9fff]", cached_address):
            return cached_address
    providers = cfg.get("providers") or ["system"]
    if cfg.get("mode") == "system": providers = ["system"]
    results = []
    for provider in providers:
        address = ""
        try:
            if provider == "system":
                try:
                    data = fetch_json_url("https://whois.pconline.com.cn/ipJson.jsp?json=true&ip=%s" % quote(ip))
                    address = "".join(str(data.get(k) or "") for k in ("pro", "city", "region", "addr"))
                except Exception:
                    data = fetch_json_url("https://ipwho.is/" + quote(ip))
                    if data.get("success") is not False: address = "".join(str(data.get(k) or "") for k in ("country", "region", "city"))
            elif provider == "amap" and cfg.get("amapKey"):
                data = fetch_json_url("https://restapi.amap.com/v3/ip?output=json&ip=%s&key=%s" % (quote(ip), quote(cfg["amapKey"])))
                if str(data.get("status")) == "1": address = str(data.get("province") or "") + str(data.get("city") or "")
            elif provider == "baidu" and cfg.get("baiduKey"):
                data = fetch_json_url("https://api.map.baidu.com/location/ip?coor=bd09ll&ip=%s&ak=%s" % (quote(ip), quote(cfg["baiduKey"])))
                detail = (data.get("content") or {}).get("address_detail") or {}
                if data.get("status") == 0: address = "".join(str(detail.get(k) or "") for k in ("province", "city", "district", "street", "street_number"))
            elif provider == "tencent" and cfg.get("tencentKey"):
                data = fetch_json_url("https://apis.map.qq.com/ws/location/v1/ip?ip=%s&key=%s" % (quote(ip), quote(cfg["tencentKey"])))
                detail = (data.get("result") or {}).get("ad_info") or {}
                if data.get("status") == 0: address = "".join(str(detail.get(k) or "") for k in ("nation", "province", "city", "district"))
            elif provider == "ip-api":
                data = fetch_json_url("http://ip-api.com/json/%s?lang=zh-CN" % quote(ip))
                if data.get("status") == "success": address = "".join(str(data.get(k) or "") for k in ("country", "regionName", "city", "district"))
            elif provider == "ipapi-co":
                data = fetch_json_url("https://ipapi.co/%s/json/" % quote(ip))
                if not data.get("error"): address = "".join(str(data.get(k) or "") for k in ("country_name", "region", "city"))
            elif provider == "ip-sb":
                data = fetch_json_url("https://api.ip.sb/geoip/%s" % quote(ip))
                address = "".join(str(data.get(k) or "") for k in ("country", "region", "city"))
            elif provider == "pconline":
                data = fetch_json_url("https://whois.pconline.com.cn/ipJson.jsp?json=true&ip=%s" % quote(ip))
                address = "".join(str(data.get(k) or "") for k in ("pro", "city", "region", "addr"))
        except Exception:
            continue
        if address:
            results.append({"provider": provider, "address": address})
            if cfg.get("mode") == "first": break
    address = select_ip_location(results, cfg)
    if cfg.get("unifiedChinese", True):
        repeated = re.fullmatch(r"(.+?)\\1", address, flags=re.I)
        if repeated: address = repeated.group(1)
        location_names = {
            "Autonomous Region": "",
            "Hulun Buir": "呼伦贝尔市",
            "Hulunbuir": "呼伦贝尔市","Beijing": "北京市", "Shanghai": "上海市", "Tianjin": "天津市", "Chongqing": "重庆市", "Hebei": "河北省", "Shanxi": "山西省", "Liaoning": "辽宁省", "Jilin": "吉林省", "Heilongjiang": "黑龙江省", "Jiangsu": "江苏省", "Zhejiang": "浙江省", "Anhui": "安徽省", "Fujian": "福建省", "Jiangxi": "江西省", "Shandong": "山东省", "Henan": "河南省", "Hubei": "湖北省", "Hunan": "湖南省", "Guangdong": "广东省", "Hainan": "海南省", "Sichuan": "四川省", "Guizhou": "贵州省", "Yunnan": "云南省", "Shaanxi": "陕西省", "Gansu": "甘肃省", "Qinghai": "青海省", "Taiwan": "台湾省", "Inner Mongolia": "内蒙古自治区", "Guangxi": "广西壮族自治区", "Tibet": "西藏自治区", "Ningxia": "宁夏回族自治区", "Xinjiang": "新疆维吾尔自治区", "Hong Kong": "香港特别行政区", "Macao": "澳门特别行政区", "Macau": "澳门特别行政区"}
        for english in sorted(location_names, key=len, reverse=True):
            address = re.sub(re.escape(english), location_names[english], address, flags=re.I)
        if re.search(r"[\u3400-\u9fff]", address):
            address = re.sub(r"[A-Za-z][A-Za-z ._-]*", "", address).strip()
        address = re.sub(r"^(中国|China)", "", address, flags=re.I).strip()
    cache[ip] = {"address": address, "time": time.time()}
    write_json(IP_CACHE_PATH, cache)
    return address


def read_audit_events(limit=5000):
    if not AUDIT_LOG_PATH.exists(): return {"items": []}
    rows = []
    with AUDIT_LOG_PATH.open("r", encoding="utf-8") as stream:
        for line in stream:
            try:
                row = json.loads(line)
                row["eventKey"] = hashlib.sha256(line.rstrip("\r\n").encode("utf-8")).hexdigest()
                rows.append(row)
            except Exception: continue
    users = read_users().get("users", [])
    users_by_id = {str(user.get("id") or ""): user for user in users}
    users_by_name = {str(user.get("username") or ""): user for user in users}
    ip_cache = read_json(IP_CACHE_PATH, {})
    for row in rows:
        actor = users_by_id.get(str(row.get("actorId") or "")) or users_by_name.get(str(row.get("actor") or ""))
        if actor:
            row.setdefault("actorDisplayName", actor.get("displayName") or actor.get("username") or "")
            row.setdefault("actorEmail", actor.get("email") or "")
        cached_ip = ip_cache.get(str(row.get("ip") or ""))
        if isinstance(cached_ip, dict):
            row.setdefault("ipAddress", str(cached_ip.get("address") or ""))
    return {"items": list(reversed(rows[-limit:]))}


def audit_event(action, actor=None, target="", handler=None, details=None, success=True):
    ip = client_ip(handler) if handler else ""
    entry = {
        "time": now_iso(), "action": action, "success": bool(success),
        "actorId": (actor or {}).get("id", ""), "actor": (actor or {}).get("username", ""),
        "actorDisplayName": (actor or {}).get("displayName", ""),
        "actorEmail": (actor or {}).get("email", ""),
        "target": str(target or ""), "ip": ip,
        "ipAddress": locate_ip(ip) if ip else "",
        "details": details or {},
    }
    AUDIT_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with SECURITY_LOCK:
        with AUDIT_LOG_PATH.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(entry, ensure_ascii=False, separators=(",", ":")) + "\n")
        if AUDIT_LOG_PATH.stat().st_size > AUDIT_LOG_MAX_BYTES:
            lines = AUDIT_LOG_PATH.read_text(encoding="utf-8").splitlines()
            kept = []
            kept_bytes = 0
            for line in reversed(lines[-AUDIT_LOG_KEEP_EVENTS:]):
                line_bytes = len((line + "\n").encode("utf-8"))
                if kept and kept_bytes + line_bytes > AUDIT_LOG_MAX_BYTES:
                    break
                kept.append(line)
                kept_bytes += line_bytes
            kept.reverse()
            AUDIT_LOG_PATH.write_text(("\n".join(kept) + "\n") if kept else "", encoding="utf-8")


AUDIT_DETAILED_PATHS = {
    "/api/admin/app", "/api/admin/popup", "/api/admin/buttons",
    "/api/super/template/app", "/api/super/template/popup", "/api/super/template/buttons",
}


def should_write_generic_audit(path, method):
    if method not in ("POST", "PUT", "PATCH", "DELETE"):
        return False
    if path in ("/api/super/ip-location/test", "/api/super/audit") or path in AUDIT_DETAILED_PATHS:
        return False
    if path in ("/api/admin/announcements/read-all", "/api/admin/announcements/read-batch"):
        return False
    if re.fullmatch(r"/api/admin/announcements/[^/]+/read", path):
        return False
    return True


def audit_display_value(value, limit=180):
    if value is True:
        return "已开启"
    if value is False:
        return "已关闭"
    if value is None or value == "":
        return "未设置"
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    text = str(value).strip()
    if re.match(r"^https?://", text, re.I):
        return "已设置（链接已隐藏）"
    return text if len(text) <= limit else text[:limit] + "…"


def audit_change_rows(before, after, field_labels, keys=None):
    rows = []
    for key in (keys or field_labels.keys()):
        old_value = (before or {}).get(key)
        new_value = (after or {}).get(key)
        if old_value == new_value:
            continue
        rows.append({
            "field": field_labels.get(key, key),
            "before": audit_display_value(old_value),
            "after": audit_display_value(new_value),
        })
    return rows


APP_AUDIT_FIELDS = {
    "title": "工具箱名称", "subtitle": "副标题", "version": "版本号", "theme": "默认主题",
    "theme_count": "主题数量", "allow_client_theme": "允许客户端切换主题",
    "default_view_mode": "默认显示方式", "logo_text": "Logo 文字", "icon": "程序图标",
    "exe_icon": "EXE 图标", "window_width": "窗口宽度", "window_height": "窗口高度",
    "admin_title": "后台标题", "login_hint": "登录提示", "button_content_layout": "按钮内容布局",
    "button_content_layout_rules": "按钮布局规则",
}


def apply_basic_settings_patch(config, patch):
    payload = dict(patch or {})
    marker = object()
    delete_downloads = payload.pop("delete_downloads_on_exit", marker)
    apply_app_patch(config, payload)
    if delete_downloads is not marker:
        features = config.setdefault("features", {})
        if not isinstance(features, dict):
            features = {}
            config["features"] = features
        features["delete_downloads_on_exit"] = delete_downloads is True
        normalize_feature_settings(config)
    return payload


def basic_settings_audit_details(before, after, requested_patch, path):
    requested = dict(requested_patch or {})
    keys = [key for key in APP_AUDIT_FIELDS if key in requested]
    changes = audit_change_rows((before or {}).get("app") or {}, (after or {}).get("app") or {}, APP_AUDIT_FIELDS, keys)
    if "delete_downloads_on_exit" in requested:
        old_value = ((before or {}).get("features") or {}).get("delete_downloads_on_exit") is True
        new_value = ((after or {}).get("features") or {}).get("delete_downloads_on_exit") is True
        if old_value != new_value:
            changes.append({"field": "关闭时删除已下载文件", "before": audit_display_value(old_value), "after": audit_display_value(new_value)})
    return {"title": "修改基础信息", "category": "basic", "method": "PATCH", "path": path, "changes": changes}


def popup_rows_summary(rows):
    items = rows if isinstance(rows, list) else []
    names = [str(item.get("title") or "").strip() for item in items if isinstance(item, dict) and str(item.get("title") or "").strip()]
    suffix = "（%s）" % "、".join(names[:6]) if names else ""
    if len(names) > 6:
        suffix = suffix[:-1] + "等）"
    return "%d 项%s" % (len(items), suffix)


POPUP_AUDIT_FIELDS = {
    "enabled": "联系方式弹窗", "clickCount": "触发点击次数", "cacheMinutes": "缓存时间（分钟）",
    "title": "弹窗标题", "thanksText": "感谢文字",
}


def popup_settings_audit_details(before, after, path):
    changes = audit_change_rows(before or {}, after or {}, POPUP_AUDIT_FIELDS)
    for key, label in (("contacts", "联系方式"), ("payments", "收款方式"), ("links", "相关链接")):
        old_rows = (before or {}).get(key) or []
        new_rows = (after or {}).get(key) or []
        if old_rows != new_rows:
            changes.append({"field": label, "before": popup_rows_summary(old_rows), "after": popup_rows_summary(new_rows)})
    return {"title": "修改联系方式", "category": "contacts", "method": "PATCH", "path": path, "changes": changes}


BUTTON_AUDIT_FIELDS = {
    "name": "按钮名称", "enabled": "启用状态", "sort": "排序", "icon": "按钮图标",
    "description": "按钮说明", "action": "操作类型", "download_mode": "下载模式", "package_name": "安装包名称",
}
BUTTON_ACTION_LABELS = {"link": "打开链接", "download": "下载文件", "cmd": "执行命令", "script": "内置功能", "winget": "Winget 安装"}


def find_button_audit_row(config, body):
    rows, _ = button_rows(config)
    button_id = str((body or {}).get("id") or "")
    if button_id:
        return next((row for row in rows if str(row.get("id") or "") == button_id), None)
    for row in rows:
        if (row.get("scope") == (body or {}).get("scope") and
                row.get("pageId") == (body or {}).get("pageId") and
                row.get("tabIndex") == (body or {}).get("tabIndex") and
                int(row.get("sectionIndex") or 0) == int((body or {}).get("sectionIndex") or 0) and
                int(row.get("buttonIndex") or 0) == int((body or {}).get("buttonIndex") or 0)):
            return row
    return None


def button_location_text(row):
    if not row:
        return "未记录"
    area = str(row.get("area") or "").strip()
    section = str(row.get("section") or "").strip()
    return " / ".join(value for value in (area, section) if value) or "未记录"


def button_audit_value(key, value):
    if key == "action":
        return BUTTON_ACTION_LABELS.get(str(value or ""), audit_display_value(value))
    return audit_display_value(value)


def button_audit_details(operation, before_row, after_row, path):
    before_button = json_clone((before_row or {}).get("raw") or {})
    after_button = json_clone((after_row or {}).get("raw") or {})
    changes = []
    if operation == "create":
        for key, label in BUTTON_AUDIT_FIELDS.items():
            if key in after_button and after_button.get(key) not in (None, ""):
                changes.append({"field": label, "before": "未创建", "after": button_audit_value(key, after_button.get(key))})
        changes.append({"field": "所在位置", "before": "未创建", "after": button_location_text(after_row)})
    elif operation == "delete":
        for key, label in BUTTON_AUDIT_FIELDS.items():
            if key in before_button and before_button.get(key) not in (None, ""):
                changes.append({"field": label, "before": button_audit_value(key, before_button.get(key)), "after": "已删除"})
        changes.append({"field": "所在位置", "before": button_location_text(before_row), "after": "已删除"})
    else:
        for key, label in BUTTON_AUDIT_FIELDS.items():
            if before_button.get(key) != after_button.get(key):
                changes.append({"field": label, "before": button_audit_value(key, before_button.get(key)), "after": button_audit_value(key, after_button.get(key))})
        if get_target(before_button) != get_target(after_button) or before_button.get("files") != after_button.get("files"):
            changes.append({"field": "链接或执行目标", "before": "内容已隐藏", "after": "已修改（内容已隐藏）"})
        old_location = button_location_text(before_row)
        new_location = button_location_text(after_row)
        if old_location != new_location:
            changes.append({"field": "所在位置", "before": old_location, "after": new_location})
    name = str((after_button or before_button).get("name") or "未命名按钮")
    titles = {"create": "新增按钮", "update": "修改按钮", "delete": "删除按钮"}
    methods = {"create": "POST", "update": "PATCH", "delete": "DELETE"}
    return {
        "title": "%s：%s" % (titles[operation], name), "category": "buttons", "operation": operation,
        "method": methods[operation], "path": path, "itemName": name, "changes": changes,
    }


def security_backup(label, paths):
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    destination = BACKUP_DIR / f"{stamp}-{safe_id(label)}"
    destination.mkdir(parents=True, exist_ok=False)
    for path in paths:
        path = Path(path)
        if path.exists() and path.is_file():
            shutil.copy2(path, destination / path.name)
    return destination


def revoke_user_sessions(user_id, keep_token=""):
    with SECURITY_LOCK:
        expired = [token for token, row in SESSIONS.items()
                   if row.get("userId") == user_id and token != keep_token]
        for token in expired:
            SESSIONS.pop(token, None)
        if expired:
            save_sessions()
    return len(expired)


def hmac_sha256_hex(secret, text):
    return hmac.new(str(secret or "").encode("utf-8"), str(text or "").encode("utf-8"), hashlib.sha256).hexdigest()


def constant_time_equals(left, right):
    return hmac.compare_digest(str(left or ""), str(right or ""))


def read_json(path, fallback):
    if not path.exists():
        return fallback
    with path.open("r", encoding="utf-8-sig") as f:
        return json.load(f)


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = None
    with JSON_WRITE_LOCK:
        try:
            with tempfile.NamedTemporaryFile(
                mode="w",
                encoding="utf-8",
                dir=str(path.parent),
                prefix=path.name + ".",
                suffix=".tmp",
                delete=False,
            ) as f:
                tmp = Path(f.name)
                json.dump(value, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(str(tmp), str(path))
        finally:
            if tmp and tmp.exists():
                try:
                    tmp.unlink()
                except OSError:
                    pass


def read_json_recover_extra(path, fallback, label="JSON 文件"):
    try:
        return read_json(path, fallback)
    except json.JSONDecodeError as exc:
        if exc.msg != "Extra data":
            raise RuntimeError(f"{label} 已损坏：{exc}") from exc

    text = path.read_text(encoding="utf-8-sig")
    decoder = json.JSONDecoder()
    values = []
    index = 0
    while index < len(text):
        while index < len(text) and text[index].isspace():
            index += 1
        if index >= len(text):
            break
        try:
            value, index = decoder.raw_decode(text, index)
        except json.JSONDecodeError:
            break
        if isinstance(value, dict):
            values.append(value)
    if not values:
        raise RuntimeError(f"{label} 已损坏，且没有找到可恢复的完整数据。")

    backup_dir = path.parent / "json-recovery-backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    backup_path = backup_dir / f"{path.stem}-extra-data-{stamp}-{random_hex(4)}{path.suffix}"
    shutil.copy2(path, backup_path)
    recovered = values[-1]
    write_json(path, recovered)
    return recovered


def read_toolbox_config_json(path, fallback):
    return read_json_recover_extra(path, fallback, "工具箱配置 JSON")


ANNOUNCEMENT_TYPES = ("功能更新", "问题修复", "系统通知", "重要公告", "维护公告")
ANNOUNCEMENT_IMPORTANCE = ("普通", "重要", "紧急")


def read_json_safe(path, fallback):
    try:
        value = read_json(path, fallback)
        return value
    except Exception:
        return fallback


def read_admin_announcements():
    value = read_json_safe(ADMIN_ANNOUNCEMENTS_PATH, {"announcements": []})
    return value if isinstance(value, dict) and isinstance(value.get("announcements"), list) else {"announcements": []}


def read_admin_announcement_reads():
    value = read_json_safe(ADMIN_ANNOUNCEMENT_READS_PATH, {"reads": []})
    return value if isinstance(value, dict) and isinstance(value.get("reads"), list) else {"reads": []}


def ensure_admin_announcement_files():
    with ADMIN_ANNOUNCEMENT_LOCK:
        if not ADMIN_ANNOUNCEMENTS_PATH.exists():
            write_json(ADMIN_ANNOUNCEMENTS_PATH, {"announcements": []})
        if not ADMIN_ANNOUNCEMENT_READS_PATH.exists():
            write_json(ADMIN_ANNOUNCEMENT_READS_PATH, {"reads": []})


def clean_announcement_text(value, limit):
    text = str(value or "").replace("\x00", "").strip()
    return text[:limit]


def normalize_announcement_payload(body, current=None):
    body = body if isinstance(body, dict) else {}
    item = dict(current or {})
    item["title"] = clean_announcement_text(body.get("title", item.get("title")), 160)
    item["summary"] = clean_announcement_text(body.get("summary", item.get("summary")), 500)
    item["content"] = clean_announcement_text(body.get("content", item.get("content")), 30000)
    item["version"] = clean_announcement_text(body.get("version", item.get("version")), 80)
    announcement_type = clean_announcement_text(body.get("type", item.get("type") or "功能更新"), 30)
    item["type"] = announcement_type if announcement_type in ANNOUNCEMENT_TYPES else "功能更新"
    importance = clean_announcement_text(body.get("importance", item.get("importance") or "普通"), 20)
    item["importance"] = importance if importance in ANNOUNCEMENT_IMPORTANCE else "普通"
    item["popup_enabled"] = bool(body.get("popup_enabled", item.get("popup_enabled", True)))
    item["force_popup"] = False
    item["publish_time"] = clean_announcement_text(body.get("publish_time", item.get("publish_time")), 50)
    item["expire_time"] = clean_announcement_text(body.get("expire_time", item.get("expire_time")), 50)
    item["enabled"] = bool(body.get("enabled", item.get("enabled", True)))
    return item


def announcement_is_available(item):
    if item.get("status") != "published" or item.get("enabled", True) is False:
        return False
    publish_time = str(item.get("publish_time") or "").strip()
    if publish_time:
        try:
            if parse_iso_datetime(publish_time) > datetime.now(timezone.utc):
                return False
        except Exception:
            pass
    expires = str(item.get("expire_time") or "").strip()
    if expires:
        try:
            if parse_iso_datetime(expires) <= datetime.now(timezone.utc):
                return False
        except Exception:
            pass
    return True


def announcement_read_record(reads, announcement_id, user_id, revision):
    return next((row for row in reads if row.get("announcement_id") == announcement_id and row.get("user_id") == user_id and int(row.get("notification_revision") or 1) == revision), None)


def public_admin_announcement(item, user_id, reads):
    result = dict(item)
    revision = int(item.get("notification_revision") or 1)
    result["read"] = announcement_read_record(reads, item.get("id"), user_id, revision) is not None
    return result


def mark_admin_announcement_read(announcement_id, user, revision):
    with ADMIN_ANNOUNCEMENT_LOCK:
        store = read_admin_announcement_reads()
        reads = store["reads"]
        record = announcement_read_record(reads, announcement_id, user.get("id"), revision)
        if not record:
            reads.append({
                "announcement_id": announcement_id,
                "user_id": user.get("id"),
                "username": user.get("username"),
                "read_time": now_iso(),
                "notification_revision": revision,
            })
            write_json(ADMIN_ANNOUNCEMENT_READS_PATH, store)


def mark_admin_announcement_batch_read(rows, reads, user, references):
    """Mark exactly the announcement revisions displayed in a one-time popup."""
    if not isinstance(references, list):
        return 0
    user_id = user.get("id")
    by_id = {str(item.get("id") or ""): item for item in rows if item.get("id")}
    marked = 0
    seen = set()
    for reference in references[:200]:
        if isinstance(reference, dict):
            announcement_id = clean_announcement_text(reference.get("id"), 160)
            requested_revision = reference.get("notification_revision")
        else:
            announcement_id = clean_announcement_text(reference, 160)
            requested_revision = None
        item = by_id.get(announcement_id)
        if not item or announcement_id in seen or not announcement_is_available(item):
            continue
        revision = int(item.get("notification_revision") or 1)
        if requested_revision not in (None, ""):
            try:
                if int(requested_revision) != revision:
                    continue
            except (TypeError, ValueError):
                continue
        seen.add(announcement_id)
        if announcement_read_record(reads, announcement_id, user_id, revision):
            continue
        reads.append({
            "announcement_id": announcement_id,
            "user_id": user_id,
            "username": user.get("username"),
            "read_time": now_iso(),
            "notification_revision": revision,
        })
        marked += 1
    return marked


def client_build_cleanup_settings():
    settings = read_system_settings().get("clientBuild") or {}
    try:
        cache_hours = max(1, min(24 * 30, int(settings.get("cacheRetentionHours") or 24)))
    except Exception:
        cache_hours = 24
    try:
        job_hours = max(1, min(24 * 30, int(settings.get("jobRetentionHours") or 24)))
    except Exception:
        job_hours = 24
    try:
        interval_minutes = max(10, min(24 * 60, int(settings.get("cleanupIntervalMinutes") or 360)))
    except Exception:
        interval_minutes = 360
    try:
        max_entries = max(1, min(200, int(settings.get("maxCacheEntries") or 30)))
    except Exception:
        max_entries = 30
    return {
        "cacheSeconds": cache_hours * 60 * 60,
        "jobSeconds": job_hours * 60 * 60,
        "intervalSeconds": interval_minutes * 60,
        "maxEntries": max_entries,
    }


def read_client_integrity():
    data = read_json_recover_extra(
        CLIENT_INTEGRITY_PATH,
        {"builds": {}, "tokens": {}},
        "客户端完整性记录 JSON",
    )
    if not isinstance(data, dict):
        data = {"builds": {}, "tokens": {}}
    data.setdefault("builds", {})
    data.setdefault("tokens", {})
    return data


def write_client_integrity(data):
    data.setdefault("builds", {})
    data.setdefault("tokens", {})
    write_json(CLIENT_INTEGRITY_PATH, data)


def load_sessions():
    try:
        value = read_json(SESSIONS_PATH, {})
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def save_sessions():
    try:
        write_json(SESSIONS_PATH, SESSIONS)
    except Exception:
        pass


SESSIONS.update(load_sessions())


def default_popup_settings():
    return {
        "enabled": False,
        "clickCount": 3,
        "title": "联系我们 / 支持作者",
        "thanksText": "感谢你的支持，我们会持续维护和更新工具箱。",
        "cacheMinutes": 60,
        "contacts": [],
        "payments": [],
        "links": [],
    }


def default_config():
    return {
        "app": {
            "title": "Toolbox",
            "subtitle": "",
            "version": "V1.0",
            "logo_text": "Y",
            "icon": DEFAULT_APP_ICON,
            "admin_title": DEFAULT_ADMIN_TITLE,
            "login_hint": "",
            "window_width": 1080,
            "window_height": 700,
            "password": "",
            "theme": "鍗堝闈涜摑",
            "theme_count": 19,
            "allow_client_theme": True,
            "default_view_mode": "grid",
            "button_content_layout": "icon_left",
            "button_content_layout_rules": {
                "icon_left": {"enabled": False, "pages": []},
                "icon_top": {"enabled": False, "pages": []},
            },
            "bg_path": "",
            "output_dir": "",
        },
        "license": {"enabled": False, "api_base": "", "product_code": ""},
        "popup": default_popup_settings(),
        "features": {"software_catalog_enabled": True, "delete_downloads_on_exit": False},
        "page_locks": {},
        "page_lock_groups": {},
        "sidebar": [],
        "toolbox_tabs": [],
        "pages": {},
    }


def config_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return value != 0
    text = str(value).strip().lower()
    if text in ("1", "true", "yes", "on", "enabled", "enable", "启用", "开启"):
        return True
    if text in ("0", "false", "no", "off", "disabled", "disable", "停用", "禁用", "关闭"):
        return False
    return default


def normalize_view_mode(value, default="grid"):
    text = str(value or "").strip().lower()
    if text in ("list", "列表", "listmode", "list_mode"):
        return "list"
    if text in ("grid", "宫格", "gongge", "gridmode", "grid_mode"):
        return "grid"
    return default


def normalize_button_content_layout(value):
    value = str(value or "").strip().lower()
    return value if value in ("none", "icon_left", "icon_top") else "icon_left"


def normalize_feature_settings(config):
    changed = False
    features = config.get("features")
    if not isinstance(features, dict):
        features = {}
        config["features"] = features
        changed = True
    enabled = config_bool(features.get("software_catalog_enabled"), True)
    if features.get("software_catalog_enabled") is not enabled:
        features["software_catalog_enabled"] = enabled
        changed = True
    delete_downloads_on_exit = config_bool(features.get("delete_downloads_on_exit"), False)
    if features.get("delete_downloads_on_exit") is not delete_downloads_on_exit:
        features["delete_downloads_on_exit"] = delete_downloads_on_exit
        changed = True
    return changed


def normalize_page_locks(config):
    changed = False
    locks = config.get("page_locks")
    if not isinstance(locks, dict):
        locks = {}
        config["page_locks"] = locks
        changed = True
    for raw_page_id in list(locks.keys()):
        page_id = str(raw_page_id or "").strip()
        if not page_id:
            locks.pop(raw_page_id, None)
            changed = True
            continue
        if page_id != raw_page_id:
            locks[page_id] = locks.pop(raw_page_id)
            changed = True
        lock = locks.get(page_id)
        if not isinstance(lock, dict):
            lock = {"enabled": config_bool(lock, False), "password": ""}
            locks[page_id] = lock
            changed = True
        enabled = config_bool(lock.get("enabled"), False)
        if lock.get("enabled") is not enabled:
            lock["enabled"] = enabled
            changed = True
        password = str(lock.get("password") or "").strip()
        if password and not password.startswith(("sha256$", "pbkdf2_sha256$")):
            lock["password_plain"] = password
            password = stored_password(password)
        if lock.get("password") != password:
            lock["password"] = password
            changed = True
        if "title" in lock:
            title = str(lock.get("title") or "").strip()
            if lock.get("title") != title:
                lock["title"] = title
                changed = True
    return changed


def normalize_page_lock_groups(config):
    changed = False
    groups = config.get("page_lock_groups")
    if not isinstance(groups, dict):
        groups = {}
        config["page_lock_groups"] = groups
        changed = True
    for raw_group_id in list(groups.keys()):
        group_id = str(raw_group_id or "").strip()
        if not group_id:
            groups.pop(raw_group_id, None)
            changed = True
            continue
        if group_id != raw_group_id:
            groups[group_id] = groups.pop(raw_group_id)
            changed = True
        group = groups.get(group_id)
        if not isinstance(group, dict):
            group = {"title": "", "password": "", "pages": []}
            groups[group_id] = group
            changed = True
        password = str(group.get("password") or "").strip()
        if password and not password.startswith(("sha256$", "pbkdf2_sha256$")):
            group["password_plain"] = password
            password = stored_password(password)
        if group.get("password") != password:
            group["password"] = password
            changed = True
        pages = group.get("pages")
        if not isinstance(pages, list):
            pages = []
        normalized_pages = []
        for page_id in pages:
            page_id = str(page_id or "").strip()
            if page_id and page_id not in normalized_pages:
                normalized_pages.append(page_id)
        if group.get("pages") != normalized_pages:
            group["pages"] = normalized_pages
            changed = True
        title = str(group.get("title") or "").strip()
        if group.get("title") != title:
            group["title"] = title
            changed = True
    return changed


def safe_id(value):
    text = "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in str(value).lower()).strip("_")
    return text or "user"


def user_display_name(user):
    if not user:
        return ""
    return (user.get("displayName") or user.get("username") or user.get("id") or "").strip()


def find_user_display_name(user_id="", username=""):
    user = find_user_by_id(user_id) if user_id else None
    if not user and username:
        user = find_user_by_username(username)
    return user_display_name(user) or username or user_id or ""


def exe_file_stem(user):
    return safe_id(user_display_name(user) or "user")


def clean_download_name_part(value):
    text = str(value or "").strip()
    invalid = '<>:"/\\|?*\r\n\t\0'
    text = "".join("_" if ch in invalid else ch for ch in text)
    text = " ".join(text.split()).strip(" ._")
    return (text[:80].strip(" ._") or "user")


def ascii_file_name_part(value, fallback="user"):
    text = str(value or "").strip()
    chars = []
    for ch in text:
        if ord(ch) < 128 and (ch.isalnum() or ch in "_-."):
            chars.append(ch)
        elif ch.isspace() or ch in "-_.":
            chars.append("_")
    cleaned = "".join(chars).strip("._-")
    while "__" in cleaned:
        cleaned = cleaned.replace("__", "_")
    return (cleaned[:80].strip("._-") or fallback)


def client_exe_filename(user, timestamp=None, variant=DEFAULT_CLIENT_VARIANT):
    stamp = int(timestamp or time.time())
    stem = ascii_file_name_part((user or {}).get("username") or (user or {}).get("id") or "user")
    suffix = client_variant_file_suffix(variant)
    return f"toolbox-{stem}-{suffix}-{stamp}.exe"


def ascii_download_fallback(filename):
    path = Path(str(filename or "download.bin"))
    suffix = path.suffix or ".bin"
    stem = "".join(ch if (ord(ch) < 128 and (ch.isalnum() or ch in "_-.")) else "_" for ch in path.stem).strip("._")
    stem = stem[:80].strip("._") or "download"
    return f"{stem}{suffix}"


def normalize_client_variant(value):
    variant = str(value or "").strip().lower()
    return variant if variant in CLIENT_VARIANTS else DEFAULT_CLIENT_VARIANT


def client_variant_info(value):
    return CLIENT_VARIANTS[normalize_client_variant(value)]


def public_client_variants():
    configured = read_system_settings().get("clientVariants") or {}
    counts = read_client_download_counts()
    variants = []
    for variant_id in ("original", "studio", "tuner", "audio", "portal"):
        item = dict(CLIENT_VARIANTS[variant_id])
        values = configured.get(variant_id) if isinstance(configured.get(variant_id), dict) else {}
        for key in ("name", "badge", "description", "coverMode", "coverUrl"):
            if key in values:
                item[key] = values[key]
        item["downloadCount"] = counts.get(variant_id, 0)
        variants.append(item)
    return {"variants": variants}


def read_client_download_counts():
    data = read_json(CLIENT_DOWNLOAD_STATS_PATH, {})
    return {
        variant_id: max(0, int(data.get(variant_id) or 0))
        for variant_id in CLIENT_VARIANTS
    } if isinstance(data, dict) else {variant_id: 0 for variant_id in CLIENT_VARIANTS}


def record_client_download(variant):
    variant = normalize_client_variant(variant)
    with SECURITY_LOCK:
        counts = read_client_download_counts()
        counts[variant] = counts.get(variant, 0) + 1
        write_json(CLIENT_DOWNLOAD_STATS_PATH, counts)
        return counts[variant]


def record_client_build_download(job_id, actor):
    if is_super(actor):
        return False
    with CLIENT_BUILD_LOCK:
        job = CLIENT_BUILD_JOBS.get(job_id)
        if not job or job.get("downloadCounted"):
            return False
        job["downloadCounted"] = True
        variant = job.get("variant")
    record_client_download(variant)
    return True


def request_client_variant(handler, body=None):
    if body and body.get("variant"):
        return normalize_client_variant(body.get("variant"))
    if hasattr(handler, "query"):
        return normalize_client_variant(handler.query.get("variant", [""])[0])
    return DEFAULT_CLIENT_VARIANT


def client_variant_file_suffix(variant):
    return client_variant_info(variant).get("file") or normalize_client_variant(variant)


def find_csharp_compiler():
    compiler = shutil.which("mcs") or shutil.which("csc")
    if compiler:
        return compiler
    windows_dir = Path(os.environ.get("WINDIR", r"C:\Windows"))
    candidates = [
        windows_dir / "Microsoft.NET" / "Framework64" / "v4.0.30319" / "csc.exe",
        windows_dir / "Microsoft.NET" / "Framework" / "v4.0.30319" / "csc.exe",
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Mono" / "lib" / "mono" / "4.5" / "mcs.exe",
        Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Mono" / "lib" / "mono" / "4.5" / "mcs.exe",
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Mono" / "bin" / "mcs.exe",
        Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Mono" / "bin" / "mcs.exe",
    ]
    for candidate in candidates:
        if candidate.exists():
            return str(candidate)
    return None


def csharp_compile_command(compiler, args):
    compiler_path = Path(str(compiler or ""))
    if os.name == "nt" and compiler_path.suffix.lower() == ".exe":
        parts = [p.lower() for p in compiler_path.parts]
        if "mono" in parts and compiler_path.name.lower() in ("mcs.exe", "csc.exe"):
            mono = Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Mono" / "bin" / "mono.exe"
            if not mono.exists():
                mono = Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Mono" / "bin" / "mono.exe"
            if mono.exists():
                return [str(mono), str(compiler_path)] + args
    return [str(compiler)] + args


def is_windows_exe(data):
    return isinstance(data, (bytes, bytearray)) and len(data) >= 2 and data[:2] == b"MZ"


def binary_header_preview(data, limit=16):
    if not isinstance(data, (bytes, bytearray)) or not data:
        return "empty"
    sample = bytes(data[:limit])
    return " ".join(f"{byte:02X}" for byte in sample)


def user_config_path(user_id):
    safe = safe_id(user_id)
    return USER_DATA / safe / "config.json"


def ensure_config_defaults(config):
    app = config.setdefault("app", {})
    changed = False
    if not app.get("icon") and not app.get("icon_url") and not app.get("icon_path"):
        app["icon"] = DEFAULT_APP_ICON
        changed = True
    if "login_hint" not in app:
        app["login_hint"] = DEFAULT_LOGIN_HINT
        changed = True
    if "admin_title" not in app:
        app["admin_title"] = DEFAULT_ADMIN_TITLE
        changed = True
    default_view_mode = normalize_view_mode(app.get("default_view_mode"), "grid")
    if app.get("default_view_mode") != default_view_mode:
        app["default_view_mode"] = default_view_mode
        changed = True
    button_content_layout = normalize_button_content_layout(app.get("button_content_layout"))
    if app.get("button_content_layout") != button_content_layout:
        app["button_content_layout"] = button_content_layout
        changed = True
    rules = app.get("button_content_layout_rules")
    if not isinstance(rules, dict):
        rules = {}
    normalized_rules = {}
    for layout_id in ("icon_left", "icon_top"):
        source = rules.get(layout_id) if isinstance(rules.get(layout_id), dict) else {}
        pages = []
        for page_id in source.get("pages") or []:
            value = str(page_id or "").strip()
            if value and value not in pages:
                pages.append(value[:120])
        normalized_rules[layout_id] = {"enabled": source.get("enabled") is True, "pages": pages[:100]}
    if app.get("button_content_layout_rules") != normalized_rules:
        app["button_content_layout_rules"] = normalized_rules
        changed = True
    if normalize_feature_settings(config):
        changed = True
    if normalize_page_locks(config):
        changed = True
    if normalize_page_lock_groups(config):
        changed = True
    if ensure_studio_overview_page(config):
        changed = True
    normalized_popup = normalize_popup_settings(config.get("popup") or {})
    if config.get("popup") != normalized_popup:
        config["popup"] = normalized_popup
        changed = True
    return changed


def read_config(user_id=""):
    path = user_config_path(user_id) if user_id else DATA / "config.json"
    if not path.exists():
        if user_id and USER_TEMPLATE_PATH.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(USER_TEMPLATE_PATH, path)
        elif (DATA / "config.json").exists() and user_id:
            path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(DATA / "config.json", path)
        else:
            write_json(path, default_config())
    config = read_toolbox_config_json(path, default_config())
    changed = ensure_config_defaults(config)
    if changed:
        write_json(path, config)
    return config


def write_config(config, user_id=""):
    path = user_config_path(user_id) if user_id else DATA / "config.json"
    if not isinstance(config, dict):
        raise ValueError("配置格式错误。")
    ensure_config_defaults(config)
    write_json(path, config)
    invalidate_public_config_cache(user_id or None)


def read_user_template_config():
    if not USER_TEMPLATE_PATH.exists():
        write_json(USER_TEMPLATE_PATH, default_config())
    config = read_json(USER_TEMPLATE_PATH, default_config())
    if ensure_config_defaults(config):
        write_json(USER_TEMPLATE_PATH, config)
    return config


def write_user_template_config(config):
    if not isinstance(config, dict):
        raise ValueError("模板配置格式错误。")
    ensure_config_defaults(config)
    write_json(USER_TEMPLATE_PATH, config)


def reset_user_template_config():
    config = default_config()
    write_user_template_config(config)
    return read_user_template_config()


def copy_user_config_to_template(user_id):
    if not find_user_by_id(user_id):
        raise ValueError("用户不存在。")
    config = read_config(user_id)
    write_user_template_config(config)
    return read_user_template_config()


def should_sync_default_config(actor, user_id):
    if not actor or not is_super(actor):
        return False
    target = find_user_by_id(user_id)
    return bool(target and is_super(target))


def write_config_for_actor(config, user_id, actor):
    path = user_config_path(user_id)
    if path.exists():
        security_backup(f"config-{user_id}", [path])
    write_config(config, user_id)


def json_clone(value):
    return json.loads(json.dumps(value, ensure_ascii=False))


def exportable_config(config):
    cfg = json_clone(config if isinstance(config, dict) else {})
    cfg.pop("_sync", None)
    if not isinstance(cfg.get("app"), dict):
        cfg["app"] = {}
    if not isinstance(cfg.get("pages"), dict):
        cfg["pages"] = {}
    if not isinstance(cfg.get("toolbox_tabs"), list):
        cfg["toolbox_tabs"] = []
    if not isinstance(cfg.get("sidebar"), list):
        cfg["sidebar"] = []
    ensure_config_defaults(cfg)
    return cfg


def config_button_count(config):
    total = 0
    for page in (config.get("pages") or {}).values():
        if not isinstance(page, dict):
            continue
        for section in page.get("sections") or []:
            if isinstance(section, dict):
                total += len(section.get("buttons") or [])
    for tab in config.get("toolbox_tabs") or []:
        if not isinstance(tab, dict):
            continue
        for section in tab.get("sections") or []:
            if isinstance(section, dict):
                total += len(section.get("buttons") or [])
    return total


def config_summary(config):
    cfg = config if isinstance(config, dict) else {}
    return {
        "title": ((cfg.get("app") or {}).get("title") or "Toolbox"),
        "subtitle": ((cfg.get("app") or {}).get("subtitle") or ""),
        "pages": len(cfg.get("pages") or {}),
        "tabs": len(cfg.get("toolbox_tabs") or []),
        "buttons": config_button_count(cfg),
    }


def config_export_package(config, user=None, base_url=""):
    cfg = exportable_config(config)
    summary = config_summary(cfg)
    return {
        "format": "toolbox-config-export",
        "version": 1,
        "exportedAt": now_iso(),
        "title": summary["title"],
        "summary": summary,
        "source": {
            "userId": (user or {}).get("id", ""),
            "name": user_display_name(user or {}),
            "baseUrl": normalize_public_base_url(base_url) if base_url else "",
        },
        "config": cfg,
    }


def normalize_import_config(payload):
    if not isinstance(payload, dict):
        raise ValueError("导入内容必须是 JSON 对象。")
    config = payload.get("config") if isinstance(payload.get("config"), dict) else payload
    if not isinstance(config, dict):
        raise ValueError("导入配置格式错误。")
    if not any(key in config for key in ("app", "sidebar", "toolbox_tabs", "pages", "popup")):
        raise ValueError("没有识别到工具箱配置内容。")
    cfg = exportable_config(config)
    if "app" not in cfg or not isinstance(cfg.get("app"), dict):
        cfg["app"] = default_config()["app"]
    cfg.setdefault("sidebar", [])
    cfg.setdefault("toolbox_tabs", [])
    cfg.setdefault("pages", {})
    return cfg


def read_config_shares():
    data = read_json(CONFIG_SHARES_PATH, {"shares": {}})
    if not isinstance(data, dict):
        data = {"shares": {}}
    shares = data.get("shares")
    if not isinstance(shares, dict):
        data["shares"] = {}
    return data


def write_config_shares(data):
    if not isinstance(data, dict):
        data = {"shares": {}}
    data.setdefault("shares", {})
    write_json(CONFIG_SHARES_PATH, data)


def config_share_url(base_url, token):
    return f"{normalize_public_base_url(base_url).rstrip('/')}/api/public/config-share?token={quote(token)}"


def public_config_share(row, base_url="", include_config=True):
    config = exportable_config(row.get("config") or {})
    payload = {
        "format": "toolbox-config-export",
        "version": 1,
        "cloud": True,
        "shareToken": row.get("token", ""),
        "shareUrl": config_share_url(base_url, row.get("token", "")) if base_url and row.get("token") else "",
        "title": row.get("title") or config_summary(config)["title"],
        "createdAt": row.get("createdAt", ""),
        "source": {
            "userId": row.get("ownerUserId", ""),
            "name": row.get("ownerName", ""),
            "baseUrl": normalize_public_base_url(base_url) if base_url else row.get("baseUrl", ""),
        },
        "summary": config_summary(config),
    }
    if include_config:
        payload["config"] = config
    return payload


def create_config_share(config, user, base_url):
    token = random_hex(18)
    cfg = exportable_config(config)
    summary = config_summary(cfg)
    data = read_config_shares()
    data.setdefault("shares", {})[token] = {
        "token": token,
        "title": summary["title"],
        "ownerUserId": (user or {}).get("id", ""),
        "ownerName": user_display_name(user or {}),
        "baseUrl": normalize_public_base_url(base_url),
        "createdAt": now_iso(),
        "config": cfg,
    }
    write_config_shares(data)
    return public_config_share(data["shares"][token], base_url, include_config=False)


def read_config_share(token):
    token = (token or "").strip()
    if not token:
        raise ValueError("分享链接缺少 token。")
    row = (read_config_shares().get("shares") or {}).get(token)
    if not row:
        raise ValueError("分享链接不存在或已失效。")
    return row


def fetch_remote_config_payload(url):
    text = str(url or "").strip()
    parsed = urlparse(text)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ValueError("请填写 http 或 https 开头的云端链接。")
    req = urllib.request.Request(text, headers={"User-Agent": "ToolboxAdminConfigImporter/1.0", "Accept": "application/json"})
    limit = 3 * 1024 * 1024
    with urllib.request.urlopen(req, timeout=15) as resp:
        length = resp.headers.get("Content-Length")
        if length and int(length) > limit:
            raise ValueError("云端配置文件过大。")
        data = resp.read(limit + 1)
    if len(data) > limit:
        raise ValueError("云端配置文件过大。")
    try:
        return json.loads(data.decode("utf-8-sig"))
    except Exception as exc:
        raise ValueError(f"云端链接没有返回有效 JSON：{exc}")


def public_toolbox_config(user_id):
    cfg = read_config(user_id)
    app = cfg.setdefault("app", {})
    app.pop("password_plain", None)
    for lock in (cfg.get("page_locks") or {}).values():
        if isinstance(lock, dict): lock.pop("password_plain", None)
    for group in (cfg.get("page_lock_groups") or {}).values():
        if isinstance(group, dict): group.pop("password_plain", None)
    if app.get("password_enabled") is False:
        app["password"] = ""
    normalize_client_config(cfg, user_id=user_id)
    path = user_config_path(user_id)
    meta = dict(cfg.get("_sync") or {})
    meta["userId"] = user_id
    meta["updatedAt"] = int(path.stat().st_mtime) if path.exists() else int(time.time())
    cfg["_sync"] = meta
    return cfg


def file_signature(path):
    try:
        stat = path.stat()
        return stat.st_mtime_ns, stat.st_size
    except OSError:
        return None


def public_toolbox_config_payload(user_id):
    path = user_config_path(user_id)
    signature = (
        file_signature(path),
        file_signature(USERS_PATH),
        file_signature(SYSTEM_PATH),
    )
    with PUBLIC_CONFIG_CACHE_LOCK:
        cached = PUBLIC_CONFIG_CACHE.get(user_id)
        if cached and cached["signature"] == signature:
            return cached["data"], cached["gzip"], cached["etag"]

    payload = public_toolbox_config(user_id)
    data = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    compressed = gzip.compress(data, compresslevel=5)
    etag = '"' + hashlib.sha256(data).hexdigest() + '"'
    final_signature = (
        file_signature(path),
        file_signature(USERS_PATH),
        file_signature(SYSTEM_PATH),
    )
    with PUBLIC_CONFIG_CACHE_LOCK:
        PUBLIC_CONFIG_CACHE[user_id] = {
            "signature": final_signature,
            "data": data,
            "gzip": compressed,
            "etag": etag,
        }
    return data, compressed, etag


def invalidate_public_config_cache(user_id=None):
    with PUBLIC_CONFIG_CACHE_LOCK:
        if user_id:
            PUBLIC_CONFIG_CACHE.pop(user_id, None)
        else:
            PUBLIC_CONFIG_CACHE.clear()


GLOBAL_BUILTIN_PREFIX = "builtin:"


def builtin_function_rows(include_urls=False):
    rows = []
    configured = {
        str(item.get("id")): item
        for item in read_system_settings().get("builtinFunctions") or []
        if isinstance(item, dict) and item.get("id")
    }
    for function_id, label in SCRIPT_LABELS.items():
        item = configured.pop(function_id, {})
        row = {"id": function_id, "name": str(item.get("name") or label),
               "enabled": item.get("enabled", True) is not False, "builtIn": True,
               "action": str(item.get("action") or "script")}
        if not include_urls and not row["enabled"]:
            continue
        if include_urls:
            row["target"] = str(item.get("target") or item.get("downloadUrl") or "")
            row["downloadUrl"] = row["target"] if row["action"] == "download" else ""
            if row["action"] == "download":
                row["backup_url"] = get_backup_url(item)
                row["backup_page_url"] = get_backup_url(item, True)
        rows.append(row)
    for function_id, item in configured.items():
        if item.get("enabled", True) is False:
            continue
        row = {"id": function_id, "name": str(item.get("name") or "未命名功能"), "enabled": True,
               "builtIn": False, "action": str(item.get("action") or "download")}
        if include_urls:
            row["target"] = str(item.get("target") or item.get("downloadUrl") or "")
            row["downloadUrl"] = row["target"] if row["action"] == "download" else ""
            if row["action"] == "download":
                row["backup_url"] = get_backup_url(item)
                row["backup_page_url"] = get_backup_url(item, True)
        rows.append(row)
    return rows


def find_builtin_function(function_id):
    return next((item for item in builtin_function_rows(True) if item.get("id") == function_id), None)


def proxy_builtin_download(handler):
    api_key = (handler.query.get("key", [""])[0] or handler.headers.get("X-Client-Api-Key", "")).strip()
    if not find_user_by_api_key(api_key):
        return handler.send_json({"error": "工具箱对接密钥无效或账号已停用。"}, 403)
    item = find_builtin_function((handler.query.get("id", [""])[0] or "").strip())
    if not item:
        return handler.send_json({"error": "内置功能不存在或已停用。"}, 404)
    headers = {"User-Agent": "ToolboxClient/1.0"}
    if handler.headers.get("Range"):
        headers["Range"] = handler.headers.get("Range")
    urls = [item.get("target") or item.get("downloadUrl")]
    backup_url = get_backup_url(item)
    if backup_url and backup_url not in urls:
        urls.append(backup_url)
    upstream = None
    for target_url in urls:
        request = urllib.request.Request(target_url, headers=headers)
        try:
            upstream = urllib.request.urlopen(request, timeout=60)
        except urllib.error.HTTPError as exc:
            upstream = exc
        except Exception:
            upstream = None
        if upstream is not None:
            status = getattr(upstream, "status", None) or upstream.getcode()
            if status < 400:
                break
            upstream.close()
            upstream = None
    if upstream is None:
        return handler.send_json({"error": "下载源暂时不可用。"}, 502)
    status = getattr(upstream, "status", None) or upstream.getcode()
    if status >= 400:
        upstream.close()
        return handler.send_json({"error": "下载源暂时不可用。"}, 502)
    handler.send_response(status)
    for header in ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges", "Content-Disposition", "ETag", "Last-Modified"):
        value = upstream.headers.get(header)
        if value:
            handler.send_header(header, value)
    if not upstream.headers.get("Content-Type"):
        handler.send_header("Content-Type", "application/octet-stream")
    handler.send_header("Cache-Control", "private, no-store")
    handler.end_headers()
    if handler.command.upper() != "HEAD":
        shutil.copyfileobj(upstream, handler.wfile, length=1024 * 256)
    upstream.close()


def normalize_client_config(cfg, user_id=""):
    def visible_buttons(buttons):
        return [button for button in buttons or [] if (button or {}).get("enabled", True) is not False]

    def normalize_button(button):
        if not isinstance(button, dict):
            return
        action = button.get("action", "link")
        target = get_target(button)
        if action == "download":
            files = normalize_download_files(button.get("files"))
            if files:
                button["files"] = files
                button["download_mode"] = "multiple" if len(files) > 1 or button.get("download_mode") == "multiple" else "single"
                if not get_backup_url(button) and get_backup_url(files[0]): button["backup_url"] = get_backup_url(files[0])
                if not get_backup_url(button, True) and get_backup_url(files[0], True): button["backup_page_url"] = get_backup_url(files[0], True)
            button["download_url"] = target
            if get_backup_url(button): button["backup_url"] = get_backup_url(button)
            if get_backup_url(button, True): button["backup_page_url"] = get_backup_url(button, True)
            download_directory = str(button.get("download_directory") or button.get("download_path") or "").strip()[:1000]
            if download_directory:
                button["download_directory"] = download_directory
                button["download_delete_on_exit"] = button.get("download_delete_on_exit") is True
            else:
                button.pop("download_directory", None)
                button.pop("download_path", None)
                button.pop("download_delete_on_exit", None)
            button.setdefault("url", target)
            button.setdefault("target", target)
        elif action == "script":
            if str(target).startswith(GLOBAL_BUILTIN_PREFIX) or str(target) in SCRIPT_LABELS:
                function_id = str(target)[len(GLOBAL_BUILTIN_PREFIX):] if str(target).startswith(GLOBAL_BUILTIN_PREFIX) else str(target)
                item = find_builtin_function(function_id)
                if item and item.get("action") == "download" and (item.get("target") or item.get("downloadUrl")):
                    user = find_user_by_id(user_id) if user_id else None
                    api_key = (user or {}).get("apiKey") or ""
                    button["action"] = "download"
                    button["download_url"] = "/api/toolbox/builtin-download?id=" + quote(function_id) + "&key=" + quote(api_key)
                    button["url"] = button["download_url"]
                    button["target"] = button["download_url"]
                    if get_backup_url(item, True): button["backup_page_url"] = get_backup_url(item, True)
                    button["name"] = button.get("name") or item.get("name")
                    return
                if item and item.get("action") not in ("", "script") and item.get("target"):
                    global_action = item.get("action")
                    global_target = item.get("target")
                    button["action"] = global_action
                    button["target"] = global_target
                    if global_action == "link": button["url"] = global_target
                    elif global_action == "cmd": button["command"] = global_target
                    elif global_action == "winget": button["package_id"] = global_target
                    return
            button["script_id"] = target
            button.setdefault("script", target)
            if target not in SCRIPT_LABELS:
                button["custom_script"] = target
            button.setdefault("target", target)
        elif action == "cmd":
            button["command"] = target
            button.setdefault("target", target)
        elif action == "winget":
            button["package_id"] = target
            button.setdefault("winget", target)
            button.setdefault("package", target)
            button.setdefault("target", target)
        else:
            button["url"] = target
            button.setdefault("target", target)

    def normalize_sections(sections):
        for section in sections or []:
            if isinstance(section, dict):
                section["buttons"] = visible_buttons(section.get("buttons") or [])
            for button in (section or {}).get("buttons") or []:
                normalize_button(button)

    for page in (cfg.get("pages") or {}).values():
        normalize_sections((page or {}).get("sections") or [])
    for tab in cfg.get("toolbox_tabs") or []:
        normalize_sections((tab or {}).get("sections") or [])


def inject_update_entry(cfg):
    # 更新由客户端启动时的版本弹窗处理，不再向侧栏注入独立更新页面。
    return


def public_brand_config():
    app = read_config("").get("app", {})
    return {
        "title": app.get("admin_title") or DEFAULT_ADMIN_TITLE,
        "hint": app.get("login_hint") or DEFAULT_LOGIN_HINT,
        "icon": app.get("icon") or DEFAULT_APP_ICON,
        "logoText": app.get("logo_text") or "Y",
    }


def sync_public_brand_config(app_patch):
    keys = ("admin_title", "login_hint", "icon", "icon_url", "logo_text")
    if not any(key in app_patch for key in keys):
        return
    cfg = read_config("")
    app = cfg.setdefault("app", {})
    for key in keys:
        if key in app_patch:
            app[key] = app_patch[key]
    write_config(cfg, "")


def apply_app_patch(config, patch):
    app = config.setdefault("app", {})
    for key, value in patch.items():
        if key == "password_enabled" and not value:
            app["password_enabled"] = False
        elif key == "password_enabled":
            app["password_enabled"] = True
        elif key == "password":
            plain = str(value or "")
            app["password"] = stored_password(plain) if plain else ""
            app["password_plain"] = plain
        elif key == "default_view_mode":
            app[key] = normalize_view_mode(value, "grid")
        elif key == "button_content_layout":
            app[key] = normalize_button_content_layout(value)
        elif key == "button_content_layout_rules" and isinstance(value, dict):
            app[key] = value
        else:
            app[key] = value
    ensure_config_defaults(config)
    return config


def read_users():
    DATA.mkdir(parents=True, exist_ok=True)
    USER_DATA.mkdir(parents=True, exist_ok=True)
    store = read_json(USERS_PATH, {"users": [], "inviteCodes": []})
    store.setdefault("users", [])
    store.setdefault("inviteCodes", [])
    store.setdefault("settings", {})
    changed = False
    for user in store["users"]:
        if (user.get("id") == "admin" and check_password("dev-token", user.get("passwordHash", ""))
                and len(ADMIN_TOKEN) >= 12 and ADMIN_TOKEN.lower() != "dev-token"):
            user["passwordHash"] = stored_password(ADMIN_TOKEN)
            changed = True
            audit_event("default_admin_password_migrated", actor=user)
        if user.get("role") == "agent":
            user["role"] = "user"
            changed = True
        for key in ("parentAgentId", "parentAgentName", "balance"):
            if key in user:
                user.pop(key, None)
                changed = True
    for invite in store["inviteCodes"]:
        for key in ("ownerAgentId", "ownerAgentName", "boundAgentId", "boundAgentName", "isAgentInvite", "price", "chargedAmount"):
            if key in invite:
                invite.pop(key, None)
                changed = True
        if invite.get("registerRole") == "agent":
            invite["registerRole"] = "user"
            changed = True
    cleanup_invites(store)
    if not store["users"]:
        if len(ADMIN_TOKEN) < 12 or ADMIN_TOKEN.lower() in ("dev-token", "password", "admin"):
            raise RuntimeError("首次启动必须通过 TOOLBOX_ADMIN_TOKEN 设置至少 12 位的管理员密码。")
        admin = {
            "id": "admin",
            "username": "admin",
            "displayName": "总管理员",
            "role": "super",
            "active": True,
            "canViewJson": True,
            "passwordHash": stored_password(ADMIN_TOKEN),
            "apiKey": random_hex(20),
            "createdAt": now_iso(),
        }
        store["users"] = [admin]
        write_json(USERS_PATH, store)
        write_config(read_config(""), "admin")
    elif changed:
        write_json(USERS_PATH, store)
    return store


def write_users(store):
    store.setdefault("users", [])
    store.setdefault("inviteCodes", [])
    store.setdefault("settings", {})
    cleanup_invites(store)
    write_json(USERS_PATH, store)
    with API_KEY_CACHE_LOCK:
        API_KEY_CACHE["signature"] = None
        API_KEY_CACHE["users"] = {}
    invalidate_public_config_cache()


def is_super(user):
    return user.get("role") == "super"


def is_agent(user):
    return False


def can_manage_users(user):
    return is_super(user)


def role_label(role):
    return {"super": "总管理员", "user": "普通用户"}.get(role, "普通用户")


def is_login_api_path(path):
    normalized = "/" + str(path or "").strip("/").lower()
    return normalized in ("/api/login", "/desktop/login") or normalized.endswith("/api/login") or normalized.endswith("/desktop/login")


def handle_desktop_login(handler):
    body = handler.read_body()
    username = (body.get("username") or "").strip()
    key = f"{client_ip(handler)}:{username.lower()}"
    now = time.time()
    attempts = [stamp for stamp in LOGIN_ATTEMPTS.get(key, []) if now - stamp < LOGIN_WINDOW_SECONDS]
    if len(attempts) >= LOGIN_MAX_FAILURES:
        audit_event("login_blocked", target=username, handler=handler, success=False)
        return handler.send_json({"error": "登录尝试过多，请 15 分钟后重试。"}, 429)
    user = find_user_by_username(username)
    if not user or user.get("active", True) is False or not check_password(str(body.get("password") or ""), user.get("passwordHash", "")):
        attempts.append(now)
        LOGIN_ATTEMPTS[key] = attempts
        audit_event("login_failed", target=username, handler=handler, success=False)
        return handler.send_json({"error": "用户名或密码错误。"}, 401)
    LOGIN_ATTEMPTS.pop(key, None)
    token = random_hex(32)
    user = mark_user_login(user["id"], handler)
    SESSIONS[token] = {"userId": user["id"], "createdAt": now_iso(), "lastSeenAt": now_iso()}
    save_sessions()
    audit_event("login_success", actor=user, handler=handler)
    return handler.send_json({"token": token, "user": public_user(user)})


def default_system_settings():
    return {
        "builtinFunctions": [],
        "menuIconFolders": [{"id": "default", "name": "默认", "sort": 0}],
        "menuIcons": [],
        "locations": {
            "noticeAreaTitle": "全部未读",
            "adminSystemName": "系统管理",
            "frontendActiveGlow": True,
            "frontendShowGroupCount": True,
        },
        "agent": {
            "invitePrice": 0,
            "currency": "CNY",
            "allowNegativeBalance": False,
            "orderCooldownMinutes": 30,
        },
        "pay": {
            "wechatChannel": "disabled",
            "alipayChannel": "disabled",
            "wechatOrder": 10,
            "alipayOrder": 20,
            "easypay": {"enabled": False, "name": "", "apiUrl": "", "pid": "", "key": "", "notifyUrl": "", "returnUrl": "", "pcScan": False},
            "easypay2": {"enabled": False, "name": "", "apiUrl": "", "pid": "", "key": "", "notifyUrl": "", "returnUrl": "", "pcScan": False},
            "alipayOfficial": {"enabled": False, "appId": "", "privateKey": "", "publicKey": "", "gateway": "", "notifyUrl": "", "returnUrl": ""},
            "wechatOfficial": {"enabled": False, "mchId": "", "appId": "", "apiV3Key": "", "serialNo": "", "privateKey": "", "notifyUrl": ""},
        },
        "clientBuild": {
            "cacheRetentionHours": 24,
            "jobRetentionHours": 24,
            "cleanupIntervalMinutes": 360,
            "maxCacheEntries": 30,
        },
        "clientVariants": {
            variant_id: {
                "name": variant.get("label", ""),
                "badge": "",
                "description": variant.get("description", ""),
                "coverMode": "default",
                "coverUrl": "",
            }
            for variant_id, variant in CLIENT_VARIANTS.items()
        },
        "menuIcons": [],
        "menuIconLibraryUrl": "",
        "menuIconLibraryToken": "",
        "menuIconLibraryUsername": "",
        "menuIconLibraryPassword": "",
        "ipLocation": {"mode": "consensus", "threshold": 2, "providers": ["amap", "tencent", "ip-api", "ipapi-co", "pconline"], "unifiedChinese": True,
            "amapKey": "", "amapSecret": "", "baiduKey": "", "tencentKey": "", "tencentSecret": ""},
        "integrity": {
            "enabled": True,
            "secret": "",
            "tokenTtlMinutes": 10080,
            "lockBuildAfterFirstIssue": False,
        },
    }


def http_url(value):
    text = str(value or "").strip()
    return text if text.lower().startswith(("http://", "https://")) else ""


def popup_image_url(value):
    text = str(value or "").strip()
    return text if text.lower().startswith(("http://", "https://")) else ""


def popup_abs_url(value, base_url):
    text = str(value or "").strip()
    if text.lower().startswith(("http://", "https://")):
        return text
    if text.startswith("/"):
        return base_url.rstrip("/") + text
    return text


def popup_int(value, fallback, minimum=0, maximum=9999):
    try:
        return max(minimum, min(maximum, int(value)))
    except Exception:
        return fallback


def normalize_popup_qr_items(items):
    rows = []
    if not isinstance(items, list):
        return rows
    for index, item in enumerate(items):
        if not isinstance(item, dict):
            continue
        row = {
            "title": str(item.get("title") or "").strip(),
            "description": str(item.get("description") or "").strip(),
            "image": popup_image_url(item.get("image")),
            "enabled": item.get("enabled", True) is not False,
            "sort": popup_int(item.get("sort"), index + 1, -999999, 999999),
            "buttonText": str(item.get("buttonText") or "").strip(),
            "buttonUrl": http_url(item.get("buttonUrl")),
        }
        rows.append(row)
    return rows


def normalize_popup_links(items):
    rows = []
    if not isinstance(items, list):
        return rows
    for index, item in enumerate(items):
        if not isinstance(item, dict):
            continue
        row = {
            "title": str(item.get("title") or item.get("name") or "").strip(),
            "description": str(item.get("description") or "").strip(),
            "url": http_url(item.get("url")),
            "buttonText": str(item.get("buttonText") or "打开链接").strip() or "打开链接",
            "enabled": item.get("enabled", True) is not False,
            "sort": popup_int(item.get("sort"), index + 1, -999999, 999999),
        }
        rows.append(row)
    return rows


def normalize_popup_settings(value):
    default = default_popup_settings()
    popup = value if isinstance(value, dict) else {}
    normalized = {
        "enabled": popup.get("enabled", default["enabled"]) is True,
        "clickCount": popup_int(popup.get("clickCount"), default["clickCount"], 1, 20),
        "title": str(popup.get("title") or default["title"]).strip() or default["title"],
        "thanksText": str(popup.get("thanksText") or default["thanksText"]).strip() or default["thanksText"],
        "cacheMinutes": popup_int(popup.get("cacheMinutes"), default["cacheMinutes"], 0, 1440),
        "contacts": normalize_popup_qr_items(popup.get("contacts")),
        "payments": normalize_popup_qr_items(popup.get("payments")),
        "links": normalize_popup_links(popup.get("links")),
    }
    return normalized


def public_popup_config(user_id, base_url):
    popup = normalize_popup_settings(read_config(user_id).get("popup") or {})
    def public_qr_rows(rows):
        result = []
        for row in sorted([x for x in rows if x.get("enabled")], key=lambda x: (x.get("sort", 0), x.get("title", ""))):
            result.append({
                "title": row.get("title") or "",
                "description": row.get("description") or "",
                "image": popup_abs_url(row.get("image") or "", base_url),
                "enabled": True,
                "sort": row.get("sort", 0),
                "buttonText": row.get("buttonText") or "",
                "buttonUrl": row.get("buttonUrl") or "",
            })
        return result

    links = []
    for row in sorted([x for x in popup.get("links", []) if x.get("enabled") and x.get("url")], key=lambda x: (x.get("sort", 0), x.get("title", ""))):
        links.append({
            "title": row.get("title") or "",
            "description": row.get("description") or "",
            "url": row.get("url") or "",
            "buttonText": row.get("buttonText") or "打开链接",
            "enabled": True,
            "sort": row.get("sort", 0),
        })
    cache_minutes = popup_int(popup.get("cacheMinutes"), 60, 0, 1440)
    return {
        "enabled": popup.get("enabled") is True,
        "clickCount": popup_int(popup.get("clickCount"), 3, 1, 20),
        "title": popup.get("title") or "联系我们 / 支持作者",
        "thanksText": popup.get("thanksText") or "",
        "cacheMinutes": cache_minutes,
        "cacheSeconds": cache_minutes * 60,
        "contacts": public_qr_rows(popup.get("contacts", [])),
        "payments": public_qr_rows(popup.get("payments", [])),
        "links": links,
    }


def read_system_settings():
    data = read_json(SYSTEM_PATH, default_system_settings())
    defaults = default_system_settings()
    changed = False
    for key, value in defaults.items():
        if isinstance(value, dict):
            if key not in data or not isinstance(data.get(key), dict):
                data[key] = {}
                changed = True
            for sub_key, sub_value in value.items():
                if isinstance(sub_value, dict):
                    if sub_key not in data[key] or not isinstance(data[key].get(sub_key), dict):
                        data[key][sub_key] = {}
                        changed = True
                    for item_key, item_value in sub_value.items():
                        if item_key not in data[key][sub_key]:
                            data[key][sub_key][item_key] = item_value
                            changed = True
                else:
                    if sub_key not in data[key]:
                        data[key][sub_key] = sub_value
                        changed = True
        else:
            if key not in data:
                data[key] = value
                changed = True
    pay = data.get("pay") or {}
    for selected_key in (pay.get("wechatChannel"), pay.get("alipayChannel")):
        if selected_key and selected_key != "disabled" and isinstance(pay.get(selected_key), dict):
            pay[selected_key].setdefault("enabled", True)
    if "popup" in data:
        data.pop("popup", None)
        changed = True
    integrity = data.setdefault("integrity", {})
    if len(str(integrity.get("secret") or "").strip()) < 32:
        integrity["secret"] = random_hex(24)
        changed = True
    if changed:
        write_json(SYSTEM_PATH, data)
    return data


def public_system_settings():
    data = read_system_settings()
    public = json.loads(json.dumps(data, ensure_ascii=False))
    public.pop("popup", None)
    public["builtinFunctions"] = builtin_function_rows(True)
    if isinstance(public.get("integrity"), dict):
        public["integrity"]["secret"] = ""
        public["integrity"]["secretConfigured"] = True
    return public


def cache_library_icon(source_url, token=""):
    digest = hashlib.sha256(source_url.encode("utf-8")).hexdigest()
    parsed = urlparse(source_url)
    suffix = Path(parsed.path).suffix.lower()
    if suffix not in (".png", ".jpg", ".jpeg", ".webp", ".gif", ".ico", ".bmp"):
        suffix = ".png"
    target = MENU_ICON_LIBRARY_DIR / (digest + suffix)
    if target.exists() and target.stat().st_size:
        return "/uploads/menu-icon-library/" + target.name
    headers = {"User-Agent": "ToolboxAdmin/1.0"}
    if token:
        headers["Authorization"] = "Bearer " + token
    request = urllib.request.Request(source_url, headers=headers)
    with urllib.request.urlopen(request, timeout=12) as response:
        raw = response.read(5 * 1024 * 1024 + 1)
        content_type = str(response.headers.get("Content-Type") or "").lower()
    if len(raw) > 5 * 1024 * 1024 or not raw or (content_type and "image/" not in content_type):
        raise ValueError("图标文件格式无效或超过 5MB")
    MENU_ICON_LIBRARY_DIR.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(target.name + "." + secrets.token_hex(4) + ".tmp")
    temporary.write_bytes(raw)
    os.replace(str(temporary), str(target))
    return "/uploads/menu-icon-library/" + target.name


def openlist_icon_sources(library_url, token):
    parsed = urlparse(library_url)
    path = unquote(parsed.path or "/")
    if path.startswith("/d/"):
        path = path[2:]
    elif path == "/d":
        path = "/"
    api_url = parsed.scheme + "://" + parsed.netloc + "/api/fs/list"
    body = json.dumps({"path": path, "password": "", "page": 1, "per_page": 500, "refresh": False}).encode("utf-8")
    headers = {"Content-Type": "application/json", "User-Agent": "ToolboxAdmin/1.0"}
    if token:
        headers["Authorization"] = "Bearer " + token
    request = urllib.request.Request(api_url, data=body, headers=headers, method="POST")
    with urllib.request.urlopen(request, timeout=12) as response:
        payload = json.loads(response.read(2 * 1024 * 1024).decode("utf-8-sig"))
    if int(payload.get("code") or 0) != 200:
        message = str(payload.get("message") or "目录接口拒绝访问")
        if "guest user is disabled" in message.lower():
            message = "目录禁止游客访问，请填写图标库登录账号和密码或访问令牌"
        raise ValueError(message)
    content = ((payload.get("data") or {}).get("content") or [])
    rows = []
    image_suffixes = (".png", ".jpg", ".jpeg", ".webp", ".gif", ".ico", ".bmp")
    for item in content:
        name = str(item.get("name") or "").strip()
        if item.get("is_dir") or not name.lower().endswith(image_suffixes):
            continue
        raw_url = str(item.get("raw_url") or "").strip()
        if not raw_url:
            raw_url = parsed.scheme + "://" + parsed.netloc + "/d" + quote(path.rstrip("/") + "/" + name, safe="/")
        rows.append({"name": Path(name).stem, "url": raw_url})
    return rows


def openlist_login(library_url, username, password):
    parsed = urlparse(library_url)
    api_url = parsed.scheme + "://" + parsed.netloc + "/api/auth/login"
    body = json.dumps({"username": username, "password": password, "otp_code": ""}).encode("utf-8")
    request = urllib.request.Request(api_url, data=body, headers={"Content-Type": "application/json", "User-Agent": "ToolboxAdmin/1.0"}, method="POST")
    with urllib.request.urlopen(request, timeout=12) as response:
        payload = json.loads(response.read(1024 * 1024).decode("utf-8-sig"))
    if int(payload.get("code") or 0) != 200:
        raise ValueError(payload.get("message") or "图标库账号或密码错误")
    token = str((payload.get("data") or {}).get("token") or "").strip()
    if not token:
        raise ValueError("图标库登录成功但未返回访问令牌")
    return token


def cached_openlist_token(library_url, username, password, force=False):
    parsed = urlparse(library_url)
    key = (parsed.scheme.lower(), parsed.netloc.lower(), str(username))
    with MENU_ICON_LIBRARY_LOGIN_LOCK:
        cached = MENU_ICON_LIBRARY_TOKEN_CACHE.get(key) or {}
        if not force and cached.get("token") and time.time() - float(cached.get("created") or 0) < 1800:
            return cached["token"]
        token = openlist_login(library_url, username, password)
        MENU_ICON_LIBRARY_TOKEN_CACHE[key] = {"token": token, "created": time.time()}
        return token


def read_remote_menu_icons(library_url, token="", username="", password=""):
    library_url = str(library_url or "").strip()
    if not library_url:
        return [], ""
    try:
        token = str(token or "").strip()
        account_login = not token and bool(username and password)
        if account_login:
            token = cached_openlist_token(library_url, str(username), str(password))
        headers = {
            "Accept": "application/json, text/plain;q=0.9, */*;q=0.1",
            "User-Agent": "ToolboxAdmin/1.0",
        }
        if token:
            headers["Authorization"] = "Bearer " + token
        request = urllib.request.Request(library_url, headers=headers)
        with urllib.request.urlopen(request, timeout=8) as response:
            raw = response.read(1024 * 1024 + 1)
            final_url = response.geturl()
            content_type = str(response.headers.get("Content-Type") or "").lower()
        if len(raw) > 1024 * 1024:
            raise ValueError("图标库清单不能超过 1MB")
        text = raw.decode("utf-8-sig", errors="replace").strip()
        sources = None
        if "text/html" in content_type or text[:100].lower().startswith(("<!doctype html", "<html")):
            try:
                sources = openlist_icon_sources(library_url, token)
            except ValueError as exc:
                if account_login and "token is invalidated" in str(exc).lower():
                    token = cached_openlist_token(library_url, str(username), str(password), force=True)
                    sources = openlist_icon_sources(library_url, token)
                else:
                    raise
        try:
            payload = json.loads(text)
            if isinstance(payload, dict):
                payload = payload.get("icons", payload.get("files", []))
            if isinstance(payload, list):
                sources = payload
        except json.JSONDecodeError:
            pass
        if sources is None:
            if "<html" in text[:500].lower() or "<!doctype" in text[:100].lower():
                raise ValueError("该地址是网页而不是图标清单，请填写访问令牌后重试")
            sources = []
            for line in text.splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "|" in line:
                    name, icon_url = line.split("|", 1)
                    sources.append({"name": name.strip(), "url": icon_url.strip()})
                else:
                    sources.append(line)

        icons = []
        used = set()
        candidates = []
        for source in sources[:500]:
            if isinstance(source, str):
                icon_url = source.strip()
                name = Path(urlparse(icon_url).path).stem
            elif isinstance(source, dict):
                icon_url = str(source.get("url") or source.get("downloadUrl") or source.get("link") or "").strip()
                name = str(source.get("name") or source.get("title") or "").strip()
            else:
                continue
            icon_url = urljoin(final_url, icon_url)
            if not http_url(icon_url) or icon_url in used:
                continue
            used.add(icon_url)
            candidates.append((icon_url, (name or Path(urlparse(icon_url).path).stem or "图标")[:80]))
        if not candidates:
            directory = unquote(urlparse(library_url).path or "/")
            raise ValueError("目录读取成功，但未发现图片文件，当前目录：" + directory)

        def build_icon(candidate):
            icon_url, icon_name = candidate
            cached_url = cache_library_icon(icon_url, token)
            return {
                "id": "library_" + hashlib.sha256(icon_url.encode("utf-8")).hexdigest()[:16],
                "name": icon_name,
                "url": cached_url,
                "library": True,
            }

        failures = []
        with ThreadPoolExecutor(max_workers=min(12, len(candidates))) as executor:
            futures = {executor.submit(build_icon, candidate): candidate for candidate in candidates}
            for future in as_completed(futures):
                try:
                    icons.append(future.result())
                except Exception as exc:
                    failures.append(str(exc))
        icons.sort(key=lambda item: item.get("name", "").lower())
        if not icons:
            raise ValueError("目录中发现图片，但缓存全部失败：" + (failures[0] if failures else "未知错误"))
        return icons, ""
    except Exception as exc:
        return [], "图标库读取失败：" + str(exc)[:160]


def write_system_settings(body):
    current = read_system_settings()
    if isinstance(body.get("menuIconFolders"), list):
        folders = []
        used = set()
        for index, source in enumerate(body.get("menuIconFolders")[:100]):
            if not isinstance(source, dict):
                continue
            folder_id = re.sub(r"[^a-zA-Z0-9_-]", "", str(source.get("id") or "")) or new_id("folder")
            name = str(source.get("name") or "").strip()[:80]
            if not name or folder_id in used:
                continue
            used.add(folder_id)
            try:
                sort = max(-999999, min(999999, int(source.get("sort", index))))
            except (TypeError, ValueError):
                sort = index
            folders.append({"id": folder_id, "name": name, "sort": sort})
        if not any(item["id"] == "default" for item in folders):
            folders.insert(0, {"id": "default", "name": "默认", "sort": -999999})
        current["menuIconFolders"] = folders
    if "menuIconLibraryUrl" in body:
        library_url = str(body.get("menuIconLibraryUrl") or "").strip()[:1000]
        if library_url and not http_url(library_url):
            raise ValueError("图标库清单地址必须是 HTTP/HTTPS 地址。")
        current["menuIconLibraryUrl"] = library_url
    if "menuIconLibraryToken" in body:
        current["menuIconLibraryToken"] = str(body.get("menuIconLibraryToken") or "").strip()[:4000]
    if "menuIconLibraryUsername" in body:
        current["menuIconLibraryUsername"] = str(body.get("menuIconLibraryUsername") or "").strip()[:200]
    if "menuIconLibraryPassword" in body:
        current["menuIconLibraryPassword"] = str(body.get("menuIconLibraryPassword") or "")[:500]
    if isinstance(body.get("menuIcons"), list):
        current["menuIconLibraryUrl"] = ""
        current["menuIconLibraryToken"] = ""
        current["menuIconLibraryUsername"] = ""
        current["menuIconLibraryPassword"] = ""
        rows = []
        used = set()
        for source in body.get("menuIcons")[:500]:
            if not isinstance(source, dict):
                continue
            icon_id = re.sub(r"[^a-zA-Z0-9_-]", "", str(source.get("id") or "")) or new_id("icon")
            name = str(source.get("name") or "").strip()[:80]
            url = str(source.get("url") or "").strip()[:1000]
            valid_url = http_url(url) or (url if url.startswith("/uploads/menu-icons/") else "")
            if not name or not valid_url or icon_id in used:
                continue
            used.add(icon_id)
            folder_id = re.sub(r"[^a-zA-Z0-9_-]", "", str(source.get("folderId") or "default")) or "default"
            try:
                sort = max(-999999, min(999999, int(source.get("sort", 0))))
            except (TypeError, ValueError):
                sort = 0
            rows.append({"id": icon_id, "name": name, "url": valid_url, "folderId": folder_id, "sort": sort})
        current["menuIcons"] = rows
    if isinstance(body.get("builtinFunctions"), list):
        rows = []
        used = set()
        for source in body.get("builtinFunctions"):
            if not isinstance(source, dict):
                continue
            function_id = re.sub(r"[^a-zA-Z0-9_-]", "", str(source.get("id") or "")) or new_id("builtin")
            if function_id in used:
                raise ValueError("内置功能 ID 不能重复。")
            name = str(source.get("name") or "").strip()
            action = str(source.get("action") or ("script" if function_id in SCRIPT_LABELS else "download"))
            if action not in ("link", "download", "cmd", "script", "winget"):
                raise ValueError("不支持的内置功能动作。")
            target = str(source.get("target") or source.get("downloadUrl") or "").strip()
            if action in ("link", "download") and target and not http_url(target):
                raise ValueError("网页和下载动作必须填写 HTTP/HTTPS 地址。")
            if not name:
                raise ValueError("内置功能名称不能为空。")
            if action != "script" and not target:
                raise ValueError("内置功能的目标内容不能为空。")
            if action == "script" and function_id not in SCRIPT_LABELS and not target:
                raise ValueError("自定义内置功能请选择或填写要执行的内置功能。")
            used.add(function_id)
            row = {"id": function_id, "name": name, "action": action, "target": target,
                   "downloadUrl": target if action == "download" else "",
                   "enabled": source.get("enabled", True) is not False}
            if action == "download":
                if get_backup_url(source): row["backup_url"] = get_backup_url(source)
                if get_backup_url(source, True): row["backup_page_url"] = get_backup_url(source, True)
            rows.append(row)
        current["builtinFunctions"] = rows
    for section in ("locations", "pay", "integrity", "clientBuild", "clientVariants", "ipLocation"):
        patch = body.get(section)
        if not isinstance(patch, dict):
            continue
        if section == "integrity":
            current.setdefault("integrity", {})
            if "enabled" in patch:
                current["integrity"]["enabled"] = patch.get("enabled") is not False
            if "tokenTtlMinutes" in patch:
                try:
                    current["integrity"]["tokenTtlMinutes"] = max(5, min(43200, int(patch.get("tokenTtlMinutes") or 10080)))
                except Exception:
                    current["integrity"]["tokenTtlMinutes"] = 10080
            if "lockBuildAfterFirstIssue" in patch:
                current["integrity"]["lockBuildAfterFirstIssue"] = patch.get("lockBuildAfterFirstIssue") is not False
            if patch.get("rotateSecret"):
                current["integrity"]["secret"] = random_hex(24)
            continue
        if section == "clientBuild":
            current.setdefault("clientBuild", {})
            if "cacheRetentionHours" in patch:
                try:
                    current["clientBuild"]["cacheRetentionHours"] = max(1, min(24 * 30, int(patch.get("cacheRetentionHours") or 24)))
                except Exception:
                    current["clientBuild"]["cacheRetentionHours"] = 24
            if "jobRetentionHours" in patch:
                try:
                    current["clientBuild"]["jobRetentionHours"] = max(1, min(24 * 30, int(patch.get("jobRetentionHours") or 24)))
                except Exception:
                    current["clientBuild"]["jobRetentionHours"] = 24
            if "cleanupIntervalMinutes" in patch:
                try:
                    current["clientBuild"]["cleanupIntervalMinutes"] = max(10, min(24 * 60, int(patch.get("cleanupIntervalMinutes") or 360)))
                except Exception:
                    current["clientBuild"]["cleanupIntervalMinutes"] = 360
            if "maxCacheEntries" in patch:
                try:
                    current["clientBuild"]["maxCacheEntries"] = max(1, min(200, int(patch.get("maxCacheEntries") or 30)))
                except Exception:
                    current["clientBuild"]["maxCacheEntries"] = 30
            continue
        if section == "clientVariants":
            variants = current.setdefault("clientVariants", {})
            for variant_id, values in patch.items():
                if variant_id not in CLIENT_VARIANTS or not isinstance(values, dict):
                    continue
                existing = variants.setdefault(variant_id, {})
                mode = str(values.get("coverMode") or existing.get("coverMode") or "default").strip()
                cover_url = str(values.get("coverUrl") or "").strip()
                if mode not in ("default", "upload", "url"):
                    mode = "default"
                if mode == "url" and not http_url(cover_url):
                    cover_url = ""
                if mode == "upload" and not cover_url.startswith("/uploads/variant-covers/"):
                    cover_url = ""
                variants[variant_id] = {
                    "name": str(values.get("name") or CLIENT_VARIANTS[variant_id].get("label") or "").strip()[:80],
                    "badge": str(values.get("badge") or "").strip()[:80],
                    "description": str(values.get("description") or "").strip()[:500],
                    "coverMode": mode,
                    "coverUrl": cover_url,
                }
            continue
        for key, value in patch.items():
            if isinstance(current.get(section, {}).get(key), dict) and isinstance(value, dict):
                current[section][key].update(value)
            else:
                current.setdefault(section, {})[key] = value
    pay = current.setdefault("pay", {})
    for selected_key in (pay.get("wechatChannel"), pay.get("alipayChannel")):
        if selected_key and selected_key != "disabled" and isinstance(pay.get(selected_key), dict):
            pay[selected_key].setdefault("enabled", True)
    write_json(SYSTEM_PATH, current)
    return public_system_settings()


def read_notices():
    data = read_json(NOTICES_PATH, {"notices": [], "reads": {}})
    data.setdefault("notices", [])
    data.setdefault("reads", {})
    return data


def write_notices(data):
    data.setdefault("notices", [])
    data.setdefault("reads", {})
    write_json(NOTICES_PATH, data)


def read_orders():
    data = read_json(ORDERS_PATH, {"orders": []})
    data.setdefault("orders", [])
    return data


def write_orders(data):
    data.setdefault("orders", [])
    write_json(ORDERS_PATH, data)


def public_order(order):
    user_id = order.get("userId") or order.get("agentId", "")
    username = order.get("username") or order.get("agentUsername", "")
    display_name = order.get("displayName") or order.get("agentDisplayName") or find_user_display_name(user_id, username)
    return {
        "id": order.get("id"),
        "status": order.get("status", "pending"),
        "action": order.get("action", ""),
        "amount": order.get("amount", 0),
        "currency": order.get("currency", "CNY"),
        "userId": user_id,
        "username": username,
        "displayName": display_name,
        "detail": localized_order_detail(order),
        "request": order.get("request") or {},
        "paymentMethod": order.get("paymentMethod", ""),
        "paymentChannel": order.get("paymentChannel", ""),
        "fulfilledAt": order.get("fulfilledAt", ""),
        "fulfilledInviteCodes": order.get("fulfilledInviteCodes") or [],
        "createdAt": order.get("createdAt", ""),
        "updatedAt": order.get("updatedAt", ""),
    }


def localized_order_detail(order):
    request = order.get("request") or {}
    if order.get("action") == "create_invites" and request:
        return order_detail_for_invites(request)
    detail = str(order.get("detail") or "")
    if detail.startswith("Create ") and "invite code" in detail:
        try:
            count = detail.split("Create ", 1)[1].split(" invite", 1)[0]
            max_uses = detail.split("maxUses=", 1)[1].split(",", 1)[0]
            retention_days = detail.split("retentionDays=", 1)[1].split(",", 1)[0]
            return f"生成 {count} 个邀请码，可用次数 {max_uses}，使用后保留 {retention_days} 天"
        except Exception:
            return "生成邀请码"
    return detail


def localized_notice_title(title):
    mapping = {
        "Agent order pending": "订单待处理",
        "Agent invite order fulfilled": "邀请码订单已通过",
        "Agent invite created": "邀请码已生成",
    }
    return mapping.get(title, title)


def localized_notice_content(content):
    text = str(content or "")
    if text.startswith("Agent ") and " created order " in text:
        try:
            username = text.split("Agent ", 1)[1].split(" created order ", 1)[0]
            rest = text.split(" created order ", 1)[1]
            order_id = rest.split(":", 1)[0]
            amount = rest.split("Amount:", 1)[1].strip().rstrip(".")
            return f"用户 {username} 提交了订单 {order_id}，金额：{amount}。"
        except Exception:
            return "用户提交了新订单。"
    if text.startswith("Super admin ") and " approved order " in text:
        try:
            approver = text.split("Super admin ", 1)[1].split(" approved order ", 1)[0]
            rest = text.split(" approved order ", 1)[1]
            order_id = rest.split(" for agent ", 1)[0]
            agent = rest.split(" for agent ", 1)[1].split(";", 1)[0]
            created = rest.split("created ", 1)[1].split(" invite", 1)[0]
            amount = rest.split("Amount:", 1)[1].strip().rstrip(".")
            return f"总管理员 {approver} 已通过用户 {agent} 的订单 {order_id}，生成 {created} 个邀请码，金额：{amount}。"
        except Exception:
            return "总管理员已通过订单并生成邀请码。"
    if text.startswith("Agent ") and " invite code(s). Amount: " in text:
        try:
            username = text.split("Agent ", 1)[1].split(" created ", 1)[0]
            count = text.split(" created ", 1)[1].split(" invite", 1)[0]
            amount = text.split("Amount:", 1)[1].strip().rstrip(".")
            return f"用户 {username} 已生成 {count} 个邀请码，金额：{amount}。"
        except Exception:
            return "已生成邀请码。"
    return text


def public_notice(notice, user_id=""):
    created_by = notice.get("createdBy", "")
    created_by_name = notice.get("createdByName") or ("系统" if created_by == "system" else find_user_display_name(notice.get("createdById", ""), created_by))
    return {
        "id": notice.get("id"),
        "title": localized_notice_title(notice.get("title", "")),
        "content": localized_notice_content(notice.get("content", "")),
        "level": notice.get("level", "info"),
        "createdAt": notice.get("createdAt", ""),
        "createdBy": created_by_name,
        "createdByUsername": "" if created_by == "system" else created_by,
        "createdById": notice.get("createdById", ""),
        "read": user_id in set(notice.get("readBy") or []),
        "refType": notice.get("refType", ""),
        "refId": notice.get("refId", ""),
    }


def notice_visible_to_user(notice, user):
    if notice.get("targetRole") == "super" and not is_super(user):
        return False
    return notice.get("active", True) is not False


def add_system_notice(title, content, level="info", target_role="", ref_type="", ref_id=""):
    data = read_notices()
    notice = {
        "id": new_id("notice"),
        "title": title,
        "content": content,
        "level": level,
        "targetRole": target_role,
        "active": True,
        "createdAt": now_iso(),
        "createdBy": "system",
        "createdById": "system",
        "readBy": [],
        "refType": ref_type,
        "refId": ref_id,
    }
    data["notices"].insert(0, notice)
    write_notices(data)
    return notice


def scoped_users(store, actor):
    users = store.get("users", [])
    if is_super(actor):
        return users
    return [actor]


def assert_user_scope(actor, target_id):
    if is_super(actor):
        return
    target = find_user_by_id(target_id)
    if not target:
        raise ValueError("用户不存在。")
    if target.get("id") == actor.get("id"):
        return
    raise PermissionError("没有权限管理这个用户。")


def cleanup_invites(store):
    try:
        keep = []
        now_ts = time.time()
        default_days = int((store.get("settings") or {}).get("inviteRetentionDays") or 7)
        for invite in store.get("inviteCodes", []):
            used = int(invite.get("usedCount") or 0)
            max_uses = int(invite.get("maxUses") or 1)
            days = int(invite.get("retentionDays") or default_days)
            if used > 0 and max_uses > 0 and used >= max_uses and days >= 0:
                used_at = ""
                if invite.get("usedBy"):
                    used_at = invite.get("usedBy", [{}])[-1].get("usedAt", "")
                try:
                    used_ts = time.mktime(time.strptime(used_at[:19], "%Y-%m-%dT%H:%M:%S"))
                except Exception:
                    used_ts = now_ts
                if now_ts - used_ts >= days * 86400:
                    continue
            keep.append(invite)
        store["inviteCodes"] = keep
    except Exception:
        return


def default_mail_settings():
    return {"host": "", "port": 465, "user": "", "password": "", "from": "", "secure": True}


def read_mail_settings():
    settings = read_json(MAIL_PATH, default_mail_settings())
    defaults = default_mail_settings()
    defaults.update(settings or {})
    return defaults


def public_mail_settings():
    settings = read_mail_settings()
    return {
        "host": settings.get("host", ""),
        "port": settings.get("port", 465),
        "user": settings.get("user", ""),
        "from": settings.get("from", ""),
        "secure": bool(settings.get("secure", True)),
        "hasPassword": bool(settings.get("password"))
    }


def write_mail_settings(body):
    current = read_mail_settings()
    current["host"] = (body.get("host") or "").strip()
    current["port"] = int(body.get("port") or 465)
    current["user"] = (body.get("user") or "").strip()
    current["from"] = (body.get("from") or current["user"]).strip()
    current["secure"] = bool(body.get("secure", True))
    if body.get("password"):
        current["password"] = body.get("password")
    elif body.get("clearPassword"):
        current["password"] = ""
    write_json(MAIL_PATH, current)
    return current


def public_user(user, store=None):
    if not user:
        return None
    data = {
        "id": user.get("id"),
        "username": user.get("username"),
        "email": user.get("email", ""),
        "displayName": user.get("displayName"),
        "role": user.get("role"),
        "roleLabel": role_label(user.get("role")),
        "active": user.get("active", True),
        "canViewJson": user.get("canViewJson", user.get("role") == "super"),
        "apiKey": user.get("apiKey"),
        "createdAt": user.get("createdAt", ""),
        "lastLoginAt": user.get("lastLoginAt", ""),
        "lastLoginIp": (user.get("loginIpHistory") or [{}])[0],
        "loginIpHistory": (user.get("loginIpHistory") or [])[:3],
    }
    return data


def find_user_by_id(user_id):
    return next((u for u in read_users()["users"] if u.get("id") == user_id), None)


def find_user_by_username(username):
    return next((u for u in read_users()["users"] if u.get("username") == username), None)


def mark_user_login(user_id, handler=None):
    store = read_users()
    login_at = now_iso()
    for row in store["users"]:
        if row.get("id") == user_id:
            row["lastLoginAt"] = login_at
            if handler:
                ip = client_ip(handler)
                history = [x for x in row.get("loginIpHistory", []) if isinstance(x, dict)]
                history.insert(0, {"ip": ip, "address": locate_ip(ip), "time": login_at})
                row["loginIpHistory"] = history[:3]
            write_users(store)
            return row
    return find_user_by_id(user_id)


def find_user_by_email(email):
    email = (email or "").strip().lower()
    if not email:
        return None
    return next((u for u in read_users()["users"] if (u.get("email") or "").strip().lower() == email), None)


def find_user_by_api_key(key):
    if not key:
        return None
    signature = file_signature(USERS_PATH)
    with API_KEY_CACHE_LOCK:
        if API_KEY_CACHE["signature"] != signature:
            users = read_users()["users"]
            API_KEY_CACHE["users"] = {
                user.get("apiKey"): dict(user)
                for user in users
                if user.get("apiKey") and user.get("active", True) is not False
            }
            API_KEY_CACHE["signature"] = file_signature(USERS_PATH)
        user = API_KEY_CACHE["users"].get(key)
        return dict(user) if user else None


def normalize_role(role):
    return role if role in ("super", "user") else "user"


def create_user(username, password, display_name="", role="user", template_user=None, email=""):
    username = (username or "").strip()
    email = (email or "").strip().lower()
    password = password or ""
    display_name = (display_name or username).strip() or username
    role = normalize_role(role)
    if not username or not password:
        raise ValueError("用户名和密码不能为空。")
    if len(password) < 10:
        raise ValueError("密码至少 10 位。")
    if find_user_by_username(username):
        raise ValueError("用户名已存在。")
    if email and find_user_by_email(email):
        raise ValueError("邮箱已存在。")
    base = safe_id(username)
    user_id = base
    while find_user_by_id(user_id):
        user_id = f"{base}-{int(time.time() * 1000)}"
    user = {
        "id": user_id,
        "username": username,
        "email": email,
        "displayName": display_name,
        "role": role,
        "active": True,
        "canViewJson": role == "super",
        "passwordHash": stored_password(password),
        "apiKey": random_hex(20),
        "createdAt": now_iso(),
    }
    store = read_users()
    store["users"].append(user)
    write_users(store)
    template_config = read_config(template_user["id"]) if template_user else read_user_template_config()
    write_config(template_config, user_id)
    return user


def smtp_ready():
    settings = read_mail_settings()
    return bool((settings.get("host") or os.environ.get("SMTP_HOST")) and
                (settings.get("user") or os.environ.get("SMTP_USER")) and
                (settings.get("password") or os.environ.get("SMTP_PASS")))


def send_reset_email(email, code):
    if not smtp_ready():
        return False
    msg = EmailMessage()
    settings = read_mail_settings()
    sender = settings.get("from") or settings.get("user") or os.environ.get("SMTP_FROM") or os.environ.get("SMTP_USER")
    msg["From"] = sender
    msg["To"] = email
    msg["Subject"] = "工具箱后台密码找回验证码"
    msg.set_content("你的密码找回验证码是：%s\n验证码 10 分钟内有效。" % code)
    host = settings.get("host") or os.environ.get("SMTP_HOST")
    port = int(settings.get("port") or os.environ.get("SMTP_PORT", "465"))
    user = settings.get("user") or os.environ.get("SMTP_USER")
    password = settings.get("password") or os.environ.get("SMTP_PASS")
    if settings.get("secure", True) or port == 465:
        with smtplib.SMTP_SSL(host, port, timeout=15) as smtp:
            smtp.login(user, password)
            smtp.send_message(msg)
    else:
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            smtp.starttls()
            smtp.login(user, password)
            smtp.send_message(msg)
    return True


def send_admin_event_email(subject, content):
    if not smtp_ready():
        return False
    store = read_users()
    recipients = [
        (u.get("email") or "").strip()
        for u in store.get("users", [])
        if is_super(u) and (u.get("email") or "").strip()
    ]
    if not recipients:
        return False
    settings = read_mail_settings()
    sender = settings.get("from") or settings.get("user") or os.environ.get("SMTP_FROM") or os.environ.get("SMTP_USER")
    host = settings.get("host") or os.environ.get("SMTP_HOST")
    port = int(settings.get("port") or os.environ.get("SMTP_PORT", "465"))
    user = settings.get("user") or os.environ.get("SMTP_USER")
    password = settings.get("password") or os.environ.get("SMTP_PASS")
    msg = EmailMessage()
    msg["From"] = sender
    msg["To"] = ", ".join(recipients)
    msg["Subject"] = subject
    msg.set_content(content)
    if settings.get("secure", True) or port == 465:
        with smtplib.SMTP_SSL(host, port, timeout=15) as smtp:
            smtp.login(user, password)
            smtp.send_message(msg)
    else:
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            smtp.starttls()
            smtp.login(user, password)
            smtp.send_message(msg)
    return True


def send_notice_mail_to_users(notice, users=None):
    if not smtp_ready():
        return False, "未配置邮箱服务器。"
    pool = users if users is not None else read_users().get("users", [])
    recipients = []
    for user in pool:
        email = (user.get("email") or "").strip()
        if email and email not in recipients:
            recipients.append(email)
    if not recipients:
        return False, "没有可接收邮箱的用户。"
    settings = read_mail_settings()
    sender = settings.get("from") or settings.get("user") or os.environ.get("SMTP_FROM") or os.environ.get("SMTP_USER")
    host = settings.get("host") or os.environ.get("SMTP_HOST")
    port = int(settings.get("port") or os.environ.get("SMTP_PORT", "465"))
    user = settings.get("user") or os.environ.get("SMTP_USER")
    password = settings.get("password") or os.environ.get("SMTP_PASS")
    msg = EmailMessage()
    msg["From"] = sender
    msg["To"] = ", ".join(recipients)
    msg["Subject"] = notice.get("title") or "通知"
    msg.set_content(notice.get("content") or "")
    if settings.get("secure", True) or port == 465:
        with smtplib.SMTP_SSL(host, port, timeout=15) as smtp:
            smtp.login(user, password)
            smtp.send_message(msg)
    else:
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            smtp.starttls()
            smtp.login(user, password)
            smtp.send_message(msg)
    return True, f"已推送到 {len(recipients)} 个邮箱。"


PAYMENT_CHANNEL_LABELS = {
    "easypay": "易支付一",
    "easypay2": "易支付二",
    "alipayOfficial": "支付宝官方",
    "wechatOfficial": "微信企业支付",
}


def configured_payment_channels(settings):
    pay = settings.get("pay") or {}
    channels = []
    for selected_key in (pay.get("wechatChannel"), pay.get("alipayChannel")):
        if not selected_key or selected_key == "disabled" or selected_key in channels:
            continue
        gateway = pay.get(selected_key) or {}
        if gateway.get("enabled") is not True:
            continue
        if selected_key in ("easypay", "easypay2"):
            ready = gateway.get("apiUrl") and gateway.get("pid") and gateway.get("key")
        elif selected_key == "alipayOfficial":
            ready = gateway.get("appId") and gateway.get("privateKey") and gateway.get("gateway")
        elif selected_key == "wechatOfficial":
            ready = gateway.get("mchId") and gateway.get("appId") and gateway.get("apiV3Key")
        else:
            ready = False
        if ready:
            channels.append(selected_key)
    return channels


def public_payment_channels(settings):
    return [{"key": key, "label": PAYMENT_CHANNEL_LABELS.get(key, key)} for key in configured_payment_channels(settings)]


def recent_pending_order(user_id, action, cooldown_minutes, data=None):
    if cooldown_minutes <= 0:
        return None
    try:
        cutoff = time.time() - cooldown_minutes * 60
        data = data or read_orders()
        for order in data.get("orders", []):
            order_user_id = order.get("userId") or order.get("agentId")
            if order_user_id != user_id or order.get("action") != action or order.get("status") != "pending":
                continue
            try:
                created = time.mktime(time.strptime((order.get("createdAt") or "")[:19], "%Y-%m-%dT%H:%M:%S"))
            except Exception:
                created = time.time()
            if created >= cutoff:
                return order
    except Exception:
        return None
    return None


def create_admin_order(user, action, amount, currency, detail, request=None, payment_method="", payment_channel=""):
    data = read_orders()
    existing = recent_pending_order(user.get("id"), action, 0, data)
    if existing:
        existing["amount"] = round(float(amount or 0), 2)
        existing["currency"] = currency or "CNY"
        existing["detail"] = detail
        existing["request"] = request or {}
        existing["paymentMethod"] = payment_method
        existing["paymentChannel"] = payment_channel
        existing["displayName"] = user_display_name(user)
        existing["updatedAt"] = now_iso()
        write_orders(data)
        return existing, False
    order = {
        "id": new_id("order"),
        "status": "pending",
        "action": action,
        "amount": round(float(amount or 0), 2),
        "currency": currency or "CNY",
        "userId": user.get("id"),
        "username": user.get("username"),
        "displayName": user_display_name(user),
        "detail": detail,
        "request": request or {},
        "paymentMethod": payment_method,
        "paymentChannel": payment_channel,
        "createdAt": now_iso(),
    }
    data["orders"].insert(0, order)
    write_orders(data)
    title = "订单待处理"
    content = f"用户 {user_display_name(user)} 提交了订单 {order['id']}：{detail}。金额：{order['amount']} {order['currency']}。"
    add_system_notice(title, content, "warn", "super")
    try:
        send_admin_event_email(title, content)
    except Exception:
        pass
    return order, True


def update_user_account(user_id, body, super_edit=False, actor=None):
    store = read_users()
    user = next((u for u in store["users"] if u.get("id") == user_id), None)
    if not user:
        raise ValueError("用户不存在。")
    username = (body.get("username") or user.get("username") or "").strip()
    email = (body.get("email") or user.get("email") or "").strip().lower()
    if not username:
        raise ValueError("用户名不能为空。")
    for other in store["users"]:
        if other.get("id") == user_id:
            continue
        if other.get("username") == username:
            raise ValueError("用户名已存在。")
        if email and (other.get("email") or "").strip().lower() == email:
            raise ValueError("邮箱已存在。")
    sensitive_change = bool(body.get("password")) or email != (user.get("email") or "").strip().lower()
    if sensitive_change:
        security_backup(f"account-{user_id}", [USERS_PATH, SESSIONS_PATH, user_config_path(user_id)])
    user["username"] = username
    user["email"] = email
    if "displayName" in body:
        user["displayName"] = (body.get("displayName") or username).strip() or username
    if super_edit and "role" in body:
        user["role"] = normalize_role(body.get("role"))
    if super_edit and "active" in body:
        user["active"] = bool(body.get("active"))
    if super_edit and "canViewJson" in body:
        user["canViewJson"] = bool(body.get("canViewJson")) or user.get("role") == "super"
    if body.get("password"):
        user["passwordHash"] = stored_password(body.get("password"))
    if super_edit and body.get("resetApiKey"):
        user["apiKey"] = random_hex(20)
    write_users(store)
    if sensitive_change:
        revoke_user_sessions(user_id)
    return user


def get_auth(handler):
    auth = handler.headers.get("Authorization", "")
    token = ""
    if auth.startswith("Bearer "):
        token = auth[7:]
    else:
        token = handler.query.get("token", [""])[0]
    session = SESSIONS.get(token)
    if session:
        try:
            last_seen = parse_iso_datetime(session.get("lastSeenAt") or session.get("createdAt") or "")
            if last_seen.tzinfo is None:
                last_seen = last_seen.replace(tzinfo=timezone.utc)
            expired = (datetime.now(timezone.utc) - last_seen).total_seconds() > SESSION_TTL_SECONDS
        except (TypeError, ValueError):
            expired = True
        if expired:
            SESSIONS.pop(token, None)
            save_sessions()
            return None
        user = find_user_by_id(session["userId"])
        if user and user.get("active", True) is not False:
            session["lastSeenAt"] = now_iso()
            return {"token": token, "user": user}
    return None


def target_user_id(auth, handler):
    target = handler.headers.get("X-Target-User") or handler.query.get("targetUserId", [""])[0]
    if auth["user"].get("role") == "super" and target:
        user = find_user_by_id(target)
        if not user:
            raise ValueError("目标用户不存在。")
        return user["id"]
    return auth["user"]["id"]


def invite_request_from_body(store, body):
    return {
        "prefix": clean_invite_prefix(body.get("prefix") or body.get("code") or "YQ"),
        "count": max(1, min(200, int(body.get("count") or 1))),
        "maxUses": max(1, int(body.get("maxUses") or 1)),
        "retentionDays": max(0, int(body.get("retentionDays") or (store.get("settings") or {}).get("inviteRetentionDays") or 7)),
    }


def invite_quote_for_actor(store, actor, body):
    request = normalize_invite_request_for_actor(store, actor, invite_request_from_body(store, body))
    return {
        "request": request,
        "price": 0,
        "total": 0,
        "currency": "CNY",
        "balance": 0,
        "balanceEnough": True,
        "allowNegativeBalance": False,
        "channels": [],
    }


def normalize_invite_request_for_actor(store, actor, request):
    normalized = dict(request or {})
    normalized["registerRole"] = "user"
    return normalized


def generate_invites_for_actor(store, actor, body, price=0, charged_amount=0):
    request = normalize_invite_request_for_actor(store, actor, invite_request_from_body(store, body))
    prefix = request["prefix"]
    count = request["count"]
    max_uses = request["maxUses"]
    retention_days = request["retentionDays"]
    existing = {x.get("code") for x in store["inviteCodes"]}
    created = []
    for _ in range(count):
        code = make_invite_code(prefix, existing)
        existing.add(code)
        invite = {"code": code, "active": True, "maxUses": max_uses,
                  "usedCount": 0, "usedBy": [], "retentionDays": retention_days,
                  "createdAt": now_iso(), "createdBy": actor.get("username"),
                  "createdById": actor.get("id"), "registerRole": "user"}
        created.append(invite)
    store["inviteCodes"][0:0] = created
    return created


def order_detail_for_invites(request):
    return f"生成 {request.get('count')} 个邀请码，可用次数 {request.get('maxUses')}，使用后保留 {request.get('retentionDays')} 天"


def create_invites_for_actor(store, actor, body):
    created = generate_invites_for_actor(store, actor, body, 0, 0)
    return {"invites": created, "created": True, "balance": 0}

def get_target(button):
    action = button.get("action", "link")
    if action == "download":
        return button.get("download_url") or button.get("url") or button.get("target") or ""
    if action == "cmd":
        return button.get("command") or button.get("target") or ""
    if action == "script":
        return normalize_script_target(button.get("script_id") or button.get("target") or "")
    if action == "winget":
        return button.get("package_id") or button.get("target") or ""
    return button.get("url") or button.get("target") or ""


def get_backup_url(button, page=False):
    if not isinstance(button, dict):
        return ""
    keys = ("backup_page_url", "backup_webpage", "fallback_page_url", "backupPageUrl") if page else ("backup_url", "backup_download_url", "fallback_url", "backupUrl")
    for key in keys:
        value = str(button.get(key) or "").strip()
        if value:
            return value
    return ""


def normalize_download_files(value):
    files = []
    if not isinstance(value, list):
        return files
    for raw in value[:50]:
        if not isinstance(raw, dict):
            continue
        url = str(raw.get("url") or raw.get("download_url") or "").strip()
        name = Path(str(raw.get("name") or raw.get("filename") or "").strip()).name
        if url:
            item = {"name": name, "url": url, "primary": raw.get("primary") is True}
            if get_backup_url(raw): item["backup_url"] = get_backup_url(raw)
            if get_backup_url(raw, True): item["backup_page_url"] = get_backup_url(raw, True)
            files.append(item)
    if files and not any(item["primary"] for item in files):
        files[0]["primary"] = True
    primary_seen = False
    for item in files:
        if item["primary"] and not primary_seen:
            primary_seen = True
        elif item["primary"]:
            item["primary"] = False
    return files


def new_button(body):
    action = body.get("action", "link")
    target = body.get("target") or body.get("url") or ""
    if action == "script":
        target = normalize_script_target(target)
    item = {"name": body.get("name", "未命名"), "icon": body.get("icon", ""), "action": action}
    item["id"] = body.get("id") or new_id("btn")
    item["enabled"] = body.get("enabled", True) is not False
    try:
        item["sort"] = int(body.get("sort") if body.get("sort") not in (None, "") else 0)
    except Exception:
        item["sort"] = 0
    if body.get("description") or body.get("intro") or body.get("remark"):
        item["description"] = body.get("description") or body.get("intro") or body.get("remark")
    if action == "download":
        item["download_url"] = target
        if get_backup_url(body): item["backup_url"] = get_backup_url(body)
        if get_backup_url(body, True): item["backup_page_url"] = get_backup_url(body, True)
        download_directory = str(body.get("download_directory") or body.get("download_path") or "").strip()[:1000]
        if download_directory:
            item["download_directory"] = download_directory
            item["download_delete_on_exit"] = body.get("download_delete_on_exit") is True
        files = normalize_download_files(body.get("files"))
        if (body.get("download_mode") == "multiple" or len(files) > 1) and files:
            item["download_mode"] = "multiple"
            item["package_name"] = str(body.get("package_name") or body.get("name") or "").strip()
            item["files"] = files
            item["download_url"] = files[0]["url"]
    elif action == "cmd":
        item["command"] = target
    elif action == "script":
        item["script_id"] = target
        if target not in SCRIPT_LABELS:
            item["custom_script"] = target
    elif action == "winget":
        item["package_id"] = target
    else:
        item["url"] = target
    return item


def button_sort_value(button):
    try:
        return int((button or {}).get("sort") or 0)
    except Exception:
        return 0


def button_rows(config):
    rows = []
    changed = False
    for page_id, page in (config.get("pages") or {}).items():
        for si, section in enumerate(page.get("sections") or []):
            buttons = section.get("buttons") or []
            kept = [button for button in buttons if not is_empty_button(button)]
            if len(kept) != len(buttons):
                section["buttons"] = kept
                changed = True
            for bi, button in enumerate(section.get("buttons") or []):
                if not button.get("id"):
                    button["id"] = new_id("btn")
                    changed = True
                rows.append({"scope": "page", "pageId": page_id, "tabIndex": None, "sectionIndex": si, "buttonIndex": bi,
                             "id": button.get("id"),
                             "area": page.get("title") or page.get("name") or page_id, "section": section.get("title", ""),
                             "name": button.get("name", ""), "icon": button.get("icon", ""), "action": button.get("action", "link"),
                             "enabled": button.get("enabled", True) is not False,
                             "sort": button_sort_value(button), "target": get_target(button), "raw": button})
    for ti, tab in enumerate(config.get("toolbox_tabs") or []):
        for si, section in enumerate(tab.get("sections") or []):
            buttons = section.get("buttons") or []
            kept = [button for button in buttons if not is_empty_button(button)]
            if len(kept) != len(buttons):
                section["buttons"] = kept
                changed = True
            for bi, button in enumerate(section.get("buttons") or []):
                if not button.get("id"):
                    button["id"] = new_id("btn")
                    changed = True
                rows.append({"scope": "toolbox", "pageId": None, "tabIndex": ti, "sectionIndex": si, "buttonIndex": bi,
                             "id": button.get("id"),
                             "area": tab.get("name", ""), "section": section.get("title", ""),
                             "name": button.get("name", ""), "icon": button.get("icon", ""), "action": button.get("action", "link"),
                             "enabled": button.get("enabled", True) is not False,
                             "sort": button_sort_value(button), "target": get_target(button), "raw": button})
    rows.sort(key=lambda row: (row.get("area") or "", row.get("section") or "", int(row.get("sort") or 0), int(row.get("buttonIndex") or 0)))
    return rows, changed


def is_empty_button(button):
    if not isinstance(button, dict):
        return True
    name = str(button.get("name") or "").strip()
    if name and name != "未命名":
        return False
    if str(button.get("icon") or "").strip():
        return False
    if str(button.get("description") or button.get("intro") or button.get("remark") or "").strip():
        return False
    return not get_target(button).strip()


def get_container(config, body):
    if body.get("scope") == "toolbox":
        return config["toolbox_tabs"][int(body.get("tabIndex", 0))]
    return config["pages"][body.get("pageId")]


def find_button_slot(config, body):
    button_id = body.get("id")
    if button_id:
        for page_id, page in (config.get("pages") or {}).items():
            for si, section in enumerate(page.get("sections") or []):
                for bi, button in enumerate(section.get("buttons") or []):
                    if button.get("id") == button_id:
                        return section, bi
        for ti, tab in enumerate(config.get("toolbox_tabs") or []):
            for si, section in enumerate(tab.get("sections") or []):
                for bi, button in enumerate(section.get("buttons") or []):
                    if button.get("id") == button_id:
                        return section, bi
    container = get_container(config, body)
    section = container["sections"][int(body["sectionIndex"])]
    return section, int(body["buttonIndex"])


def target_button_section(config, body):
    target_scope = body.get("targetScope") or body.get("scope")
    if target_scope == "toolbox":
        tab_index = body.get("targetTabIndex")
        if tab_index in (None, ""):
            tab_index = body.get("tabIndex", 0)
        container = config["toolbox_tabs"][int(tab_index)]
    else:
        page_id = body.get("targetPageId") or body.get("pageId")
        container = config["pages"][page_id]

    section_index = body.get("targetSectionIndex")
    if section_index in (None, ""):
        section_index = body.get("sectionIndex", 0)
    section_index = max(0, int(section_index))
    sections = container.setdefault("sections", [])
    while len(sections) <= section_index:
        sections.append({"title": "默认分组", "buttons": []})
    return sections[section_index]


def update_button(config, body):
    source_section, button_index = find_button_slot(config, body)
    source_buttons = source_section.setdefault("buttons", [])
    old_button = source_buttons[button_index]
    old_id = old_button.get("id") or body.get("id")
    payload = dict(body.get("button") or body)
    if old_id:
        payload["id"] = old_id
    updated_button = new_button(payload)
    target_section = target_button_section(config, body)

    if target_section is source_section:
        source_buttons[button_index] = updated_button
    else:
        del source_buttons[button_index]
        target_section.setdefault("buttons", []).append(updated_button)
    return updated_button


def clean_invite_prefix(value):
    text = "".join(ch for ch in str(value or "YQ").upper() if ch.isalnum() or ch in "-_").strip("-_")
    return (text or "YQ")[:18]


def make_invite_code(prefix, existing):
    for _ in range(1000):
        code = f"{prefix}-{random_hex(4).upper()}"
        if code not in existing:
            return code
    raise ValueError("邀请码生成失败，请重试。")


def csharp_literal(value):
    return '"' + str(value).replace("\\", "\\\\").replace('"', '\\"').replace("\r", "\\r").replace("\n", "\\n").replace("\t", "\\t") + '"'


def assembly_version(value):
    text = str(value or "1.0.0.0").strip().lstrip("vV")
    parts = []
    for raw in text.replace("_", ".").replace("-", ".").split("."):
        if raw.isdigit():
            parts.append(str(max(0, min(65535, int(raw)))))
        if len(parts) == 4:
            break
    while len(parts) < 4:
        parts.append("0")
    return ".".join(parts)


def make_ico_from_png(png_bytes):
    size = len(png_bytes)
    header = b"\x00\x00\x01\x00\x01\x00"
    entry = bytes([0, 0, 0, 0]) + (1).to_bytes(2, "little") + (32).to_bytes(2, "little") + size.to_bytes(4, "little") + (22).to_bytes(4, "little")
    return header + entry + png_bytes


def custom_client_icon(app, target_dir):
    url = (app.get("exe_icon") or app.get("exe_icon_url") or "").strip()
    if not url:
        return CLIENT_ICON
    if url.lower().startswith(("http://", "https://")):
        cache_key = hashlib.sha256(url.encode("utf-8")).hexdigest()
        cached_icon = ICON_CACHE / f"{cache_key}.ico"
        if cached_icon.exists():
            return cached_icon
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "ToolboxAdminApi"})
        with urllib.request.urlopen(request, timeout=3) as response:
            data = response.read(2 * 1024 * 1024)
            content_type = response.headers.get("Content-Type", "").lower()
        icon_path = Path(target_dir) / "client-icon.ico"
        lower = url.lower().split("?", 1)[0]
        if lower.endswith(".ico") or "image/x-icon" in content_type or "image/vnd.microsoft.icon" in content_type:
            icon_path.write_bytes(data)
            if url.lower().startswith(("http://", "https://")):
                ICON_CACHE.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(icon_path, ICON_CACHE / f"{hashlib.sha256(url.encode('utf-8')).hexdigest()}.ico")
            return icon_path
        if lower.endswith(".png") or "image/png" in content_type or data.startswith(b"\x89PNG\r\n\x1a\n"):
            icon_path.write_bytes(make_ico_from_png(data))
            if url.lower().startswith(("http://", "https://")):
                ICON_CACHE.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(icon_path, ICON_CACHE / f"{hashlib.sha256(url.encode('utf-8')).hexdigest()}.ico")
            return icon_path
    except Exception:
        if url.lower().startswith(("http://", "https://")):
            cached_icon = ICON_CACHE / f"{hashlib.sha256(url.encode('utf-8')).hexdigest()}.ico"
            if cached_icon.exists():
                return cached_icon
        return CLIENT_ICON
    return CLIENT_ICON


def client_cache_key(user, base_url, app_config, source, build_id, build_stamp, integrity_seed, variant=DEFAULT_CLIENT_VARIANT):
    icon_ref = (app_config.get("exe_icon") or app_config.get("exe_icon_url") or "").strip()
    payload = {
        "variant": normalize_client_variant(variant),
        "userId": user.get("id"),
        "username": user.get("username"),
        "displayName": user_display_name(user),
        "apiKey": user.get("apiKey"),
        "baseUrl": base_url.rstrip("/"),
        "app": app_config,
        "templateSha256": hashlib.sha256(source.encode("utf-8")).hexdigest(),
        "buildId": build_id,
        "buildStamp": build_stamp,
        "integritySeed": integrity_seed,
        "defaultIconMtime": int(CLIENT_ICON.stat().st_mtime) if CLIENT_ICON.exists() else 0,
        "iconRef": icon_ref,
    }
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def read_client_cache(cache_key):
    exe_path = CLIENT_CACHE / f"{cache_key}.exe"
    meta_path = CLIENT_CACHE / f"{cache_key}.json"
    if not exe_path.exists() or not meta_path.exists():
        return None
    try:
        meta = read_json(meta_path, {})
        data = exe_path.read_bytes()
        if not is_windows_exe(data):
            exe_path.unlink(missing_ok=True)
            meta_path.unlink(missing_ok=True)
            return None
        return meta.get("name") or "toolbox.exe", data
    except Exception:
        return None


def write_client_cache(cache_key, name, data):
    if not is_windows_exe(data):
        raise RuntimeError("EXE 生成结果无效，已拒绝写入缓存。")
    CLIENT_CACHE.mkdir(parents=True, exist_ok=True)
    exe_path = CLIENT_CACHE / f"{cache_key}.exe"
    meta_path = CLIENT_CACHE / f"{cache_key}.json"
    exe_path.write_bytes(data)
    write_json(meta_path, {"name": name, "createdAt": now_iso(), "bytes": len(data)})
    cleanup_client_build_artifacts()


def cleanup_client_build_artifacts():
    settings = client_build_cleanup_settings()
    now_ts = time.time()
    cache_cutoff = now_ts - settings["cacheSeconds"]
    job_cutoff = now_ts - settings["jobSeconds"]
    try:
        CLIENT_CACHE.mkdir(parents=True, exist_ok=True)
        entries = sorted(CLIENT_CACHE.glob("*.exe"), key=lambda p: p.stat().st_mtime, reverse=True)
        for old in entries[settings["maxEntries"]:]:
            old.unlink(missing_ok=True)
            old.with_suffix(".json").unlink(missing_ok=True)
        for exe_path in CLIENT_CACHE.glob("*.exe"):
            try:
                if exe_path.stat().st_mtime < cache_cutoff:
                    exe_path.unlink(missing_ok=True)
                    exe_path.with_suffix(".json").unlink(missing_ok=True)
            except Exception:
                pass
        for meta_path in CLIENT_CACHE.glob("*.json"):
            try:
                if not meta_path.with_suffix(".exe").exists():
                    meta_path.unlink(missing_ok=True)
            except Exception:
                pass
    except Exception:
        pass
    try:
        CLIENT_JOBS.mkdir(parents=True, exist_ok=True)
        for exe_path in CLIENT_JOBS.glob("*.exe"):
            try:
                if exe_path.stat().st_mtime < job_cutoff:
                    exe_path.unlink(missing_ok=True)
            except Exception:
                pass
        with CLIENT_BUILD_LOCK:
            stale_job_ids = []
            for job_id, job in CLIENT_BUILD_JOBS.items():
                status = job.get("status")
                updated_at = float(job.get("updatedAt") or job.get("createdAt") or 0)
                if status in ("done", "error", "missing") and updated_at < job_cutoff:
                    stale_job_ids.append(job_id)
            for job_id in stale_job_ids:
                CLIENT_BUILD_JOBS.pop(job_id, None)
    except Exception:
        pass


def run_client_build_cleanup_loop():
    while True:
        try:
            cleanup_client_build_artifacts()
        except Exception:
            pass
        time.sleep(client_build_cleanup_settings()["intervalSeconds"])


def public_client_build_job(job_id):
    cleanup_client_build_artifacts()
    with CLIENT_BUILD_LOCK:
        job = dict(CLIENT_BUILD_JOBS.get(job_id) or {})
    if not job:
        return None
    return {
        "id": job_id,
        "status": job.get("status", "missing"),
        "message": job.get("message", ""),
        "fileName": job.get("fileName", ""),
        "variant": job.get("variant", DEFAULT_CLIENT_VARIANT),
        "variantLabel": job.get("variantLabel", client_variant_info(job.get("variant", DEFAULT_CLIENT_VARIANT)).get("label")),
        "createdAt": job.get("createdAt", 0),
        "updatedAt": job.get("updatedAt", 0),
    }


def integrity_settings():
    settings = read_system_settings().get("integrity") or {}
    secret = str(settings.get("secret") or "").strip()
    if len(secret) < 32:
        secret = random_hex(24)
        settings["secret"] = secret
        system = read_system_settings()
        system["integrity"] = settings
        write_json(SYSTEM_PATH, system)
    try:
        ttl_minutes = max(5, min(43200, int(settings.get("tokenTtlMinutes") or 10080)))
    except Exception:
        ttl_minutes = 10080
    return {
        "enabled": settings.get("enabled", True) is not False,
        "secret": secret,
        "tokenTtlSeconds": ttl_minutes * 60,
        "lockBuildAfterFirstIssue": settings.get("lockBuildAfterFirstIssue", False) is not False,
    }


def client_signature_payload(user_id, api_key, build_id, build_stamp, integrity_seed, base_url, exe_sha256=""):
    return "|".join([
        str(user_id or ""),
        str(api_key or ""),
        str(build_id or ""),
        str(build_stamp or ""),
        str(integrity_seed or ""),
        str(base_url or "").rstrip("/"),
        str(exe_sha256 or ""),
    ])


def sign_client_build(user_id, api_key, build_id, build_stamp, integrity_seed, base_url, exe_sha256=""):
    settings = integrity_settings()
    payload = client_signature_payload(user_id, api_key, build_id, build_stamp, integrity_seed, base_url, exe_sha256)
    return hmac_sha256_hex(settings["secret"], payload)


def register_client_build(user, api_key, base_url, build_id, build_stamp, integrity_seed, exe_sha256, source_sha256):
    data = read_client_integrity()
    builds = data.setdefault("builds", {})
    build_signature = sign_client_build(user.get("id"), api_key, build_id, build_stamp, integrity_seed, base_url, exe_sha256)
    builds[build_id] = {
        "id": build_id,
        "userId": user.get("id"),
        "username": user.get("username"),
        "apiKeyHash": sha256_hex(api_key),
        "baseUrl": base_url.rstrip("/"),
        "buildStamp": str(build_stamp),
        "integritySeedHash": sha256_hex(integrity_seed),
        "exeSha256": exe_sha256,
        "sourceSha256": source_sha256,
        "signature": build_signature,
        "createdAt": now_iso(),
        "firstVerifiedAt": "",
        "lastVerifiedAt": "",
        "verifyCount": 0,
        "revoked": False,
    }
    try:
        entries = sorted(builds.values(), key=lambda row: row.get("createdAt", ""), reverse=True)
        keep_ids = {row.get("id") for row in entries[:1000]}
        data["builds"] = {key: value for key, value in builds.items() if key in keep_ids}
    except Exception:
        pass
    write_client_integrity(data)
    return build_signature


def issue_build_runtime_token(build_id, user_id, api_key, expires_in, data=None):
    token = random_hex(32)
    own_data = data is None
    data = data or read_client_integrity()
    cleanup_runtime_tokens(data)
    data.setdefault("tokens", {})[token] = {
        "userId": user_id,
        "apiKeyHash": sha256_hex(api_key),
        "buildId": build_id,
        "issuedAt": time.time(),
        "expiresAt": time.time() + max(60, int(expires_in or 0)),
    }
    if own_data:
        write_client_integrity(data)
    return token


def cleanup_runtime_tokens(data):
    now_ts = time.time()
    tokens = data.setdefault("tokens", {})
    expired = []
    for token, row in tokens.items():
        try:
            if float(row.get("expiresAt", 0)) <= now_ts:
                expired.append(token)
        except Exception:
            expired.append(token)
    for token in expired:
        tokens.pop(token, None)


def verify_runtime_token(handler, user):
    settings = integrity_settings()
    if not settings["enabled"]:
        return True
    token = (handler.headers.get("X-Client-Integrity") or handler.query.get("runtimeToken", [""])[0] or "").strip()
    if not token:
        return verify_build_headers(handler, user)
    data = read_client_integrity()
    cleanup_runtime_tokens(data)
    row = data.get("tokens", {}).get(token)
    if not row:
        write_client_integrity(data)
        return verify_build_headers(handler, user)
    if row.get("userId") != user.get("id"):
        return False
    if row.get("apiKeyHash") != sha256_hex(user.get("apiKey") or ""):
        return False
    if float(row.get("expiresAt", 0) or 0) <= time.time():
        data.get("tokens", {}).pop(token, None)
        write_client_integrity(data)
        return verify_build_headers(handler, user)
    return True

def verify_any_runtime_token(handler):
    settings = integrity_settings()
    if not settings["enabled"]:
        return True
    token = (handler.headers.get("X-Client-Integrity") or handler.query.get("runtimeToken", [""])[0] or "").strip()
    if not token:
        return verify_build_headers(handler)
    data = read_client_integrity()
    cleanup_runtime_tokens(data)
    row = data.get("tokens", {}).get(token)
    if not row:
        write_client_integrity(data)
        return verify_build_headers(handler)
    if float(row.get("expiresAt", 0) or 0) <= time.time():
        data.get("tokens", {}).pop(token, None)
        write_client_integrity(data)
        return verify_build_headers(handler)
    return True

def verify_build_headers(handler, user=None):
    settings = integrity_settings()
    if not settings["enabled"]:
        return True
    api_key = (handler.query.get("key", [""])[0] or handler.headers.get("X-Client-Api-Key") or "").strip()
    if user is None and api_key:
        user = find_user_by_api_key(api_key)
    if not user:
        return False
    if not api_key:
        api_key = user.get("apiKey") or ""
    build_id = (handler.headers.get("X-Client-Build-Id") or "").strip()
    build_stamp = (handler.headers.get("X-Client-Build-Stamp") or "").strip()
    integrity_seed = (handler.headers.get("X-Client-Integrity-Seed") or "").strip()
    build_signature = (handler.headers.get("X-Client-Build-Signature") or "").strip()
    exe_sha256 = (handler.headers.get("X-Client-Exe-Sha256") or "").strip().lower()
    if not build_id or not build_stamp or not integrity_seed or not build_signature or not exe_sha256:
        return False
    data = read_client_integrity()
    cleanup_runtime_tokens(data)
    build = data.get("builds", {}).get(build_id)
    if build:
        if build.get("revoked"):
            return False
        if build.get("userId") != user.get("id") or build.get("apiKeyHash") != sha256_hex(api_key):
            return False
        if build.get("buildStamp") != build_stamp or build.get("integritySeedHash") != sha256_hex(integrity_seed):
            return False
        if build.get("exeSha256") and build.get("exeSha256") != exe_sha256:
            return False
        return True
    expected_signature = sign_client_build(user.get("id"), api_key, build_id, build_stamp, integrity_seed, normalize_public_base_url(handler.base_url()), "")
    if not constant_time_equals(build_signature, expected_signature):
        return False
    data.setdefault("builds", {})[build_id] = {
        "id": build_id,
        "userId": user.get("id"),
        "username": user.get("username"),
        "apiKeyHash": sha256_hex(api_key),
        "baseUrl": normalize_public_base_url(handler.base_url()).rstrip("/"),
        "buildStamp": build_stamp,
        "integritySeedHash": sha256_hex(integrity_seed),
        "exeSha256": exe_sha256,
        "sourceSha256": "",
        "signature": build_signature,
        "createdAt": now_iso(),
        "firstVerifiedAt": "",
        "lastVerifiedAt": "",
        "verifyCount": 0,
        "revoked": False,
    }
    write_client_integrity(data)
    return True


def verify_client_build_request(handler):
    body = handler.read_body()
    api_key = (body.get("apiKey") or handler.query.get("key", [""])[0] or "").strip()
    user = find_user_by_api_key(api_key)
    if not user:
        return False, {"error": "工具箱对接密钥无效或账号已停用。"}, 403
    settings = integrity_settings()
    if not settings["enabled"]:
        token = issue_build_runtime_token("integrity-disabled", user.get("id"), api_key, settings["tokenTtlSeconds"])
        return True, {"ok": True, "runtimeToken": token, "expiresIn": settings["tokenTtlSeconds"]}, 200
    build_id = str(body.get("buildId") or "").strip()
    build_stamp = str(body.get("buildStamp") or "").strip()
    integrity_seed = str(body.get("integritySeed") or "").strip()
    build_signature = str(body.get("buildSignature") or "").strip()
    exe_sha256 = str(body.get("exeSha256") or "").strip().lower()
    if not build_id or not build_stamp or not integrity_seed or not exe_sha256:
        return False, {"error": "工具箱编译校验参数不完整，请从后台重新下载。"}, 400
    data = read_client_integrity()
    cleanup_runtime_tokens(data)
    build = data.get("builds", {}).get(build_id)
    if not build:
        expected_signature = sign_client_build(user.get("id"), api_key, build_id, build_stamp, integrity_seed, normalize_public_base_url(handler.base_url()), "")
        if not build_signature or not constant_time_equals(build_signature, expected_signature):
            write_client_integrity(data)
            return False, {"error": "工具箱编译记录不存在，请从后台重新下载。"}, 403
        build = {
            "id": build_id,
            "userId": user.get("id"),
            "username": user.get("username"),
            "apiKeyHash": sha256_hex(api_key),
            "baseUrl": normalize_public_base_url(handler.base_url()).rstrip("/"),
            "buildStamp": build_stamp,
            "integritySeedHash": sha256_hex(integrity_seed),
            "exeSha256": exe_sha256,
            "sourceSha256": "",
            "signature": build_signature,
            "createdAt": now_iso(),
            "firstVerifiedAt": "",
            "lastVerifiedAt": "",
            "verifyCount": 0,
            "revoked": False,
        }
        data.setdefault("builds", {})[build_id] = build
    if build.get("revoked"):
        return False, {"error": "该工具箱版本已被管理员停用，请重新下载最新版。"}, 403
    if build.get("userId") != user.get("id") or build.get("apiKeyHash") != sha256_hex(api_key):
        return False, {"error": "工具箱用户校验失败，请使用当前账号重新下载。"}, 403
    if build.get("buildStamp") != build_stamp or build.get("integritySeedHash") != sha256_hex(integrity_seed):
        return False, {"error": "工具箱编译信息校验失败，请重新下载。"}, 403
    if build.get("exeSha256") and build.get("exeSha256") != exe_sha256:
        return False, {"error": "工具箱文件已被修改，请从后台重新下载最新版。"}, 403
    token = issue_build_runtime_token(build_id, user.get("id"), api_key, settings["tokenTtlSeconds"], data)
    build["lastVerifiedAt"] = now_iso()
    build["verifyCount"] = int(build.get("verifyCount") or 0) + 1
    if not build.get("firstVerifiedAt"):
        build["firstVerifiedAt"] = build["lastVerifiedAt"]
    write_client_integrity(data)
    return True, {"ok": True, "runtimeToken": token, "expiresIn": settings["tokenTtlSeconds"]}, 200

def start_client_build_job(user, base_url, variant=DEFAULT_CLIENT_VARIANT):
    cleanup_client_build_artifacts()
    CLIENT_JOBS.mkdir(parents=True, exist_ok=True)
    job_id = random_hex(12)
    now = time.time()
    variant = normalize_client_variant(variant)
    variant_label = client_variant_info(variant).get("label") or "工具箱"
    with CLIENT_BUILD_LOCK:
        CLIENT_BUILD_JOBS[job_id] = {
            "status": "queued",
            "message": "已加入生成队列",
            "userId": user.get("id"),
            "variant": variant,
            "variantLabel": variant_label,
            "createdAt": now,
            "updatedAt": now,
        }

    def run():
        try:
            with CLIENT_BUILD_LOCK:
                CLIENT_BUILD_JOBS[job_id]["status"] = "building"
                CLIENT_BUILD_JOBS[job_id]["message"] = f"服务器正在编译 {variant_label}"
                CLIENT_BUILD_JOBS[job_id]["updatedAt"] = time.time()
            name, data = make_client_exe(user, base_url, variant)
            if not is_windows_exe(data):
                raise RuntimeError("EXE 生成结果无效，请检查服务器编译器和缓存目录。")
            exe_path = CLIENT_JOBS / f"{job_id}.exe"
            exe_path.write_bytes(data)
            with CLIENT_BUILD_LOCK:
                CLIENT_BUILD_JOBS[job_id].update({
                    "status": "done",
                    "message": "工具箱 EXE 已生成",
                    "fileName": name,
                    "variant": variant,
                    "variantLabel": variant_label,
                    "path": str(exe_path),
                    "bytes": len(data),
                    "updatedAt": time.time(),
                })
        except Exception as exc:
            with CLIENT_BUILD_LOCK:
                CLIENT_BUILD_JOBS[job_id].update({
                    "status": "error",
                    "message": str(exc),
                    "updatedAt": time.time(),
                })

    threading.Thread(target=run, daemon=True).start()
    return public_client_build_job(job_id)


def make_client_exe(user, base_url, variant=DEFAULT_CLIENT_VARIANT):
    variant = normalize_client_variant(variant)
    if not CLIENT_TEMPLATE.exists():
        raise RuntimeError("客户端模板缺失，无法生成 EXE。")
    compiler = find_csharp_compiler()
    if not compiler:
        raise RuntimeError("服务器未安装 Mono/C# 编译器，无法在线生成 EXE。后台可正常使用；如需下载 EXE，请安装 mono-devel 后重启 toolbox-admin。")
    if not CLIENT_ICON.exists():
        raise RuntimeError("工具箱默认图标缺失，请上传 assets/toolbox-default.ico 后再生成 EXE。")
    base_url = normalize_public_base_url(base_url)
    api_key = user.get("apiKey") or random_hex(20)
    user["apiKey"] = api_key
    config_url = f"{base_url.rstrip('/')}/api/toolbox/config?key={quote(api_key)}"
    source = CLIENT_TEMPLATE.read_text(encoding="utf-8")
    app_config = read_config(user.get("id")).get("app", {})
    build_id = random_hex(12)
    build_stamp = str(int(time.time()))
    integrity_seed = random_hex(16)
    exe_title = app_config.get("exe_title") or app_config.get("title") or "Toolbox"
    exe_description = app_config.get("exe_description") or app_config.get("subtitle") or exe_title
    exe_product = app_config.get("exe_product") or app_config.get("title") or exe_title
    exe_company = app_config.get("exe_company") or ""
    exe_copyright = app_config.get("exe_copyright") or ""
    exe_version = assembly_version(app_config.get("exe_version") or app_config.get("version") or "1.0.0.0")
    variant_label = client_variant_info(variant).get("label") or "工具箱"
    file_name = client_exe_filename(user, variant=variant)
    cache_key = client_cache_key(user, base_url, app_config, source, build_id, build_stamp, integrity_seed, variant)
    cached = read_client_cache(cache_key)
    if cached:
        return cached
    source = source.replace('"__CONFIG_URL__"', csharp_literal(config_url))
    embedded_config_json = json.dumps(public_toolbox_config(user.get("id")), ensure_ascii=False, separators=(",", ":"))
    source = source.replace('"__EMBEDDED_CONFIG_JSON__"', csharp_literal(embedded_config_json))
    source = source.replace('"__CLIENT_VARIANT__"', csharp_literal(variant))
    source = source.replace('"__CLIENT_VARIANT_LABEL__"', csharp_literal(variant_label))
    update_variants = app_config.get("update_variants") if isinstance(app_config.get("update_variants"), dict) else {}
    variant_update = update_variants.get(variant) if isinstance(update_variants.get(variant), dict) else {}
    client_app_version = variant_update.get("version") or app_config.get("version") or "1.0"
    source = source.replace('"__CLIENT_APP_VERSION__"', csharp_literal(client_app_version))
    source = source.replace('"__BUILD_ID__"', csharp_literal(build_id))
    source = source.replace('"__BUILD_STAMP__"', csharp_literal(build_stamp))
    build_signature = sign_client_build(user.get("id"), api_key, build_id, build_stamp, integrity_seed, base_url, "")
    source = source.replace('"__INTEGRITY_SEED__"', csharp_literal(integrity_seed))
    source = source.replace('"__BUILD_SIGNATURE__"', csharp_literal(build_signature))
    source = source.replace('"__EXE_TITLE__"', csharp_literal(exe_title))
    source = source.replace('"__EXE_DESCRIPTION__"', csharp_literal(exe_description))
    source = source.replace('"__EXE_COMPANY__"', csharp_literal(exe_company))
    source = source.replace('"__EXE_PRODUCT__"', csharp_literal(exe_product))
    source = source.replace('"__EXE_COPYRIGHT__"', csharp_literal(exe_copyright))
    source = source.replace('"__EXE_VERSION__"', csharp_literal(exe_version))
    source = source.replace('"__EXE_FILE_VERSION__"', csharp_literal(exe_version))
    with tempfile.TemporaryDirectory() as td:
        icon_file = custom_client_icon(app_config, td)
        embedded_brand_icon = base64.b64encode(
            icon_file.read_bytes()
        ).decode("ascii")
        source = source.replace(
            '"__EMBEDDED_BRAND_ICON_BASE64__"',
            csharp_literal(embedded_brand_icon)
        )
        src = Path(td) / "ToolboxClient.cs"
        exe = Path(td) / file_name
        src.write_text(source, encoding="utf-8")
        compile_args = ["-target:winexe", "-optimize+", f"-out:{exe}", f"-win32icon:{icon_file}",
                        "-r:System.dll", "-r:System.Core.dll", "-r:System.Windows.Forms.dll",
                        "-r:System.Drawing.dll", "-r:System.Web.Extensions.dll", str(src)]
        args = csharp_compile_command(compiler, compile_args)
        result = subprocess.run(args, universal_newlines=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
        if result.returncode != 0 or not exe.exists():
            raise RuntimeError("EXE 编译失败：" + (result.stderr or result.stdout))
        data = exe.read_bytes()
        if not is_windows_exe(data):
            raise RuntimeError(
                "EXE 编译完成但输出不是 Windows EXE。"
                f"检测到的编译器：{compiler}；文件头：{binary_header_preview(data)}。"
                "请安装 mono-devel 后重启 toolbox-admin，再清理旧编译缓存重试。"
            )
        exe_sha256 = hashlib.sha256(data).hexdigest()
        source_sha256 = hashlib.sha256(source.encode("utf-8")).hexdigest()
        register_client_build(user, api_key, base_url, build_id, build_stamp, integrity_seed, exe_sha256, source_sha256)
        write_client_cache(cache_key, file_name, data)
        return file_name, data


def admin_desktop_exe_filename(timestamp=None):
    return f"toolbox-admin-desktop-{int(timestamp or time.time())}.exe"


def make_admin_desktop_exe(base_url):
    if not ADMIN_DESKTOP_TEMPLATE.exists():
        raise RuntimeError("后台 EXE 模板缺失，无法生成。")
    compiler = find_csharp_compiler()
    if not compiler:
        raise RuntimeError("服务器未安装 Mono/C# 编译器，无法在线生成后台 EXE。请安装 mono-devel 后重启 toolbox-admin。")
    if not CLIENT_ICON.exists():
        raise RuntimeError("后台默认图标缺失，请上传 assets/toolbox-default.ico 后再生成 EXE。")
    base_url = normalize_public_base_url(base_url)
    source = ADMIN_DESKTOP_TEMPLATE.read_text(encoding="utf-8")
    if any(marker not in source for marker in ("Register(", "SendResetCode(", "ResetPassword(")):
        raise RuntimeError("后台 EXE 模板不完整/已过期：缺少 Register/SendResetCode/ResetPassword。")
    app_config = read_config("").get("app", {})
    exe_title = app_config.get("admin_desktop_title") or app_config.get("admin_title") or DEFAULT_ADMIN_TITLE
    exe_description = app_config.get("admin_desktop_description") or "工具箱后台桌面登录器"
    exe_product = app_config.get("admin_desktop_product") or exe_title
    exe_company = app_config.get("exe_company") or ""
    exe_copyright = app_config.get("exe_copyright") or ""
    exe_version = assembly_version(app_config.get("admin_desktop_version") or app_config.get("exe_version") or app_config.get("version") or "1.0.0.0")
    file_name = admin_desktop_exe_filename()
    source = source.replace('"__ADMIN_URL__"', csharp_literal(base_url))
    source = source.replace('"__ADMIN_TOKEN__"', csharp_literal(ADMIN_TOKEN))
    source = source.replace('"__APP_TITLE__"', csharp_literal(exe_title))
    source = source.replace('"__LOGIN_HINT__"', csharp_literal(app_config.get("login_hint") or DEFAULT_LOGIN_HINT))
    source = source.replace('"__EXE_TITLE__"', csharp_literal(exe_title))
    source = source.replace('"__EXE_DESCRIPTION__"', csharp_literal(exe_description))
    source = source.replace('"__EXE_COMPANY__"', csharp_literal(exe_company))
    source = source.replace('"__EXE_PRODUCT__"', csharp_literal(exe_product))
    source = source.replace('"__EXE_COPYRIGHT__"', csharp_literal(exe_copyright))
    source = source.replace('"__EXE_VERSION__"', csharp_literal(exe_version))
    source = source.replace('"__EXE_FILE_VERSION__"', csharp_literal(exe_version))
    with tempfile.TemporaryDirectory() as td:
        icon_file = custom_client_icon(app_config, td)
        src = Path(td) / "ToolboxAdminDesktop.cs"
        exe = Path(td) / file_name
        src.write_text(source, encoding="utf-8")
        compile_args = [
            "-target:winexe",
            "-optimize+",
            f"-out:{exe}",
            f"-win32icon:{icon_file}",
            "-r:System.dll",
            "-r:System.Core.dll",
            "-r:System.Windows.Forms.dll",
            "-r:System.Drawing.dll",
            "-r:System.Web.Extensions.dll",
            "-r:System.Security.dll",
            str(src),
        ]
        args = csharp_compile_command(compiler, compile_args)
        result = subprocess.run(args, universal_newlines=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
        if result.returncode != 0 or not exe.exists():
            raise RuntimeError("后台 EXE 编译失败：" + (result.stderr or result.stdout))
        data = exe.read_bytes()
        if not is_windows_exe(data):
            raise RuntimeError(
                "后台 EXE 编译完成但输出不是 Windows EXE。"
                f"检测到的编译器：{compiler}；文件头：{binary_header_preview(data)}。"
                "请安装 mono-devel 后重启 toolbox-admin，再重试。"
            )
        return file_name, data


class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    request_queue_size = 128

    def __init__(self, *args, **kwargs):
        max_threads = max(8, int(os.environ.get("TOOLBOX_MAX_REQUEST_THREADS", "64")))
        self.request_slots = threading.BoundedSemaphore(max_threads)
        super().__init__(*args, **kwargs)

    def process_request(self, request, client_address):
        self.request_slots.acquire()
        try:
            super().process_request(request, client_address)
        except Exception:
            self.request_slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.request_slots.release()


class Handler(BaseHTTPRequestHandler):
    server_version = "ToolboxAdminApiPython/1.0"

    def read_body(self):
        length = int(self.headers.get("Content-Length", "0") or "0")
        if not length:
            return {}
        if length > 2 * 1024 * 1024:
            raise ValueError("请求内容过大。")
        return json.loads(self.rfile.read(length).decode("utf-8") or "{}")

    def send_security_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'")

    def send_json(self, value, status=200):
        data = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.send_security_headers()
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        if self.command.upper() != "HEAD":
            self.wfile.write(data)

    def send_cached_json(self, data, compressed, etag):
        if self.headers.get("If-None-Match", "").strip() == etag:
            self.send_response(304)
            self.send_header("ETag", etag)
            self.send_header("Cache-Control", "private, no-cache, must-revalidate")
            self.send_header("Vary", "Accept-Encoding")
            self.send_security_headers()
            self.end_headers()
            return
        use_gzip = "gzip" in self.headers.get("Accept-Encoding", "").lower()
        body = compressed if use_gzip else data
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "private, no-cache, must-revalidate")
        self.send_header("ETag", etag)
        self.send_header("Vary", "Accept-Encoding")
        if use_gzip:
            self.send_header("Content-Encoding", "gzip")
        self.send_security_headers()
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if self.command.upper() != "HEAD":
            self.wfile.write(body)

    def send_bytes(self, data, content_type, status=200, filename=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.send_security_headers()
        if filename:
            fallback = ascii_download_fallback(filename)
            encoded = quote(str(filename), safe="")
            self.send_header("Content-Disposition", f'attachment; filename="{fallback}"; filename*=UTF-8\'\'{encoded}')
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def do_GET(self):
        self.dispatch()

    def do_HEAD(self):
        self.dispatch()

    def do_POST(self):
        self.dispatch()

    def do_PUT(self):
        self.dispatch()

    def do_PATCH(self):
        self.dispatch()

    def do_DELETE(self):
        self.dispatch()

    def dispatch(self):
        try:
            parsed = urlparse(self.path)
            self.route = unquote(parsed.path)
            self.query = parse_qs(parsed.query)
            method = self.command.upper()
            path = self.route
            if path == "/api/health":
                return self.send_json({"ok": True, "app": "ToolboxAdminApi", "time": now_iso()})
            if path == "/api/public/brand" and method == "GET":
                return self.send_json(public_brand_config())
            if path == "/api/public/config-share" and method == "GET":
                token = self.query.get("token", [""])[0]
                return self.send_json(public_config_share(read_config_share(token), self.base_url(), include_config=True))
            if path == "/api/toolbox/verify-build" and method == "POST":
                ok, payload, status = verify_client_build_request(self)
                return self.send_json(payload, status)
            if path == "/api/toolbox/popup-config" and method == "GET":
                user = find_user_by_api_key(self.query.get("key", [""])[0] or self.headers.get("X-Client-Api-Key", ""))
                if not user:
                    return self.send_json({"error": "工具箱对接密钥无效或账号已停用。"}, 403)
                return self.send_json(public_popup_config(user["id"], self.base_url()))
            if path == "/api/toolbox/builtin-download" and method in ("GET", "HEAD"):
                return proxy_builtin_download(self)
            if is_login_api_path(path) and method == "POST":
                return handle_desktop_login(self)
            if path == "/api/register" and method == "POST":
                body = self.read_body()
                code = (body.get("inviteCode") or "").strip()
                store = read_users()
                invite = next((x for x in store["inviteCodes"] if x.get("code") == code), None)
                if not invite or invite.get("active") is False:
                    raise ValueError("邀请码无效。")
                used = int(invite.get("usedCount") or 0)
                max_uses = int(invite.get("maxUses") or 1)
                if max_uses > 0 and used >= max_uses:
                    raise ValueError("邀请码已被使用。")
                user = create_user(body.get("username"), body.get("password"), body.get("displayName"), "user", None, body.get("email"))
                store = read_users()
                invite = next((x for x in store["inviteCodes"] if x.get("code") == code), None)
                invite.setdefault("usedBy", []).append({"userId": user["id"], "username": user["username"], "usedAt": now_iso()})
                invite["usedCount"] = used + 1
                if max_uses > 0 and invite["usedCount"] >= max_uses:
                    invite["active"] = False
                write_users(store)
                token = random_hex(32)
                user = mark_user_login(user["id"], self)
                SESSIONS[token] = {"userId": user["id"], "createdAt": now_iso()}
                save_sessions()
                audit_event("register_success", actor=user, target=user.get("id"), handler=self, details={"title": "注册后台账号", "method": "POST", "path": "/api/register"})
                return self.send_json({"token": token, "user": public_user(user)})
            if path == "/api/password/forgot" and method == "POST":
                body = self.read_body()
                email = (body.get("email") or "").strip().lower()
                if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
                    return self.send_json({"error": "请输入正确的邮箱地址。"}, 400)
                now = time.time()
                retry_after = max(0, int(RESET_CODE_REQUESTS.get(email, 0) + RESET_CODE_COOLDOWN_SECONDS - now + 0.999))
                if retry_after > 0:
                    return self.send_json({"error": f"请在 {retry_after} 秒后重新发送验证码。", "retryAfter": retry_after}, 429)
                RESET_CODE_REQUESTS[email] = now
                user = find_user_by_email(email)
                if not user or user.get("active", True) is False:
                    return self.send_json({"ok": True, "message": "如果邮箱存在，验证码会发送到邮箱。"})
                code = str(secrets.randbelow(900000) + 100000)
                RESET_CODES[email] = {"code": code, "userId": user["id"], "expires": time.time() + 600}
                sent = send_reset_email(email, code)
                if not sent:
                    RESET_CODES.pop(email, None)
                    audit_event("password_reset_mail_unavailable", target=user.get("id"), handler=self, success=False)
                    return self.send_json({"error": "密码找回邮件服务暂不可用，请联系管理员。"}, 503)
                audit_event("password_reset_requested", target=user.get("id"), handler=self)
                return self.send_json({"ok": True, "message": "验证码已发送，请查看邮箱。"})
            if path == "/api/password/reset" and method == "POST":
                body = self.read_body()
                email = (body.get("email") or "").strip().lower()
                code = (body.get("code") or "").strip()
                password = body.get("password") or ""
                verify_key = f"{client_ip(self)}:{email}"
                now = time.time()
                attempts = [stamp for stamp in RESET_VERIFY_ATTEMPTS.get(verify_key, []) if now - stamp < LOGIN_WINDOW_SECONDS]
                if len(attempts) >= LOGIN_MAX_FAILURES:
                    audit_event("password_reset_blocked", target=email, handler=self, success=False)
                    return self.send_json({"error": "验证尝试过多，请 15 分钟后重试。"}, 429)
                record = RESET_CODES.get(email)
                if not record or record.get("code") != code or record.get("expires", 0) < time.time():
                    attempts.append(now)
                    RESET_VERIFY_ATTEMPTS[verify_key] = attempts
                    return self.send_json({"error": "验证码无效或已过期。"}, 400)
                if len(password) < 10:
                    return self.send_json({"error": "密码至少 10 位。"}, 400)
                update_user_account(record["userId"], {"password": password})
                RESET_CODES.pop(email, None)
                RESET_VERIFY_ATTEMPTS.pop(verify_key, None)
                audit_event("password_reset_completed", target=record["userId"], handler=self)
                return self.send_json({"ok": True})
            if path in ("/api/toolbox/config", "/api/config"):
                user = find_user_by_api_key(self.query.get("key", [""])[0])
                if not user:
                    return self.send_json({"error": "工具箱对接密钥无效或账号已停用。"}, 403)
                data, compressed, etag = public_toolbox_config_payload(user["id"])
                if self.query.get("watch", [""])[0] == "1":
                    deadline = time.time() + 5
                    while self.headers.get("If-None-Match", "").strip() == etag and time.time() < deadline:
                        time.sleep(1)
                        data, compressed, etag = public_toolbox_config_payload(user["id"])
                return self.send_cached_json(data, compressed, etag)

            if path.startswith("/api/"):
                auth = get_auth(self)
                if not auth:
                    return self.send_json({"error": "请先登录。"}, 401)
                if should_write_generic_audit(path, method):
                    audit_event("backend_" + method.lower(), auth["user"], path, self,
                                {"title": "后台操作", "method": method, "path": path})
                if path.startswith("/api/super"):
                    return self.handle_super(path, method, auth)
                if path.startswith("/api/admin"):
                    return self.handle_admin(path, method, auth)
                return self.send_json({"error": "接口不存在。"}, 404)
            return self.serve_static(path)
        except Exception as exc:
            return self.send_json({"error": str(exc)}, 500)

    def handle_super(self, path, method, auth):
        if not can_manage_users(auth["user"]):
            return self.send_json({"error": "无权限访问用户管理。"}, 403)
        store = read_users()
        if path == "/api/super/audit" and method == "GET":
            if not is_super(auth["user"]):
                return self.send_json({"error": "无权查看操作日志。"}, 403)
            return self.send_json(read_audit_events())
        if path == "/api/super/audit" and method == "DELETE":
            if not is_super(auth["user"]):
                return self.send_json({"error": "无权清空操作日志。"}, 403)
            body = self.read_body()
            if not check_password(str(body.get("currentPassword") or ""), auth["user"].get("passwordHash", "")):
                audit_event("audit_log_clear_failed", auth["user"], handler=self, success=False)
                return self.send_json({"error": "当前管理员密码错误。"}, 403)
            event_keys = {str(value) for value in body.get("eventKeys", []) if str(value)}
            filtered = body.get("filtered") is True
            if filtered and not event_keys:
                return self.send_json({"error": "筛选结果为空，未清理任何日志。"}, 400)
            with SECURITY_LOCK:
                AUDIT_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
                lines = AUDIT_LOG_PATH.read_text(encoding="utf-8").splitlines() if AUDIT_LOG_PATH.exists() else []
                if event_keys:
                    kept = [line for line in lines if hashlib.sha256(line.encode("utf-8")).hexdigest() not in event_keys]
                else:
                    kept = []
                AUDIT_LOG_PATH.write_text(("\n".join(kept) + "\n") if kept else "", encoding="utf-8")
            cleared = len(lines) - len(kept)
            action = "audit_log_filtered_cleared" if filtered else "audit_log_cleared"
            audit_event(action, auth["user"], handler=self, details={"cleared": cleared})
            return self.send_json({"ok": True, "cleared": cleared, "filtered": filtered})
        if path == "/api/super/ip-location/test" and method == "POST":
            if not is_super(auth["user"]):
                return self.send_json({"error": "无权测试定位接口。"}, 403)
            ip = str(self.read_body().get("ip") or client_ip(self)).strip()
            address = locate_ip(ip, True)
            audit_event("ip_location_test", auth["user"], ip, self, {"address": address})
            return self.send_json({"ip": ip, "address": address})
        if path.startswith("/api/super/template"):
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以操作新用户模板。"}, 403)
            if path == "/api/super/template":
                if method == "GET":
                    return self.send_json(read_user_template_config())
                if method == "PUT":
                    write_user_template_config(self.read_body())
                    return self.send_json(read_user_template_config())
                if method == "POST":
                    body = self.read_body()
                    action = (body.get("action") or "").strip()
                    if action == "copy_current":
                        source_user_id = (body.get("userId") or auth["user"].get("id") or "").strip()
                        return self.send_json(copy_user_config_to_template(source_user_id))
                    if action == "reset":
                        return self.send_json(reset_user_template_config())
                    raise ValueError("不支持的模板操作。")
            if path == "/api/super/template/app" and method == "PATCH":
                cfg = read_user_template_config()
                before = json_clone(cfg)
                patch = self.read_body()
                apply_basic_settings_patch(cfg, patch)
                write_user_template_config(cfg)
                details = basic_settings_audit_details(before, cfg, patch, path)
                if details["changes"]:
                    audit_event("config_basic_update", auth["user"], "user-template", self, details)
                return self.send_json(read_user_template_config())
            if path == "/api/super/template/popup" and method == "PATCH":
                cfg = read_user_template_config()
                before_popup = json_clone(cfg.get("popup") or {})
                merged = dict(cfg.get("popup") or {})
                merged.update(self.read_body())
                cfg["popup"] = normalize_popup_settings(merged)
                write_user_template_config(cfg)
                details = popup_settings_audit_details(before_popup, cfg["popup"], path)
                if details["changes"]:
                    audit_event("contact_settings_update", auth["user"], "user-template", self, details)
                return self.send_json(read_user_template_config())
            if path == "/api/super/template/buttons":
                cfg = read_user_template_config()
                if method == "GET":
                    rows, changed = button_rows(cfg)
                    if changed:
                        write_user_template_config(cfg)
                    return self.send_json(rows)
                body = self.read_body()
                before_row = find_button_audit_row(cfg, body)
                operation = "update"
                if method == "POST":
                    container = get_container(cfg, body)
                    sections = container.setdefault("sections", [])
                    while len(sections) <= int(body.get("sectionIndex", 0)):
                        sections.append({"title": "默认分组", "buttons": []})
                    payload = dict(body.get("button") or body)
                    created = new_button(payload)
                    sections[int(body.get("sectionIndex", 0))].setdefault("buttons", []).append(created)
                    body["id"] = created.get("id")
                    operation = "create"
                elif method == "PATCH":
                    updated = update_button(cfg, body)
                    body["id"] = updated.get("id")
                elif method == "DELETE":
                    section, button_index = find_button_slot(cfg, body)
                    if (section["buttons"][button_index] or {}).get("action") == "script":
                        return self.send_json({"error": "内置功能不能删除，请改为停用。"}, 400)
                    del section["buttons"][button_index]
                    operation = "delete"
                else:
                    return self.send_json({"error": "接口不存在"}, 404)
                write_user_template_config(cfg)
                rows, changed = button_rows(cfg)
                if changed:
                    write_user_template_config(cfg)
                after_row = None if operation == "delete" else find_button_audit_row(cfg, body)
                details = button_audit_details(operation, before_row, after_row, path)
                if details["changes"]:
                    audit_event("button_" + operation, auth["user"], "user-template", self, details)
                return self.send_json(rows)
            return self.send_json({"error": "接口不存在"}, 404)
        if path == "/api/super/users/batch" and method == "POST":
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以批量管理账号。"}, 403)
            b = self.read_body()
            ids = set(b.get("ids") or [])
            action = b.get("action")
            if action == "delete" and not check_password(str(b.get("currentPassword") or ""), auth["user"].get("passwordHash", "")):
                audit_event("users_batch_delete_reauth_failed", auth["user"], ",".join(sorted(ids)), self, success=False)
                return self.send_json({"error": "删除用户前必须验证当前管理员密码。"}, 403)
            if "admin" in ids and action in ("delete", "disable"):
                raise ValueError("默认总管理员不能删除或停用。")
            changed = 0
            if action == "delete":
                security_backup("users-batch-delete", [USERS_PATH, SESSIONS_PATH])
                before = len(store["users"])
                store["users"] = [u for u in store["users"] if u.get("id") not in ids]
                changed = before - len(store["users"])
            elif action in ("enable", "disable"):
                for user in store["users"]:
                    if user.get("id") in ids:
                        user["active"] = action == "enable"
                        changed += 1
            elif action in ("allow_json", "deny_json"):
                for user in store["users"]:
                    if user.get("id") in ids:
                        user["canViewJson"] = action == "allow_json" or user.get("role") == "super"
                        changed += 1
            else:
                raise ValueError("不支持的批量操作。")
            write_users(store)
            if action in ("delete", "disable"):
                for user_id in ids:
                    revoke_user_sessions(user_id)
            audit_event(f"users_batch_{action}", auth["user"], ",".join(sorted(ids)), self,
                        {"changed": changed})
            return self.send_json({"ok": True, "changed": changed})
        if path == "/api/super/users":
            if method == "GET":
                return self.send_json({"users": [public_user(u, store) for u in scoped_users(store, auth["user"])]})
            if method == "POST":
                if not is_super(auth["user"]):
                    return self.send_json({"error": "只有总管理员可以创建账号。"}, 403)
                b = self.read_body()
                return self.send_json(public_user(create_user(b.get("username"), b.get("password"), b.get("displayName"), b.get("role"), auth["user"], b.get("email"))))
            if method == "PATCH":
                b = self.read_body()
                if not is_super(auth["user"]):
                    assert_user_scope(auth["user"], b.get("id"))
                    allowed = {"id": b.get("id")}
                    if "active" in b:
                        allowed["active"] = bool(b.get("active"))
                    b = allowed
                target = next((u for u in store["users"] if u.get("id") == b.get("id")), None)
                sensitive = bool(b.get("password") or b.get("resetApiKey"))
                sensitive = sensitive or (target and "email" in b and (b.get("email") or "").strip().lower() != (target.get("email") or "").strip().lower())
                if sensitive and not check_password(str(b.get("currentPassword") or ""), auth["user"].get("passwordHash", "")):
                    audit_event("account_admin_reauth_failed", auth["user"], b.get("id"), self, success=False)
                    return self.send_json({"error": "修改敏感账号资料前必须验证当前管理员密码。"}, 403)
                user = update_user_account(b.get("id"), b, True, auth["user"])
                audit_event("account_admin_update", auth["user"], user.get("id"), self,
                            {"fields": sorted(k for k in b if k not in ("password", "currentPassword"))})
                return self.send_json(public_user(user))
            if method == "DELETE":
                if not is_super(auth["user"]):
                    return self.send_json({"error": "只有总管理员可以删除账号。"}, 403)
                b = self.read_body()
                if b.get("id") == "admin":
                    raise ValueError("不能删除默认总管理员。")
                if not check_password(str(b.get("currentPassword") or ""), auth["user"].get("passwordHash", "")):
                    audit_event("user_delete_reauth_failed", auth["user"], b.get("id"), self, success=False)
                    return self.send_json({"error": "删除用户前必须验证当前管理员密码。"}, 403)
                security_backup(f"user-delete-{b.get('id')}", [USERS_PATH, SESSIONS_PATH, user_config_path(b.get("id"))])
                store["users"] = [u for u in store["users"] if u.get("id") != b.get("id")]
                write_users(store)
                revoke_user_sessions(b.get("id"))
                audit_event("user_delete", auth["user"], b.get("id"), self)
                return self.send_json({"ok": True})
        if path == "/api/super/invites/quote" and method == "POST":
            return self.send_json(invite_quote_for_actor(store, auth["user"], self.read_body()))
        if path == "/api/super/invites":
            if method == "GET":
                return self.send_json({"invites": store["inviteCodes"]})
            if method == "POST":
                b = self.read_body()
                result = create_invites_for_actor(store, auth["user"], b)
                if result.get("created"):
                    write_users(store)
                return self.send_json(result)
            if method == "PATCH":
                b = self.read_body()
                invite = next((x for x in store["inviteCodes"] if x.get("code") == b.get("code")), None)
                if not invite:
                    raise ValueError("邀请码不存在。")
                if "active" in b:
                    invite["active"] = bool(b.get("active"))
                if "maxUses" in b:
                    invite["maxUses"] = max(1, int(b.get("maxUses") or 1))
                if "retentionDays" in b:
                    invite["retentionDays"] = max(0, int(b.get("retentionDays") or 0))
                write_users(store)
                return self.send_json(invite)
            if method == "DELETE":
                b = self.read_body()
                codes = set(b.get("codes") or [])
                if not codes and b.get("code"):
                    codes.add(b.get("code"))
                store["inviteCodes"] = [x for x in store["inviteCodes"] if x.get("code") not in codes]
                write_users(store)
                return self.send_json({"ok": True})
        if path == "/api/super/mail":
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以操作。"}, 403)
            if method == "GET":
                return self.send_json(public_mail_settings())
            if method == "PATCH":
                write_mail_settings(self.read_body())
                return self.send_json(public_mail_settings())
        if path == "/api/super/mail/test" and method == "POST":
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以操作。"}, 403)
            body = self.read_body()
            email = (body.get("email") or "").strip()
            if not email:
                raise ValueError("请输入测试收件邮箱。")
            code = str(secrets.randbelow(900000) + 100000)
            if not send_reset_email(email, code):
                raise ValueError("SMTP 未配置完整或发送失败。")
            return self.send_json({"ok": True})
        if path == "/api/super/system":
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以操作。"}, 403)
            if method == "GET":
                return self.send_json(public_system_settings())
            if method == "PATCH":
                return self.send_json(write_system_settings(self.read_body()))
        if path == "/api/super/system/variant-cover" and method == "POST":
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有超级管理员可以上传工具箱封面。"}, 403)
            body = self.read_body()
            variant_id = str(body.get("variantId") or "").strip()
            if variant_id not in CLIENT_VARIANTS:
                return self.send_json({"error": "工具箱版本不存在。"}, 400)
            match = re.fullmatch(r"data:image/(png|jpeg|webp|gif|x-icon|vnd\.microsoft\.icon);base64,([A-Za-z0-9+/=\r\n]+)", str(body.get("dataUrl") or ""), re.I)
            if not match:
                return self.send_json({"error": "仅支持 PNG、JPG、WEBP、GIF 或 ICO 图片。"}, 400)
            try:
                image_data = base64.b64decode(match.group(2), validate=True)
            except Exception:
                return self.send_json({"error": "封面图片数据无效。"}, 400)
            if not image_data or len(image_data) > 5 * 1024 * 1024:
                return self.send_json({"error": "封面图片不能超过 5MB。"}, 400)
            extension = {"jpeg": "jpg", "x-icon": "ico", "vnd.microsoft.icon": "ico"}.get(match.group(1).lower(), match.group(1).lower())
            signatures = {
                "png": image_data.startswith(b"\x89PNG\r\n\x1a\n"),
                "jpg": image_data.startswith(b"\xff\xd8\xff"),
                "webp": image_data.startswith(b"RIFF") and image_data[8:12] == b"WEBP",
                "gif": image_data.startswith((b"GIF87a", b"GIF89a")),
                "ico": image_data.startswith(b"\x00\x00\x01\x00"),
            }
            if not signatures.get(extension, False):
                return self.send_json({"error": "图片内容与文件格式不匹配。"}, 400)
            VARIANT_COVER_DIR.mkdir(parents=True, exist_ok=True)
            file_name = f"{variant_id}-{int(time.time())}-{random_hex(4)}.{extension}"
            (VARIANT_COVER_DIR / file_name).write_bytes(image_data)
            return self.send_json({"url": f"/uploads/variant-covers/{file_name}"})
        if path in ("/api/super/system/menu-icon", "/api/admin/menu-icon/upload") and method == "POST":
            if path.startswith("/api/super/") and not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以上传全局菜单图标。"}, 403)
            body = self.read_body()
            match = re.fullmatch(r"data:image/(png|jpeg|webp|gif|x-icon|vnd\.microsoft\.icon);base64,([A-Za-z0-9+/=\r\n]+)", str(body.get("dataUrl") or ""), re.I)
            if not match:
                return self.send_json({"error": "仅支持 PNG、JPG、WEBP、GIF 或 ICO 图片。"}, 400)
            try:
                image_data = base64.b64decode(match.group(2), validate=True)
            except Exception:
                return self.send_json({"error": "图标图片数据无效。"}, 400)
            if not image_data or len(image_data) > 2 * 1024 * 1024:
                return self.send_json({"error": "图标图片不能超过 2MB。"}, 400)
            extension = {"jpeg": "jpg", "x-icon": "ico", "vnd.microsoft.icon": "ico"}.get(match.group(1).lower(), match.group(1).lower())
            signatures = {
                "png": image_data.startswith(b"\x89PNG\r\n\x1a\n"),
                "jpg": image_data.startswith(b"\xff\xd8\xff"),
                "webp": image_data.startswith(b"RIFF") and image_data[8:12] == b"WEBP",
                "gif": image_data.startswith((b"GIF87a", b"GIF89a")),
                "ico": image_data.startswith(b"\x00\x00\x01\x00"),
            }
            if not signatures.get(extension, False):
                return self.send_json({"error": "图片内容与文件格式不匹配。"}, 400)
            MENU_ICON_DIR.mkdir(parents=True, exist_ok=True)
            owner = "global" if path.startswith("/api/super/") else re.sub(r"[^a-zA-Z0-9_-]", "", str(user_id))
            file_name = f"{owner}-{int(time.time())}-{random_hex(4)}.{extension}"
            (MENU_ICON_DIR / file_name).write_bytes(image_data)
            return self.send_json({"url": f"/uploads/menu-icons/{file_name}"})
        if path == "/api/super/system/popup/upload" and method == "POST":
            return self.send_json({"error": "联系方式图片只支持图床或外链图片地址，不能本地上传。"}, 400)
        if path == "/api/super/orders":
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以操作。"}, 403)
            data = read_orders()
            if method == "GET":
                return self.send_json({"orders": [public_order(order) for order in data.get("orders", [])[:200]]})
            if method == "PATCH":
                body = self.read_body()
                order = next((x for x in data.get("orders", []) if x.get("id") == body.get("id")), None)
                if not order:
                    raise ValueError("订单不存在。")
                status = body.get("status") or "pending"
                if status not in ("pending", "paid", "done", "cancelled"):
                    raise ValueError("不支持的订单状态。")
                order["status"] = status
                order["updatedAt"] = now_iso()
                write_orders(data)
                return self.send_json(public_order(order))
            if method == "DELETE":
                body = self.read_body()
                ids = {str(x).strip() for x in (body.get("ids") or []) if str(x).strip()}
                order_id = str(body.get("id") or "").strip()
                if order_id:
                    ids.add(order_id)
                if not ids:
                    raise ValueError("请选择要删除的订单。")
                before = len(data.get("orders", []))
                data["orders"] = [x for x in data.get("orders", []) if x.get("id") not in ids]
                deleted = before - len(data.get("orders", []))
                if deleted <= 0:
                    raise ValueError("订单不存在。")
                write_orders(data)
                return self.send_json({"ok": True, "deleted": deleted})
        return self.send_json({"error": "接口不存在"}, 404)

    def handle_admin(self, path, method, auth):
        user_id = target_user_id(auth, self)
        if path.startswith("/api/admin/announcements"):
            return self.handle_admin_announcements(path, method, auth)
        if path == "/api/admin/me" and method == "GET":
            return self.send_json({"user": public_user(auth["user"]), "targetUser": public_user(find_user_by_id(user_id))})
        if path == "/api/admin/notices":
            data = read_notices()
            if method == "GET":
                notices = [n for n in data.get("notices", []) if notice_visible_to_user(n, auth["user"])]
                return self.send_json({"notices": [public_notice(n, auth["user"]["id"]) for n in notices[:80]]})
            if method == "POST":
                if not is_super(auth["user"]):
                    return self.send_json({"error": "只有总管理员可以发送通知。"}, 403)
                body = self.read_body()
                title = (body.get("title") or "").strip()
                content = (body.get("content") or "").strip()
                if not title and not content:
                    raise ValueError("通知内容不能为空。")
                notice = {
                    "id": new_id("notice"),
                    "title": title or "通知",
                    "content": content,
                    "level": body.get("level") or "info",
                    "active": True,
                    "createdAt": now_iso(),
                    "createdBy": auth["user"].get("username"),
                    "createdByName": user_display_name(auth["user"]),
                    "createdById": auth["user"].get("id"),
                    "readBy": [],
                }
                data["notices"].insert(0, notice)
                write_notices(data)
                response = public_notice(notice, auth["user"]["id"])
                if body.get("mailPush"):
                    store = read_users()
                    recipients = [u for u in store.get("users", []) if (u.get("email") or "").strip() and notice_visible_to_user(notice, u)]
                    ok, message = send_notice_mail_to_users(notice, recipients)
                    if not ok:
                        return self.send_json({"error": f"通知已保存，但邮件发送失败：{message}"}, 400)
                    response["mailMessage"] = f"通知已发送，{message}"
                return self.send_json(response)
            if method == "PATCH":
                body = self.read_body()
                notice = next((n for n in data.get("notices", []) if n.get("id") == body.get("id")), None)
                if not notice:
                    raise ValueError("通知不存在。")
                if body.get("read"):
                    notice.setdefault("readBy", [])
                    if auth["user"]["id"] not in notice["readBy"]:
                        notice["readBy"].append(auth["user"]["id"])
                if body.get("hide") and (is_super(auth["user"]) or notice.get("createdById") == auth["user"].get("id")):
                    notice["active"] = False
                write_notices(data)
                return self.send_json(public_notice(notice, auth["user"]["id"]))
            if method == "DELETE":
                if not is_super(auth["user"]):
                    return self.send_json({"error": "只有总管理员可以删除所有通知。"}, 403)
                body = self.read_body()
                notice_id = (body.get("id") or "").strip()
                if notice_id:
                    before = len(data.get("notices", []))
                    data["notices"] = [n for n in data.get("notices", []) if n.get("id") != notice_id]
                    write_notices(data)
                    return self.send_json({"ok": True, "deleted": before - len(data.get("notices", []))})
                write_notices({"notices": [], "reads": {}})
                return self.send_json({"ok": True, "deleted": True})
        if path == "/api/admin/notices/mail" and method == "POST":
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以邮箱推送通知。"}, 403)
            body = self.read_body()
            notice_id = (body.get("id") or "").strip()
            data = read_notices()
            notice = next((n for n in data.get("notices", []) if n.get("id") == notice_id and n.get("active", True) is not False), None)
            if not notice:
                raise ValueError("通知不存在。")
            store = read_users()
            recipients = [u for u in store.get("users", []) if (u.get("email") or "").strip() and notice_visible_to_user(notice, u)]
            ok, message = send_notice_mail_to_users(notice, recipients)
            if not ok:
                return self.send_json({"error": f"邮件发送失败：{message}"}, 400)
            return self.send_json({"ok": True, "message": message})
        if path == "/api/admin/account" and method == "PATCH":
            b = self.read_body()
            old_email = (auth["user"].get("email") or "").strip().lower()
            new_email = (b.get("email") or old_email).strip().lower()
            if (b.get("password") or new_email != old_email) and not check_password(str(b.get("currentPassword") or ""), auth["user"].get("passwordHash", "")):
                return self.send_json({"error": "当前密码不正确。"}, 400)
            user = update_user_account(auth["user"]["id"], b, False)
            audit_event("account_self_update", auth["user"], auth["user"]["id"], self,
                        {"emailChanged": new_email != old_email, "passwordChanged": bool(b.get("password"))})
            return self.send_json({"user": public_user(user)})
        if path == "/api/admin/desktop/download" and method == "GET":
            if not is_super(auth["user"]):
                return self.send_json({"error": "只有总管理员可以下载后台 EXE。"}, 403)
            name, data = make_admin_desktop_exe(self.base_url())
            if not is_windows_exe(data):
                return self.send_json({"error": "后台 EXE 生成结果无效，请检查服务器编译环境。"}, 500)
            return self.send_bytes(data, "application/vnd.microsoft.portable-executable", filename=name)
        if path == "/api/admin/client/variants" and method == "GET":
            return self.send_json(public_client_variants())
        if path == "/api/admin/menu-icons" and method == "GET":
            settings = read_system_settings()
            icons = list(settings.get("menuIcons") or [])
            folders = list(settings.get("menuIconFolders") or [{"id": "default", "name": "默认", "sort": 0}])
            return self.send_json({"icons": icons, "folders": folders, "libraryError": ""})
        if path == "/api/admin/client/download" and method == "GET":
            variant = request_client_variant(self)
            name, data = make_client_exe(find_user_by_id(user_id), self.base_url(), variant)
            if not is_windows_exe(data):
                return self.send_json({"error": "EXE 生成结果无效，请清理缓存后重试。"}, 500)
            if not is_super(auth["user"]):
                record_client_download(variant)
            return self.send_bytes(data, "application/vnd.microsoft.portable-executable", filename=name)
        if path == "/api/admin/client/build" and method == "POST":
            body = self.read_body()
            user = find_user_by_id(user_id)
            if not user:
                return self.send_json({"error": "目标用户不存在。"}, 404)
            return self.send_json(start_client_build_job(user, self.base_url(), request_client_variant(self, body)))
        if path == "/api/admin/client/build/status" and method == "GET":
            job_id = self.query.get("id", [""])[0]
            job = public_client_build_job(job_id)
            if not job:
                return self.send_json({"error": "生成任务不存在。"}, 404)
            return self.send_json(job)
        if path == "/api/admin/client/build/file" and method == "GET":
            cleanup_client_build_artifacts()
            job_id = self.query.get("id", [""])[0]
            with CLIENT_BUILD_LOCK:
                job = dict(CLIENT_BUILD_JOBS.get(job_id) or {})
            if not job:
                return self.send_json({"error": "生成任务不存在。"}, 404)
            if job.get("status") != "done":
                return self.send_json({"error": "生成任务还未完成。"}, 409)
            file_path = Path(job.get("path") or "")
            if not file_path.exists():
                return self.send_json({"error": "生成文件不存在。"}, 404)
            data = file_path.read_bytes()
            if not is_windows_exe(data):
                return self.send_json({"error": "生成文件不是有效 EXE，请重新生成。"}, 500)
            record_client_build_download(job_id, auth["user"])
            return self.send_bytes(data, "application/vnd.microsoft.portable-executable", filename=job.get("fileName") or "toolbox.exe")
        if path == "/api/admin/config/export" and method == "GET":
            user = find_user_by_id(user_id) or auth["user"]
            package = config_export_package(read_config(user_id), user, self.base_url())
            data = json.dumps(package, ensure_ascii=False, indent=2).encode("utf-8")
            filename = f"toolbox-config-{ascii_file_name_part(user_display_name(user) or user_id, 'user')}-{int(time.time())}.json"
            return self.send_bytes(data, "application/json; charset=utf-8", filename=filename)
        if path == "/api/admin/config/share" and method == "POST":
            if is_super(auth["user"]) and user_id != auth["user"].get("id"):
                target = find_user_by_id(user_id)
                if not target:
                    return self.send_json({"error": "目标用户不存在。"}, 404)
            share = create_config_share(read_config(user_id), find_user_by_id(user_id) or auth["user"], self.base_url())
            return self.send_json(share)
        if path == "/api/admin/config/import" and method == "POST":
            body = self.read_body()
            source = (body.get("source") or "").strip().lower()
            if source == "url":
                payload = fetch_remote_config_payload(body.get("url") or body.get("shareUrl") or "")
            else:
                payload = body.get("payload") if "payload" in body else body
            cfg = normalize_import_config(payload)
            write_config_for_actor(cfg, user_id, auth["user"])
            return self.send_json({"ok": True, "summary": config_summary(cfg), "config": read_config(user_id)})
        if path == "/api/admin/config":
            if method == "GET":
                return self.send_json(read_config(user_id))
            if method == "PUT":
                write_config_for_actor(self.read_body(), user_id, auth["user"])
                return self.send_json(read_config(user_id))
        if path == "/api/admin/app" and method == "PATCH":
            patch = self.read_body()
            if auth["user"].get("role") != "super":
                for key in ("admin_title", "login_hint"):
                    patch.pop(key, None)
            cfg = read_config(user_id)
            before = json_clone(cfg)
            public_patch = apply_basic_settings_patch(cfg, patch)
            write_config_for_actor(cfg, user_id, auth["user"])
            if auth["user"].get("role") == "super" and should_sync_default_config(auth["user"], user_id):
                sync_public_brand_config(public_patch)
            details = basic_settings_audit_details(before, cfg, patch, path)
            if details["changes"]:
                audit_event("config_basic_update", auth["user"], user_id, self, details)
            return self.send_json(cfg)
        if path == "/api/admin/popup" and method == "PATCH":
            cfg = read_config(user_id)
            before_popup = json_clone(cfg.get("popup") or {})
            merged = dict(cfg.get("popup") or {})
            merged.update(self.read_body())
            cfg["popup"] = normalize_popup_settings(merged)
            write_config_for_actor(cfg, user_id, auth["user"])
            details = popup_settings_audit_details(before_popup, cfg["popup"], path)
            if details["changes"]:
                audit_event("contact_settings_update", auth["user"], user_id, self, details)
            return self.send_json(cfg)
        if path == "/api/admin/buttons":
            cfg = read_config(user_id)
            if method == "GET":
                rows, changed = button_rows(cfg)
                if changed:
                    write_config_for_actor(cfg, user_id, auth["user"])
                return self.send_json(rows)
            body = self.read_body()
            before_row = find_button_audit_row(cfg, body)
            operation = "update"
            if method == "POST":
                container = get_container(cfg, body)
                sections = container.setdefault("sections", [])
                while len(sections) <= int(body.get("sectionIndex", 0)):
                    sections.append({"title": "默认分组", "buttons": []})
                payload = dict(body.get("button") or body)
                created = new_button(payload)
                sections[int(body.get("sectionIndex", 0))].setdefault("buttons", []).append(created)
                body["id"] = created.get("id")
                operation = "create"
            elif method == "PATCH":
                updated = update_button(cfg, body)
                body["id"] = updated.get("id")
            elif method == "DELETE":
                section, button_index = find_button_slot(cfg, body)
                if (section["buttons"][button_index] or {}).get("action") == "script":
                    return self.send_json({"error": "内置功能不能删除，请改为停用。"}, 400)
                del section["buttons"][button_index]
                operation = "delete"
            write_config_for_actor(cfg, user_id, auth["user"])
            rows, changed = button_rows(cfg)
            if changed:
                write_config_for_actor(cfg, user_id, auth["user"])
            after_row = None if operation == "delete" else find_button_audit_row(cfg, body)
            details = button_audit_details(operation, before_row, after_row, path)
            if details["changes"]:
                audit_event("button_" + operation, auth["user"], user_id, self, details)
            return self.send_json(rows)
        if path == "/api/admin/builtin-functions" and method == "GET":
            return self.send_json({"functions": builtin_function_rows(is_super(auth["user"]))})
        return self.send_json({"error": "接口不存在"}, 404)

    def handle_admin_announcements(self, path, method, auth):
        user = auth["user"]
        user_id = user.get("id")
        match = re.fullmatch(r"/api/admin/announcements/([^/]+)(?:/(publish|withdraw|read))?", path)
        with ADMIN_ANNOUNCEMENT_LOCK:
            store = read_admin_announcements()
            reads_store = read_admin_announcement_reads()
            rows = store["announcements"]
            reads = reads_store["reads"]

            if path in ("/api/admin/announcements", "/api/admin/announcements/unread") and method == "GET":
                visible = rows if is_super(user) else [item for item in rows if announcement_is_available(item)]
                public_rows = [public_admin_announcement(item, user_id, reads) for item in visible]
                public_rows.sort(key=lambda item: item.get("publish_time") or item.get("updated_time") or "", reverse=True)
                if path.endswith("/unread"):
                    public_rows = [item for item in public_rows if announcement_is_available(item) and not item.get("read")]
                return self.send_json({
                    "announcements": public_rows,
                    "unreadCount": sum(1 for item in public_rows if not item.get("read") and announcement_is_available(item)),
                    "isSuper": is_super(user),
                })

            if path == "/api/admin/announcements" and method == "POST":
                if not is_super(user):
                    return self.send_json({"error": "只有总管理员可以新建公告。"}, 403)
                body = self.read_body()
                item = normalize_announcement_payload(body)
                if not item["title"] or not item["content"]:
                    return self.send_json({"error": "公告标题和更新内容不能为空。"}, 400)
                timestamp = now_iso()
                item.update({
                    "id": new_id("announcement"), "status": "draft", "publish_time": "",
                    "created_time": timestamp, "updated_time": timestamp,
                    "author": user.get("username"), "notification_revision": 1,
                })
                rows.insert(0, item)
                write_json(ADMIN_ANNOUNCEMENTS_PATH, store)
                return self.send_json(public_admin_announcement(item, user_id, reads), 201)

            if path == "/api/admin/announcements/read-batch" and method == "POST":
                body = self.read_body()
                references = body.get("announcements") if isinstance(body, dict) else []
                if not isinstance(references, list):
                    return self.send_json({"error": "公告已读参数格式错误。"}, 400)
                marked = mark_admin_announcement_batch_read(rows, reads, user, references)
                if marked:
                    write_json(ADMIN_ANNOUNCEMENT_READS_PATH, reads_store)
                return self.send_json({"ok": True, "marked": marked})

            if path == "/api/admin/announcements/read-all" and method == "POST":
                for item in rows:
                    if announcement_is_available(item):
                        revision = int(item.get("notification_revision") or 1)
                        if not announcement_read_record(reads, item.get("id"), user_id, revision):
                            reads.append({"announcement_id": item.get("id"), "user_id": user_id, "username": user.get("username"), "read_time": now_iso(), "notification_revision": revision})
                write_json(ADMIN_ANNOUNCEMENT_READS_PATH, reads_store)
                return self.send_json({"ok": True})

            if not match:
                return self.send_json({"error": "公告接口不存在。"}, 404)
            announcement_id, action = match.groups()
            item = next((entry for entry in rows if entry.get("id") == announcement_id), None)
            if not item:
                return self.send_json({"error": "公告不存在。"}, 404)

            if method == "GET" and not action:
                if not is_super(user) and not announcement_is_available(item):
                    return self.send_json({"error": "公告不存在。"}, 404)
                return self.send_json(public_admin_announcement(item, user_id, reads))

            if method == "POST" and action == "read":
                if not is_super(user) and not announcement_is_available(item):
                    return self.send_json({"error": "公告不存在。"}, 404)
                revision = int(item.get("notification_revision") or 1)
                if not announcement_read_record(reads, announcement_id, user_id, revision):
                    reads.append({"announcement_id": announcement_id, "user_id": user_id, "username": user.get("username"), "read_time": now_iso(), "notification_revision": revision})
                    write_json(ADMIN_ANNOUNCEMENT_READS_PATH, reads_store)
                return self.send_json({"ok": True})

            if not is_super(user):
                return self.send_json({"error": "只有总管理员可以修改公告。"}, 403)

            if method == "PUT" and not action:
                body = self.read_body()
                was_published = item.get("status") == "published"
                updated = normalize_announcement_payload(body, item)
                if not updated["title"] or not updated["content"]:
                    return self.send_json({"error": "公告标题和更新内容不能为空。"}, 400)
                if was_published and body.get("renotify"):
                    updated["notification_revision"] = int(item.get("notification_revision") or 1) + 1
                updated["updated_time"] = now_iso()
                item.clear()
                item.update(updated)
                write_json(ADMIN_ANNOUNCEMENTS_PATH, store)
                return self.send_json(public_admin_announcement(item, user_id, reads))

            if method == "DELETE" and not action:
                store["announcements"] = [entry for entry in rows if entry.get("id") != announcement_id]
                write_json(ADMIN_ANNOUNCEMENTS_PATH, store)
                reads_store["reads"] = [entry for entry in reads if entry.get("announcement_id") != announcement_id]
                write_json(ADMIN_ANNOUNCEMENT_READS_PATH, reads_store)
                return self.send_json({"ok": True})

            if method == "POST" and action == "publish":
                if not item.get("title") or not item.get("content"):
                    return self.send_json({"error": "公告标题和更新内容不能为空。"}, 400)
                body = self.read_body()
                item["status"] = "published"
                item["enabled"] = True
                item["publish_time"] = clean_announcement_text(body.get("publish_time"), 50) or now_iso()
                item["updated_time"] = now_iso()
                if body.get("renotify"):
                    item["notification_revision"] = int(item.get("notification_revision") or 1) + 1
                write_json(ADMIN_ANNOUNCEMENTS_PATH, store)
                return self.send_json(public_admin_announcement(item, user_id, reads))

            if method == "POST" and action == "withdraw":
                item["status"] = "withdrawn"
                item["updated_time"] = now_iso()
                write_json(ADMIN_ANNOUNCEMENTS_PATH, store)
                return self.send_json(public_admin_announcement(item, user_id, reads))

        return self.send_json({"error": "不支持的公告操作。"}, 405)

    def base_url(self):
        proto = self.headers.get("X-Forwarded-Proto") or self.headers.get("X-Forwarded-Scheme") or "http"
        if "," in proto:
            proto = proto.split(",", 1)[0].strip()
        host = self.headers.get("Host") or "localhost:5088"
        return normalize_public_base_url(f"{proto}://{host}")

    def serve_static(self, path):
        rel = path.strip("/") or "index.html"
        file_path = (WWW / rel).resolve()
        if not str(file_path).startswith(str(WWW.resolve())) or not file_path.exists() or not file_path.is_file():
            return self.send_json({"error": "接口不存在"}, 404)
        ctype = "image/x-icon" if file_path.suffix.lower() == ".ico" else (mimetypes.guess_type(str(file_path))[0] or "application/octet-stream")
        if ctype.startswith("text/") or file_path.suffix in (".js", ".json"):
            ctype += "; charset=utf-8"
        return self.send_bytes(file_path.read_bytes(), ctype)


if __name__ == "__main__":
    ensure_admin_announcement_files()
    read_users()
    threading.Thread(target=run_client_build_cleanup_loop, daemon=True).start()
    host = os.environ.get("TOOLBOX_HOST", "127.0.0.1")
    port = int(os.environ.get("TOOLBOX_PORT", "5088"))
    print(f"Toolbox admin API started: http://{host}:{port}/", flush=True)
    ThreadingHTTPServer((host, port), Handler).serve_forever()
