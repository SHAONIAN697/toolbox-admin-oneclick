#!/usr/bin/env bash
set -euo pipefail

APP_NAME="toolbox-admin"
DEFAULT_PORT="5088"

red() { printf "\033[31m%s\033[0m\n" "$*"; }
green() { printf "\033[32m%s\033[0m\n" "$*"; }
yellow() { printf "\033[33m%s\033[0m\n" "$*"; }

need_root() {
  if [ "$(id -u)" != "0" ]; then
    red "请使用 root 用户执行：sudo bash install-baota.sh"
    exit 1
  fi
}

ask() {
  local prompt="$1"
  local default="$2"
  local value
  read -r -p "$prompt [$default]: " value || true
  printf "%s" "${value:-$default}"
}

random_password() {
  if command -v openssl >/dev/null 2>&1; then
    openssl rand -base64 18 | tr -d '=+/[:space:]' | cut -c1-18
  else
    date +%s%N | sha256sum | cut -c1-18
  fi
}

service_file() {
  printf "/etc/systemd/system/%s.service" "$APP_NAME"
}

detect_service_workdir() {
  local file
  file="$(service_file)"
  [ -f "$file" ] || return 0
  grep -E "^WorkingDirectory=" "$file" | tail -n 1 | sed 's/^WorkingDirectory=//; s/^"//; s/"$//'
}

detect_service_env() {
  local key="$1"
  local file
  file="$(service_file)"
  [ -f "$file" ] || return 0
  grep -E "^Environment=${key}=" "$file" | tail -n 1 | sed "s/^Environment=${key}=//; s/^\"//; s/\"$//"
}

show_status() {
  local app_dir port state pid enabled active_since config announcements
  app_dir="$(detect_service_workdir || true)"
  port="$(detect_service_env TOOLBOX_PORT || true)"
  state="未安装"
  pid="-"
  enabled="未配置"
  active_since="-"
  if command -v systemctl >/dev/null 2>&1 && systemctl is-active --quiet "$APP_NAME"; then
    state="运行中"
    pid="$(systemctl show -p MainPID --value "$APP_NAME" 2>/dev/null || true)"
    active_since="$(systemctl show -p ActiveEnterTimestamp --value "$APP_NAME" 2>/dev/null || true)"
    [ -z "$pid" ] && pid="-"
    [ -z "$active_since" ] && active_since="-"
  elif [ -f "$(service_file)" ]; then
    state="已安装，未运行"
  fi
  if command -v systemctl >/dev/null 2>&1 && systemctl is-enabled --quiet "$APP_NAME" 2>/dev/null; then
    enabled="已启用"
  elif [ -f "$(service_file)" ]; then
    enabled="未启用"
  fi
  [ -z "$port" ] && port="$DEFAULT_PORT"
  config="未找到"
  announcements="未找到"
  if [ -n "$app_dir" ]; then
    config="$app_dir/data/config.json"
    announcements="$app_dir/data/admin-announcements.json"
    [ -f "$config" ] && config="$config（正常）" || config="$config（未找到）"
    [ -f "$announcements" ] && announcements="$announcements（正常）" || announcements="$announcements（未找到）"
  fi
  echo
  printf '%s\n' '============================================================'
  printf '工具箱后台状态\n'
  printf '%s\n' '============================================================'
  printf '服务名称：%s\n' "$APP_NAME"
  printf '运行状态：%s\n' "$state"
  printf '开机自启：%s\n' "$enabled"
  printf '进程 PID：%s\n' "$pid"
  printf '监听端口：%s\n' "$port"
  printf '运行时间：%s\n' "$active_since"
  printf '安装目录：%s\n' "${app_dir:-未找到}"
  printf '数据目录：%s\n' "${app_dir:+$app_dir/data}"
  printf '配置文件：%s\n' "$config"
  printf '公告文件：%s\n' "$announcements"
  printf '服务文件：%s\n' "$(service_file)"
  printf '日志查看：journalctl -u %s -n 50 --no-pager\n' "$APP_NAME"
  if [ -n "$app_dir" ]; then
    printf '访问地址：http://127.0.0.1:%s\n' "$port"
  fi
  printf '%s\n\n' '============================================================'
}

install_deps() {
  yellow "正在安装运行依赖：python3、Mono/C# 编译器..."
  if command -v apt >/dev/null 2>&1; then
    apt update
    DEBIAN_FRONTEND=noninteractive apt install -y python3 ca-certificates curl gnupg
    if ! command -v mcs >/dev/null 2>&1 && ! command -v csc >/dev/null 2>&1; then
      DEBIAN_FRONTEND=noninteractive apt install -y mono-devel || true
    fi
  elif command -v dnf >/dev/null 2>&1; then
    dnf install -y python3 ca-certificates curl
    if ! command -v mcs >/dev/null 2>&1 && ! command -v csc >/dev/null 2>&1; then
      dnf install -y mono-devel || dnf install -y mono-complete || true
    fi
  elif command -v yum >/dev/null 2>&1; then
    yum install -y python3 ca-certificates curl
    if ! command -v mcs >/dev/null 2>&1 && ! command -v csc >/dev/null 2>&1; then
      yum install -y mono-devel || yum install -y mono-complete || true
    fi
  else
    red "未识别包管理器，请手动安装 python3 和 mono-devel 后重试。"
    exit 1
  fi

  if command -v mcs >/dev/null 2>&1 || command -v csc >/dev/null 2>&1; then
    green "已检测到 C# 编译器，支持后台在线生成工具箱 EXE。"
  else
    yellow "未能自动安装 C# 编译器。后台可以运行，但下载 EXE 前请手动安装 mono-devel/mono-complete 后重启 ${APP_NAME}。"
  fi
}

read_admin_accounts() {
  local app_dir="$1"
  python3 - "$app_dir" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1]) / "data/users.json"
try:
    data = json.loads(path.read_text(encoding="utf-8"))
except (OSError, ValueError, TypeError):
    raise SystemExit(0)

accounts = []
for user in data.get("users", []):
    if not isinstance(user, dict):
        continue
    if user.get("role") != "super" or user.get("active", True) is False:
        continue
    username = str(user.get("username") or "").strip()
    if username:
        accounts.append(username)
print("、".join(accounts))
PY
}

validate_admin_username() {
  [[ "$1" =~ ^[A-Za-z0-9._@+-]{1,64}$ ]]
}
copy_source() {
  local src_dir="$1"
  local app_dir="$2"

  mkdir -p "$app_dir"

  if [ -d "$app_dir/data" ]; then
    local stamp="$(date +%Y%m%d%H%M%S)"
    local bak="$app_dir/data.bak.$stamp"
    local full_bak="${app_dir%/*}/$(basename "$app_dir").full.bak.$stamp.tar.gz"
    yellow "检测到已有 data 数据目录，生成数据备份：$bak"
    cp -a "$app_dir/data" "$bak"
    yellow "生成完整站点备份（跳过可重新生成的缓存，最多等待 120 秒）：$full_bak"
    # data 已经单独复制，client-cache/client-jobs 可能包含大型 EXE 和临时文件，
    # 不应让 gzip 长时间占住更新流程；失败时保留 data 备份并继续更新。
    local backup_parent="$(dirname "$app_dir")"
    local backup_name="$(basename "$app_dir")"
    local tar_status=0
    set +e
    if command -v timeout >/dev/null 2>&1; then
      timeout --signal=TERM --kill-after=10s 120s tar --exclude="$backup_name/data/client-cache" --exclude="$backup_name/data/client-jobs" --exclude="$backup_name/wwwroot/uploads" -czf "$full_bak" -C "$backup_parent" "$backup_name"
      tar_status=$?
    else
      tar --exclude="$backup_name/data/client-cache" --exclude="$backup_name/data/client-jobs" --exclude="$backup_name/wwwroot/uploads" -czf "$full_bak" -C "$backup_parent" "$backup_name"
      tar_status=$?
    fi
    set -e
    if [ "$tar_status" -eq 0 ]; then
      green "更新前已完成两份备份：完整站点 + data 数据目录"
    else
      rm -f "$full_bak"
      yellow "完整站点备份超时或失败，已保留 data 数据备份，继续更新程序。"
    fi
  fi

  yellow "正在复制程序文件到：$app_dir"
  cp -a "$src_dir/app.py" "$app_dir/"
  cp -a "$src_dir/assets" "$app_dir/"
  cp -a "$src_dir/client-template" "$app_dir/"
  cp -a "$src_dir/wwwroot" "$app_dir/"
  cp -a "$src_dir/admin-desktop-template" "$app_dir/" 2>/dev/null || true
  cp -a "$src_dir/deploy" "$app_dir/" 2>/dev/null || true
  cp -a "$src_dir/README.md" "$app_dir/" 2>/dev/null || true
  cp -a "$src_dir/DOCKING.md" "$app_dir/" 2>/dev/null || true
  cp -a "$src_dir/宝塔部署教程.md" "$app_dir/" 2>/dev/null || true
  cp -a "$src_dir/使用教程-录屏版.md" "$app_dir/" 2>/dev/null || true

  if [ ! -d "$app_dir/data" ]; then
    cp -a "$src_dir/data" "$app_dir/"
  fi

  mkdir -p "$app_dir/data" "$app_dir/data/users" "$app_dir/data/client-cache" "$app_dir/data/client-jobs" "$app_dir/data/icon-cache"
}

write_service() {
  local app_dir="$1"
  local port="$2"
  local password="$3"
  local username="$4"
  local service_file="/etc/systemd/system/${APP_NAME}.service"

  yellow "正在创建 systemd 服务..."
  if [ -e "$service_file" ]; then
    command -v chattr >/dev/null 2>&1 && chattr -i -a "$service_file" 2>/dev/null || true
    chmod u+w "$service_file" 2>/dev/null || true
  fi
  cat >"$service_file" <<EOF
[Unit]
Description=Toolbox Admin API
After=network.target
StartLimitIntervalSec=60
StartLimitBurst=5

[Service]
Type=simple
WorkingDirectory=${app_dir}
Environment=TOOLBOX_HOST=127.0.0.1
Environment=TOOLBOX_PORT=${port}
Environment=TOOLBOX_ADMIN_TOKEN=${password}
Environment=TOOLBOX_ADMIN_USERNAME=${username}
ExecStart=/usr/bin/python3 ${app_dir}/app.py
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

  systemctl daemon-reload
  systemctl enable ${APP_NAME} >/dev/null
  systemctl restart ${APP_NAME}
}

patch_nginx() {
  local domain="$1"
  local port="$2"
  local conf="/www/server/panel/vhost/nginx/${domain}.conf"
  local marker_begin="# toolbox-admin one-click begin"
  local marker_end="# toolbox-admin one-click end"

  if [ ! -f "$conf" ]; then
    yellow "未找到宝塔 Nginx 站点配置：$conf"
    yellow "请在宝塔里添加网站 ${domain} 后，再运行一次本脚本。"
    return 1
  fi

  local backup="${conf}.bak.$(date +%Y%m%d%H%M%S)"
  cp -a "$conf" "$backup"

  python3 - "$conf" "$port" "$marker_begin" "$marker_end" <<'PY'
from pathlib import Path
import re
import sys

path = Path(sys.argv[1])
port = sys.argv[2]
begin = sys.argv[3]
end = sys.argv[4]
text = path.read_text(encoding="utf-8", errors="ignore")

block = f"""
    {begin}
    location = /api {{
        return 308 /api/;
    }}

    location ^~ /api/ {{
        proxy_pass http://127.0.0.1:{port};
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header Authorization $http_authorization;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 300s;
        proxy_send_timeout 300s;
        proxy_buffering off;
        expires off;
        add_header Cache-Control "no-store, no-cache, must-revalidate, max-age=0" always;
    }}

    location / {{
        proxy_pass http://127.0.0.1:{port};
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header Authorization $http_authorization;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }}
    {end}
"""

text = re.sub(r"\n\s*# toolbox-admin one-click begin.*?# toolbox-admin one-click end\s*\n", "\n", text, flags=re.S)

def remove_location_blocks(src):
    out = []
    i = 0
    n = len(src)
    loc_re = re.compile(r"(?m)^[ \t]*location[ \t]+(?:=[ \t]+|\^~[ \t]+|~\*?[ \t]+)?(/api(?:/|\b)[^\s{]*|/(?=\s|\{))[^{]*\{")
    while i < n:
        m = loc_re.search(src, i)
        if not m:
            out.append(src[i:])
            break
        out.append(src[i:m.start()])
        depth = 0
        j = m.end() - 1
        while j < n:
            ch = src[j]
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    while j < n and src[j] in " \t\r\n":
                        j += 1
                    break
            j += 1
        i = j
    return "".join(out)

text = remove_location_blocks(text)
idx = text.rfind("\n}")
if idx == -1:
    raise SystemExit("无法定位 Nginx server 结束位置")
text = text[:idx] + "\n" + block + text[idx:]
path.write_text(text, encoding="utf-8")
PY

  if nginx -t; then
    systemctl reload nginx || service nginx reload
    green "Nginx 反向代理已自动配置。"
    return 0
  fi

  cp -a "$backup" "$conf"
  nginx -t >/dev/null 2>&1 && (systemctl reload nginx || service nginx reload) >/dev/null 2>&1 || true
  red "Nginx 配置检测失败，已自动恢复原配置。"
  yellow "请在宝塔面板手动添加反向代理：http://127.0.0.1:${port}"
  return 1
}

main() {
  if [ "${1:-}" = "status" ] || [ "${1:-}" = "状态" ]; then
    need_root
    show_status
    exit 0
  fi
  need_root

  local script_dir
  script_dir="$(cd "$(dirname "$0")" && pwd)"

  if [ ! -f "$script_dir/app.py" ]; then
    red "请先解压源码包，并在源码目录里执行：bash install-baota.sh"
    exit 1
  fi

  echo
  green "=== 梳理工具箱一键部署脚本 ==="
  echo

  local existing_app_dir
  existing_app_dir="$(detect_service_workdir || true)"
  local existing_port
  existing_port="$(detect_service_env TOOLBOX_PORT || true)"
  local existing_token
  existing_token="$(detect_service_env TOOLBOX_ADMIN_TOKEN || true)"
  local existing_username
  existing_username="$(detect_service_env TOOLBOX_ADMIN_USERNAME || true)"

  if [ -n "$existing_app_dir" ] && [ -d "$existing_app_dir/data" ]; then
    yellow "检测到已部署目录：$existing_app_dir"
    yellow "本次默认按更新模式执行，保留账号密码、后台配置和用户数据。"
    echo
  fi

  local default_domain="gjx.vst76.cn"
  if [ -n "$existing_app_dir" ]; then
    default_domain="$(basename "$existing_app_dir")"
  fi
  local domain
  domain="$(ask "请输入绑定的域名" "$default_domain")"
  local default_app_dir="/www/wwwroot/${domain}"
  if [ -n "$existing_app_dir" ]; then
    default_app_dir="$existing_app_dir"
  fi
  local app_dir
  app_dir="$(ask "请输入安装目录" "$default_app_dir")"
  if [ -n "$existing_app_dir" ] && [ -d "$existing_app_dir/data" ] && [ "$app_dir" != "$existing_app_dir" ]; then
    yellow "检测到原部署目录已有 data 数据，为避免更新后账号和配置丢失，自动使用原安装目录：$existing_app_dir"
    app_dir="$existing_app_dir"
  fi
  local default_port="$DEFAULT_PORT"
  if [ -n "$existing_port" ]; then
    default_port="$existing_port"
  fi
  local port
  port="$(ask "请输入本机服务端口" "$default_port")"
  local is_update="0"
  if [ -f "$app_dir/data/users.json" ]; then
    is_update="1"
  fi
  local password
  local admin_username
  if [ "$is_update" = "1" ]; then
    password="${existing_token:-$(random_password)}"
    admin_username="${existing_username:-admin}"
    yellow "已进入更新模式：后台账号、密码、用户列表、邀请码和工具箱配置都会保留。"
  else
    while true; do
      admin_username="$(ask "请输入后台管理员账号" "admin")"
      if validate_admin_username "$admin_username"; then
        break
      fi
      red "管理员账号只能包含字母、数字及 . _ @ + -，长度为 1-64 位。"
    done
    local password_default
    password_default="$(random_password)"
    while true; do
      password="$(ask "请输入后台管理员密码（至少 12 位），直接回车自动生成" "$password_default")"
      if [ "${#password}" -ge 12 ]; then
        break
      fi
      red "管理员密码至少需要 12 位。"
    done
  fi

  install_deps
  copy_source "$script_dir" "$app_dir"
  write_service "$app_dir" "$port" "$password" "$admin_username"
  patch_nginx "$domain" "$port" || true

  local actual_admin_accounts=""
  local account_wait
  for account_wait in 1 2 3 4 5 6 7 8 9 10; do
    actual_admin_accounts="$(read_admin_accounts "$app_dir")"
    [ -n "$actual_admin_accounts" ] && break
    sleep 0.2
  done

  echo
  green "=== 部署完成 ==="
  echo "后台地址：http://${domain}"
  echo "管理员账号：${actual_admin_accounts:-$admin_username}"
  if [ "$is_update" = "1" ]; then
    echo "管理员密码：沿用后台现有密码（密码已加密，无法显示明文）"
  else
    echo "管理员密码：${password}"
  fi
  echo
  echo "中文状态命令：bash install-baota.sh status"
  echo "重启命令：systemctl restart ${APP_NAME}"
  show_status
  echo
  yellow "如果域名已经开启 HTTPS，请用 https://${domain} 访问。"
  yellow "登录后建议先到“账号”里修改管理员资料，再到“对接”下载工具箱 EXE。"
}

main "$@"
